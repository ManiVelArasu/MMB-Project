import 'package:flutter_colorpicker/flutter_colorpicker.dart';
import 'package:mmb_app/Repository/get_me_repository.dart';

import '../../Api Model/template_edit_model.dart';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'dart:math' as math;
import 'dart:convert';
import 'package:dio/dio.dart';

import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';

import '../../Api Model/editor_model.dart';
import '../../Repository/freePic.dart';
import '../../Repository/template_edit_repository.dart';
import '../../core/api/api_endpoints.dart';
import '../../core/api/api_repository.dart';
import '../../core/api/enums/api_error_type.dart';
import '../../core/api/enums/api_method.dart';
import '../../core/api/models/api_error.dart';
import '../../core/api/models/api_request_config.dart';
import '../../core/api/models/api_result.dart';
import '../../core/app_provider/my_notifier.dart';

class EditorProvider extends ChangeNotifier with MyNotifier {
  /// User-uploaded media, available in Media > Uploads.
  /// `key` is the S3 object key; `url` is the CDN URL used for preview.
  final List<Map<String, String>> uploadedMediaImages = <Map<String, String>>[];
  String? lastUploadedS3Key;
  String? selectedMediaS3Key;
  bool isUploadingMediaImage = false;
  bool isLoadingMyUploads = false;
  bool hasFetchedMyUploads = false;
  String? myUploadsError;

  /// Loads the user's previously uploaded Media Library images from the API.
  /// Keeps any in-progress local preview tiles already shown in the grid.
  Future<void> loadMyUploads({bool forceRefresh = false}) async {
    if (isLoadingMyUploads) return;
    if (hasFetchedMyUploads && !forceRefresh) return;

    isLoadingMyUploads = true;
    myUploadsError = null;
    notifyListeners();

    try {
      final result = await ApiRepository.instance
          .request<Map<String, dynamic>>(
        config: ApiRequestConfig(
          endpoint: ApiEndpoints.upload,
          method: ApiMethod.get,
        ),
        fromJson: (json) => Map<String, dynamic>.from(json as Map),
      );

      result.when(
        success: (response) {
          final rawData = response['data'];
          if (rawData is! List) {
            throw const FormatException('Invalid MyUploads response: data is not a list');
          }

          final apiImages = <Map<String, String>>[];
          for (final rawItem in rawData) {
            if (rawItem is! Map) continue;
            final item = Map<String, dynamic>.from(rawItem);
            final key = (item['s3_key'] ?? item['key'] ?? '').toString();
            if (key.isEmpty) continue;
            apiImages.add({
              'key': key,
              'url': assetCdnUrl(key),
              'filename': (item['original_filename'] ?? item['filename'] ?? '').toString(),
              'localPath': '',
              'uploading': 'false',
            });
          }

          // Keep local/in-progress previews; replace server-backed items with
          // the latest API result to avoid duplicates after each refresh.
          final localPreviews = uploadedMediaImages
              .where((item) =>
          (item['uploading'] == 'true') ||
              ((item['key'] ?? '').isEmpty &&
                  (item['localPath'] ?? '').isNotEmpty))
              .toList();
          uploadedMediaImages
            ..clear()
            ..addAll(localPreviews)
            ..addAll(apiImages);
          hasFetchedMyUploads = true;
        },
        failure: (error) {
          myUploadsError = error.message;
        },
      );
    } catch (e) {
      myUploadsError = e.toString();
      debugPrint('❌ MyUploads API failed: $e');
    } finally {
      isLoadingMyUploads = false;
      notifyListeners();
    }
  }

  /// Presign -> upload bytes to S3 -> confirm the uploaded object.
  /// `slot` must be one accepted by the backend upload API.
  Future<ApiResult<Map<String, dynamic>>> uploadImageAndConfirm({
    required File imageFile,
    required String filename,
    required int width,
    required int height,
    required String slot,
    String? contentType,
  }) async {
    try {
      final dio = Dio();
      final resolvedContentType =
          contentType ??
              (filename.toLowerCase().endsWith('.png')
                  ? 'image/png'
                  : 'image/jpeg');

      debugPrint('🚀 MEDIA UPLOAD | slot=$slot | filename=$filename');

      final initResult = await ApiRepository.instance
          .request<Map<String, dynamic>>(
        config: ApiRequestConfig(
          endpoint: ApiEndpoints.fileUpload,
          method: ApiMethod.post,
          body: {
            "target": {"slot": slot},
            "filename": filename,
            "content_type": resolvedContentType,
          },
        ),
        fromJson: (json) {
          return Map<String, dynamic>.from(json['data'] as Map);
        },
      );

      String? uploadUrl;
      String? uploadKey;
      Map<String, dynamic>? requiredHeaders;

      final initSuccess = initResult.when(
        success: (data) {
          uploadUrl = data['upload_url']?.toString();
          uploadKey = data['key']?.toString();
          final headers = data['required_headers'];
          if (headers is Map) {
            requiredHeaders = Map<String, dynamic>.from(headers);
          }
          return true;
        },
        failure: (error) {
          debugPrint('❌ Presign API failed: ${error.message}');
          return false;
        },
      );

      if (!initSuccess ||
          uploadUrl == null ||
          uploadUrl!.isEmpty ||
          uploadKey == null ||
          uploadKey!.isEmpty) {
        return ApiResult.failure(
          ApiError(
            message: 'Failed to get presign URL from server',
            type: ApiErrorType.unknown,
          ),
        );
      }

      final bytes = await imageFile.readAsBytes();
      final s3Headers = <String, dynamic>{
        Headers.contentLengthHeader: bytes.length,
        ...?requiredHeaders,
      };
      final s3Response = await dio.put(
        uploadUrl!,
        data: Stream<List<int>>.fromIterable([bytes]),
        options: Options(headers: s3Headers, contentType: resolvedContentType),
      );

      if (s3Response.statusCode != 200 && s3Response.statusCode != 204) {
        return ApiResult.failure(
          ApiError(
            message: 'S3 upload failed: ${s3Response.statusCode}',
            type: ApiErrorType.unknown,
          ),
        );
      }

      final confirmResult = await ApiRepository.instance
          .request<Map<String, dynamic>>(
        config: ApiRequestConfig(
          endpoint: '/uploads/confirm',
          method: ApiMethod.post,
          body: {
            'uploads': [
              {
                'key': uploadKey,
                'width': width,
                'height': height,
                'filename': filename,
              },
            ],
          },
        ),
        fromJson: (json) => Map<String, dynamic>.from(json['data'] as Map),
      );

      confirmResult.when(
        success: (data) {
          lastUploadedS3Key = uploadKey;
          if (slot == 'media_library') {
            // Replace the temporary local preview only after S3 upload AND
            // confirm succeed, so the thumbnail remains visible throughout.
            uploadedMediaImages.removeWhere(
                  (item) =>
              item['key'] == uploadKey ||
                  item['localPath'] == imageFile.path,
            );
            uploadedMediaImages.insert(0, {
              'key': uploadKey!,
              'url': assetCdnUrl(uploadKey),
              'filename': filename,
              'localPath': imageFile.path,
              'uploading': 'false',
            });
          }
          debugPrint('Uploaded image key: $uploadKey');
          debugPrint('Uploaded image URL: ${assetCdnUrl(uploadKey)}');
          debugPrint('Local image path: ${imageFile.path}');
          debugPrint('✅ Upload confirmed: $uploadKey');
          notifyListeners();
        },
        failure: (error) =>
            debugPrint('❌ Upload confirmation failed: ${error.message}'),
      );
      return confirmResult;
    } catch (e, stackTrace) {
      debugPrint('❌ uploadImageAndConfirm exception: $e');
      debugPrintStack(stackTrace: stackTrace);
      return ApiResult.failure(
        ApiError(message: e.toString(), type: ApiErrorType.unknown),
      );
    }
  }

  /// Computes the pixel dimensions and uploads a picked image to Media.
  Future<bool> uploadPickedMediaImage(File imageFile) async {
    if (isUploadingMediaImage) return false;
    isUploadingMediaImage = true;
    // Show the picked image immediately while presign/S3/confirm runs.
    uploadedMediaImages.removeWhere(
          (item) => item['localPath'] == imageFile.path,
    );
    uploadedMediaImages.insert(0, {
      'key': '',
      'url': '',
      'filename': imageFile.uri.pathSegments.isNotEmpty
          ? imageFile.uri.pathSegments.last
          : 'uploading_image.jpg',
      'localPath': imageFile.path,
      'uploading': 'true',
    });
    notifyListeners();
    try {
      final bytes = await imageFile.readAsBytes();
      final codec = await ui.instantiateImageCodec(bytes);
      final frame = await codec.getNextFrame();
      final width = frame.image.width;
      final height = frame.image.height;
      frame.image.dispose();
      codec.dispose();
      final filename = imageFile.uri.pathSegments.isNotEmpty
          ? imageFile.uri.pathSegments.last
          : 'upload_${DateTime.now().millisecondsSinceEpoch}.jpg';
      final result = await uploadImageAndConfirm(
        imageFile: imageFile,
        filename: filename,
        width: width,
        height: height,
        slot: 'media_library',
      );
      return result.when(success: (_) => true, failure: (_) => false);
    } catch (e) {
      debugPrint('❌ Could not upload picked image: $e');
      uploadedMediaImages.removeWhere(
            (item) => item['localPath'] == imageFile.path,
      );
      return false;
    } finally {
      // Remove the temporary tile on failure; successful uploads have already
      // replaced it with the confirmed media item above.
      final stillTemporary = uploadedMediaImages.any(
            (item) =>
        item['localPath'] == imageFile.path &&
            item['uploading'] == 'true',
      );
      if (stillTemporary) {
        uploadedMediaImages.removeWhere(
              (item) => item['localPath'] == imageFile.path,
        );
      }
      isUploadingMediaImage = false;
      notifyListeners();
    }
  }

  final List<EditorItem> _items = [];
  List<EditorItem> get items => _items;
  final Map<String, String> _imageMaskUrls = {};
  final Map<String, String> _imageMaskNames = {};
  final Map<String, String> _outlineStyles = {};
  final Map<String, String> _outlineJoins = {};
  final Map<String, Map<String, dynamic>> _templateRawObjects = {};
  final Set<String> _templateBackgroundIds = <String>{};

  final Map<String, bool> _templateFlipX = {};
  final Map<String, bool> _templateFlipY = {};
  Map<String, dynamic>? templateRawObject(String id) => _templateRawObjects[id];

  bool templateFlipX(String id) => _templateFlipX[id] ?? false;
  bool templateFlipY(String id) => _templateFlipY[id] ?? false;

  String? imageMaskUrl(String id) => _imageMaskUrls[id];
  String? imageMaskName(String id) => _imageMaskNames[id];

  String outlineStyle(String id) => _outlineStyles[id] ?? 'none';
  String outlineJoin(String id) => _outlineJoins[id] ?? 'round';

  void updateOutlineJoin(String id, String join) {
    if (!_items.any((e) => e.id == id)) return;
    _saveState();
    _outlineJoins[id] = join;
    final raw = _templateRawObjects[id];
    if (raw != null) raw['strokeLineJoin'] = join;
    notifyListeners();
  }

  void updateOutlineStyle(String id, String style) {
    if (!_items.any((e) => e.id == id)) return;
    _saveState();
    _outlineStyles[id] = style;
    final raw = _templateRawObjects[id];
    if (raw != null) {
      switch (style) {
        case 'none':
          raw['strokeDashArray'] = null;
          raw['strokeWidth'] = 0;
          break;
        case 'solid':
          raw['strokeDashArray'] = null;
          break;
        case 'dashed':
          raw['strokeDashArray'] = [12, 8];
          break;
        case 'dotted':
          raw['strokeDashArray'] = [1, 6];
          raw['strokeLineCap'] = 'round';
          break;
        case 'fine_dotted':
          raw['strokeDashArray'] = [1, 3];
          raw['strokeLineCap'] = 'round';
          break;
      }
    }
    if (style != 'none') {
      final index = _items.indexWhere((e) => e.id == id);
      if (index != -1) {
        final current = _items[index];
        final width = current.outlineWidth > 0 ? current.outlineWidth : 3.0;
        final color = current.outlineColor ?? const Color(0xFFD9D9D9);
        _items[index] = current.copyWith(
          outlineWidth: width,
          outlineColor: color,
        );
        if (raw != null) {
          raw['stroke'] = colorToHex(color);
          raw['strokeWidth'] = width;
        }
      }
    }
    notifyListeners();
  }

  String assetCdnUrl(String? key) {
    if (key == null || key.trim().isEmpty) return '';
    final value = key.trim();
    if (value.startsWith('http://') || value.startsWith('https://')) {
      return value;
    }
    final base = ApiEndpoints.cdnImageUrl.replaceFirst(RegExp(r'/$'), '');
    return '$base/${value.replaceFirst(RegExp(r'^/'), '')}';
  }

  void setImageMask(String id, {required String name, required String url}) {
    if (!_items.any((e) => e.id == id)) return;
    _saveState();
    _imageMaskNames[id] = name;
    _imageMaskUrls[id] = assetCdnUrl(url);
    notifyListeners();
  }

  void clearImageMask(String id) {
    _saveState();
    _imageMaskNames.remove(id);
    _imageMaskUrls.remove(id);
    notifyListeners();
  }

  final List<List<EditorItem>> _history = [];
  int _historyIndex = -1;
  Color _backgroundColor = Colors.white;
  Gradient? _importedBackgroundGradient;
  Gradient? get importedBackgroundGradient => _importedBackgroundGradient;
  bool _hasImportedRootBackground = false;

  // Editor music state. The actual audio file is kept as a local path so it
  // can be bundled with the project export/download.
  String? _selectedMusicPath;
  String? _selectedMusicTitle;
  bool _isEditorMusicPlaying = false;
  Duration _musicPosition = Duration.zero;
  Duration _musicDuration = Duration.zero;

  String? get selectedMusicPath => _selectedMusicPath;
  String? get selectedMusicTitle => _selectedMusicTitle;
  bool get isEditorMusicPlaying => _isEditorMusicPlaying;
  Duration get musicPosition => _musicPosition;
  Duration get musicDuration => _musicDuration;

  void setSelectedMusic({required String path, required String title}) {
    _selectedMusicPath = path;
    _selectedMusicTitle = title;
    _musicPosition = Duration.zero;
    _musicDuration = Duration.zero;
    notifyListeners();
  }

  void setMusicPlaying(bool value) {
    _isEditorMusicPlaying = value;
    notifyListeners();
  }

  void setMusicPosition(Duration value) {
    _musicPosition = value;
    notifyListeners();
  }

  void setMusicDuration(Duration value) {
    _musicDuration = value;
    notifyListeners();
  }

  void clearMusic() {
    _selectedMusicPath = null;
    _selectedMusicTitle = null;
    _isEditorMusicPlaying = false;
    _musicPosition = Duration.zero;
    _musicDuration = Duration.zero;
    notifyListeners();
  }

  final Map<String, double> _textLetterSpacing = {};
  final Map<String, double> _textLineSpacing = {};
  final Map<String, TextAlign> _textAlignment = {};
  final Map<String, FontWeight> _textWeight = {};
  final Map<String, FontStyle> _textStyle = {};
  final Map<String, bool> _textUnderline = {};

  double textLetterSpacing(String id) => _textLetterSpacing[id] ?? 0.0;
  double textLineSpacing(String id) => _textLineSpacing[id] ?? 1.0;
  TextAlign textAlignment(String id) => _textAlignment[id] ?? TextAlign.left;
  FontWeight textWeight(String id) => _textWeight[id] ?? FontWeight.bold;
  FontStyle textStyle(String id) => _textStyle[id] ?? FontStyle.normal;
  bool textUnderline(String id) => _textUnderline[id] ?? false;
  EditorItem? _copiedItem;
  int? _copiedFromPageIndex;

  List<EditorItem>? _copiedPageItems;
  int? _copiedPageIndex;
  Color? _copiedPageBackgroundColor;

  final Map<String, double> _copiedLetterSpacing = {};
  final Map<String, double> _copiedLineSpacing = {};
  final Map<String, TextAlign> _copiedAlignment = {};
  final Map<String, FontWeight> _copiedWeight = {};
  final Map<String, FontStyle> _copiedStyle = {};
  final Map<String, bool> _copiedUnderline = {};
  final Map<String, double> _copiedFilterIntensity = {};

  bool get hasCopiedPage =>
      _copiedPageItems != null && _copiedPageItems!.isNotEmpty;

  bool get canPasteCopiedPage => hasCopiedPage;

  bool get hasCopiedItem => _copiedItem != null;

  bool get canPasteCopiedItem {
    return _copiedItem != null &&
        _copiedFromPageIndex != null &&
        _copiedFromPageIndex != _currentPageIndex;
  }

  void updateTextLetterSpacing(String id, double value) {
    _textLetterSpacing[id] = value.clamp(-2.0, 20.0);
    notifyListeners();
  }

  void updateTextLineSpacing(String id, double value) {
    _textLineSpacing[id] = value.clamp(0.7, 3.0);
    notifyListeners();
  }

  void updateTextAlignment(String id, TextAlign value) {
    _textAlignment[id] = value;
    notifyListeners();
  }

  void toggleTextBold(String id) {
    _textWeight[id] = textWeight(id) == FontWeight.bold
        ? FontWeight.normal
        : FontWeight.bold;
    notifyListeners();
  }

  void toggleTextItalic(String id) {
    _textStyle[id] = textStyle(id) == FontStyle.italic
        ? FontStyle.normal
        : FontStyle.italic;
    notifyListeners();
  }

  void toggleTextUnderline(String id) {
    _textUnderline[id] = !textUnderline(id);
    notifyListeners();
  }

  void setTextNormal(String id) {
    _textWeight[id] = FontWeight.normal;
    _textStyle[id] = FontStyle.normal;
    _textUnderline[id] = false;
    notifyListeners();
  }

  void _saveState() {
    if (_history.isEmpty) {
      _history.add(_items.map((e) => e.copyWith()).toList());
      _historyIndex = 0;
      return;
    }

    if (_historyIndex < _history.length - 1) {
      _history.removeRange(_historyIndex + 1, _history.length);
    }

    _history.add(_items.map((e) => e.copyWith()).toList());

    _historyIndex = _history.length - 1;
  }

  double canvasWidth = 1080.0;
  double canvasHeight = 1080.0;

  void setCanvasSize(double width, double height) {
    final w = width.isFinite && width > 0 ? width : 1080.0;
    final h = height.isFinite && height > 0 ? height : 1080.0;
    canvasWidth = w;
    canvasHeight = h;
  }

  double _rotationExtentX(EditorItem item, double scale) {
    final w = math.max(1.0, item.width);
    final h = math.max(1.0, item.height);
    final angle = item.rotation.isFinite ? item.rotation : 0.0;
    final c = math.cos(angle).abs();
    final s = math.sin(angle).abs();
    return ((w * c) + (h * s)) * scale / 2.0;
  }

  double _rotationExtentY(EditorItem item, double scale) {
    final w = math.max(1.0, item.width);
    final h = math.max(1.0, item.height);
    final angle = item.rotation.isFinite ? item.rotation : 0.0;
    final c = math.cos(angle).abs();
    final s = math.sin(angle).abs();
    return ((w * s) + (h * c)) * scale / 2.0;
  }

  Offset _clampPositionForFrame(EditorItem item, Offset position) {
    if (_isBackgroundLayer(item)) return Offset.zero;

    final scale = (item.scale.isFinite ? item.scale : 1.0)
        .clamp(0.05, 10.0)
        .toDouble();

    final baseW = math.max(1.0, item.width);
    final baseH = math.max(1.0, item.height);

    final extentX = _rotationExtentX(item, scale);
    final extentY = _rotationExtentY(item, scale);

    final minCenterX = extentX;
    final maxCenterX = canvasWidth - extentX;
    final minCenterY = extentY;
    final maxCenterY = canvasHeight - extentY;

    final centerX = minCenterX >= maxCenterX
        ? canvasWidth / 2.0
        : (position.dx + baseW / 2.0).clamp(minCenterX, maxCenterX).toDouble();

    final centerY = minCenterY >= maxCenterY
        ? canvasHeight / 2.0
        : (position.dy + baseH / 2.0).clamp(minCenterY, maxCenterY).toDouble();

    return Offset(centerX - baseW / 2.0, centerY - baseH / 2.0);
  }

  double _maxScaleForFrame(EditorItem item, double requested) {
    if (_isBackgroundLayer(item)) {
      return requested.clamp(0.01, 10.0).toDouble();
    }

    final safeRequested = requested.isFinite
        ? requested.clamp(0.05, 10.0).toDouble()
        : 1.0;

    final baseW = math.max(1.0, item.width);
    final baseH = math.max(1.0, item.height);

    final centerX = item.position.dx + baseW / 2.0;
    final centerY = item.position.dy + baseH / 2.0;

    final angle = item.rotation.isFinite ? item.rotation : 0.0;
    final c = math.cos(angle).abs();
    final s = math.sin(angle).abs();

    final extentXAtOne = (baseW * c + baseH * s) / 2.0;
    final extentYAtOne = (baseW * s + baseH * c) / 2.0;

    final limitX = extentXAtOne <= 0
        ? 10.0
        : math.min(
      centerX / extentXAtOne,
      (canvasWidth - centerX) / extentXAtOne,
    );

    final limitY = extentYAtOne <= 0
        ? 10.0
        : math.min(
      centerY / extentYAtOne,
      (canvasHeight - centerY) / extentYAtOne,
    );

    final maxAllowed = math.max(0.05, math.min(10.0, math.min(limitX, limitY)));

    return math.min(safeRequested, maxAllowed).clamp(0.05, 10.0).toDouble();
  }

  String? selectedItemType;
  String? selectedItemId;
  String? selectedFrameUrl;

  List<String> freePikAssets = [];
  bool isFreePikLoading = false;
  List<String> freePikStickers = [];
  bool isStickersLoading = false;
  // Keep background search results completely separate from element results.
  List<String> backgroundAssets = [];
  bool isBackgroundLoading = false;
  String _backgroundQuery = '';
  final Map<String, int> _backgroundRequestIds = {};

  // Media -> Images (Pexels) keeps its own state so it never conflicts
  // with the Background panel results.
  List<String> mediaImageAssets = [];
  bool isMediaImagesLoading = false;
  String _mediaImagesQuery = '';
  String get mediaImagesQuery => _mediaImagesQuery;
  int _mediaImagesRequestId = 0;

  // Element categories keep their own results/loading state.
  final Map<String, List<String>> _elementCategoryAssets = {};
  final Set<String> _elementCategoryRequested = <String>{};
  final Map<String, List<AssetCategoryItem>> _assetCategoryItems = {};
  final Map<String, bool> _elementCategoryLoading = {};
  // Loading state for the backend Freepik sticker proxy categories.
  // Keys: stickers, social media, e-commerce
  final Map<String, bool> _isFreePikStickerCategoryLoading = {};
  final Map<String, int> _elementCategoryRequestIds = {};
  final Set<String> _elementCategoryAllInProgress = <String>{};

  List<String> elementCategoryAssets(String query) =>
      List.unmodifiable(_elementCategoryAssets[query] ?? const <String>[]);

  List<AssetCategoryItem> assetCategoryItems(String query) => List.unmodifiable(
    _assetCategoryItems[query] ?? const <AssetCategoryItem>[],
  );

  bool isElementCategoryLoading(String query) =>
      _elementCategoryLoading[query.trim().toLowerCase()] ?? false;

  // Public getter used by the Elements UI.
  Map<String, bool> get isFreePikStickerCategoryLoading =>
      Map.unmodifiable(_isFreePikStickerCategoryLoading);

  // Background category assets loaded from the existing Freepik API.
  List<String> freePikShapes = [];
  List<String> freePikSocialMedia = [];
  List<String> freePikEcommerce = [];

  bool isShapesLoading = false;
  bool isSocialMediaLoading = false;
  bool isEcommerceLoading = false;

  Future<List<String>> _fetchFreepikCategory(
      String query, {
        required void Function(bool) setLoading,
        required void Function(List<String>) setData,
      }) async {
    setLoading(true);
    notifyListeners();
    try {
      final result = await FreePikService.searchAssets(
        query,
        page: 1,
        limit: 30,
      ).timeout(const Duration(seconds: 20), onTimeout: () => <String>[]);
      setData(result);
      return result;
    } catch (e) {
      debugPrint('Freepik category error [$query]: $e');
      setData(<String>[]);
      return <String>[];
    } finally {
      setLoading(false);
      notifyListeners();
    }
  }

  /// Loads background assets into a dedicated state.
  /// A request token prevents a late response from an older search from
  /// replacing the currently selected category/search results.
  Future<void> fetchBackgroundAssets(String query) async {
    final normalized = query.trim().isEmpty
        ? 'abstract background'
        : query.trim();

    final requestId = (_backgroundRequestIds[normalized] ?? 0) + 1;
    _backgroundRequestIds[normalized] = requestId;

    _backgroundQuery = normalized;
    isBackgroundLoading = true;
    backgroundAssets = <String>[];
    notifyListeners();

    try {
      final result = await FreePikService.searchPexelsPhotos(
        normalized,
        page: 1,
        limit: 24,
      ).timeout(const Duration(seconds: 15), onTimeout: () => <String>[]);

      // Only apply the response if this is still the latest request for
      // this query and the user has not moved to another background query.
      if (_backgroundRequestIds[normalized] == requestId &&
          _backgroundQuery == normalized) {
        backgroundAssets = result.toSet().toList();
      }
    } catch (e) {
      debugPrint('Background Pexels error [$normalized]: $e');
      if (_backgroundRequestIds[normalized] == requestId &&
          _backgroundQuery == normalized) {
        backgroundAssets = <String>[];
      }
    } finally {
      if (_backgroundRequestIds[normalized] == requestId &&
          _backgroundQuery == normalized) {
        isBackgroundLoading = false;
        notifyListeners();
      }
    }
  }

  Future<void> fetchMediaImages(String query) async {
    // Media > Images initial load must call the Pexels proxy WITHOUT a term.
    // Category/search clicks add their own term (e.g. Nature -> nature landscape).
    final normalized = query.trim();
    final requestId = ++_mediaImagesRequestId;

    _mediaImagesQuery = normalized;
    isMediaImagesLoading = true;
    mediaImageAssets = <String>[];
    notifyListeners();

    try {
      final result = await FreePikService.searchPexelsPhotos(
        normalized,
        page: 1,
        limit: 24,
      ).timeout(const Duration(seconds: 20), onTimeout: () => <String>[]);

      if (requestId == _mediaImagesRequestId &&
          _mediaImagesQuery == normalized) {
        mediaImageAssets = result
            .where((url) => url.trim().isNotEmpty)
            .toSet()
            .toList();
      }
    } catch (e) {
      debugPrint('Media Pexels images error [$normalized]: $e');
      if (requestId == _mediaImagesRequestId &&
          _mediaImagesQuery == normalized) {
        mediaImageAssets = <String>[];
      }
    } finally {
      if (requestId == _mediaImagesRequestId &&
          _mediaImagesQuery == normalized) {
        isMediaImagesLoading = false;
        notifyListeners();
      }
    }
  }

  /// Loads one element category without touching backgroundAssets or the
  /// generic freePikAssets list.
  Future<void> fetchElementCategory(
      String query, {
        int page = 1,
        int limit = 4,
        bool append = false,
      }) async {
    final normalized = query.trim().toLowerCase();
    if (normalized.isEmpty) return;

    // Prevent StatefulBuilder rebuilds from starting the same empty/error
    // request again and again.
    if (!append &&
        page == 1 &&
        _elementCategoryRequested.contains(normalized)) {
      return;
    }
    if (!append && page == 1) {
      _elementCategoryRequested.add(normalized);
    }

    final requestKey = '${normalized}__$page';
    final requestId = (_elementCategoryRequestIds[requestKey] ?? 0) + 1;
    _elementCategoryRequestIds[requestKey] = requestId;

    if (!append) {
      _elementCategoryLoading[normalized] = true;
      if (normalized == 'stickers' ||
          normalized == 'social media' ||
          normalized == 'e-commerce') {
        _isFreePikStickerCategoryLoading[normalized] = true;
      }
      _elementCategoryAssets[normalized] = <String>[];
      _assetCategoryItems[normalized] = <AssetCategoryItem>[];
    }
    notifyListeners();

    try {
      if (normalized == 'shapes' ||
          normalized == 'masks' ||
          normalized == 'mask') {
        // Shapes, masks, social media and e-commerce all come from the
        // backend assets API. Keep records without an S3 source so the UI
        // can show LOCKED instead of incorrectly saying "No data found".
        final apiCategory = normalized;
        final result = await FreePikService.fetchAssetsByCategory(
          apiCategory,
          page: page,
          perPage: limit,
        );

        if (_elementCategoryRequestIds[requestKey] != requestId) return;

        final current =
            _assetCategoryItems[normalized] ?? <AssetCategoryItem>[];
        final merged = append ? [...current, ...result] : result;
        final unique = <String, AssetCategoryItem>{};

        for (final item in merged) {
          final key =
              item.id?.toString() ??
                  '${item.name}|${item.s3Key}|${item.s3Key ?? ''}';
          unique[key] = item;
        }

        final items = unique.values.toList();
        _assetCategoryItems[normalized] = items;

        // Only unlocked/source-backed assets are returned to legacy string
        // consumers. The UI uses assetCategoryItems for LOCKED rendering.
        _elementCategoryAssets[normalized] = items
            .map((e) => e.previewKey)
            .where(
              (e) =>
          e.trim().isNotEmpty &&
              !items.any((x) => x.previewKey == e && x.isLocked),
        )
            .toSet()
            .toList();
      } else {
        final result = await FreePikService.searchStickers(
          term: normalized == 'stickers' ? null : normalized,
          page: page,
          perPage: limit,
        ).timeout(const Duration(seconds: 15), onTimeout: () => <String>[]);

        if (_elementCategoryRequestIds[requestKey] != requestId) return;

        final current = _elementCategoryAssets[normalized] ?? <String>[];
        _elementCategoryAssets[normalized] = append
            ? [...current, ...result].toSet().toList()
            : result.toSet().toList();
      }
    } catch (e) {
      debugPrint('Element category error [$normalized, page=$page]: $e');
      if (!append && _elementCategoryRequestIds[requestKey] == requestId) {
        _elementCategoryAssets[normalized] = <String>[];
        _assetCategoryItems[normalized] = <AssetCategoryItem>[];
      }
    } finally {
      if (_elementCategoryRequestIds[requestKey] == requestId) {
        // Keep View All's spinner active if its request is still running.
        if (!_elementCategoryAllInProgress.contains(normalized)) {
          _elementCategoryLoading[normalized] = false;
          if (normalized == 'stickers' ||
              normalized == 'social media' ||
              normalized == 'e-commerce') {
            _isFreePikStickerCategoryLoading[normalized] = false;
          }
        }
        notifyListeners();
      }
    }
  }

  void resetElementCategoryRequest(String query) {
    _elementCategoryRequested.remove(query.trim().toLowerCase());
  }

  Future<void> fetchElementCategoryAll(String query) async {
    final normalized = query.trim().toLowerCase();
    if (normalized.isEmpty) return;

    final requestId =
        (_elementCategoryRequestIds['${normalized}__all'] ?? 0) + 1;
    _elementCategoryRequestIds['${normalized}__all'] = requestId;
    _elementCategoryAllInProgress.add(normalized);
    _elementCategoryLoading[normalized] = true;
    if (normalized == 'stickers' ||
        normalized == 'social media' ||
        normalized == 'e-commerce') {
      _isFreePikStickerCategoryLoading[normalized] = true;
    }
    _elementCategoryAssets[normalized] = <String>[];
    _assetCategoryItems[normalized] = <AssetCategoryItem>[];
    notifyListeners();

    try {
      final all = <String>[];
      // Fetch several pages so View all is not limited to the first 4 results.
      // Shapes/masks are supplied by /api/assets as AssetCategoryItem objects.
      // The backend may cap per_page, so page-by-page loading is intentional.
      final allAssetItems = <AssetCategoryItem>[];

      for (var page = 1; page <= 10; page++) {
        if (_elementCategoryRequestIds['${normalized}__all'] != requestId)
          return;

        if (normalized == 'stickers' ||
            normalized == 'social media' ||
            normalized == 'e-commerce') {
          final result = await FreePikService.searchStickers(
            term: normalized == 'stickers' ? null : normalized,
            page: page,
            perPage: 30,
          ).timeout(const Duration(seconds: 15), onTimeout: () => <String>[]);
          if (result.isEmpty) break;

          final before = all.length;
          all.addAll(result);
          final unique = all.toSet().toList();
          all
            ..clear()
            ..addAll(unique);
          _elementCategoryAssets[normalized] = List.unmodifiable(all);

          notifyListeners();
          if (all.length == before) break;
          if (result.length < 2) break;
        } else {
          final result = await FreePikService.fetchAssetsByCategory(
            normalized,
            page: page,
            perPage: 30,
          );
          if (result.isEmpty) break;

          final before = allAssetItems.length;
          allAssetItems.addAll(result);

          final unique = <String, AssetCategoryItem>{};
          for (final item in allAssetItems) {
            final key =
                item.id?.toString() ??
                    '${item.name}|${item.s3Key}|${item.thumbnailS3Key ?? ''}';
            unique[key] = item;
          }

          allAssetItems
            ..clear()
            ..addAll(unique.values);

          _assetCategoryItems[normalized] = List.unmodifiable(allAssetItems);

          // Keep only source-backed URLs for legacy consumers.
          all
            ..clear()
            ..addAll(
              allAssetItems
                  .where((e) => !e.isLocked && e.previewKey.isNotEmpty)
                  .map((e) => e.previewKey),
            );

          _elementCategoryAssets[normalized] = List.unmodifiable(
            all.toSet().toList(),
          );

          notifyListeners();
          if (allAssetItems.length == before) break;
          if (result.length < 2) break;
        }
      }
    } catch (e) {
      debugPrint('Element category all error [$normalized]: $e');
    } finally {
      if (_elementCategoryRequestIds['${normalized}__all'] == requestId) {
        _elementCategoryAllInProgress.remove(normalized);
        _elementCategoryLoading[normalized] = false;
        if (normalized == 'stickers' ||
            normalized == 'social media' ||
            normalized == 'e-commerce') {
          _isFreePikStickerCategoryLoading[normalized] = false;
        }
        notifyListeners();
      }
    }
  }

  Future<void> fetchFreePikBackgroundCategories() async {
    await Future.wait([
      fetchFreePikShapes(),
      fetchFreePikSocialMedia(),
      fetchFreePikEcommerce(),
      fetchFreePikStickers('stickers'),
    ]);
  }

  Future<void> fetchFreePikShapes() async {
    await _fetchFreepikCategory(
      'shapes vector icons elements',
      setLoading: (value) => isShapesLoading = value,
      setData: (value) => freePikShapes = value,
    );
  }

  Future<void> fetchFreePikSocialMedia() async {
    await _fetchFreepikCategory(
      'social media',
      setLoading: (value) => isSocialMediaLoading = value,
      setData: (value) => freePikSocialMedia = value,
    );
  }

  Future<void> fetchFreePikEcommerce() async {
    await _fetchFreepikCategory(
      'e-commerce',
      setLoading: (value) => isEcommerceLoading = value,
      setData: (value) => freePikEcommerce = value,
    );
  }

  TemplateEdit? _templateDetail;
  TemplateEdit? get templateDetail => _templateDetail;

  bool _isTemplateDetailLoading = false;
  bool get isTemplateDetailLoading => _isTemplateDetailLoading;

  String? _templateDetailError;
  String? get templateDetailError => _templateDetailError;

  /// Loads the template detail API and converts its Fabric JSON `content`
  /// into the editor's existing EditorItem list.
  Future<bool> loadTemplateByUid(
      String uid, {
        double? canvasWidth,
        double? canvasHeight,
      }) async {
    final safeUid = uid.trim();

    if (safeUid.isEmpty) {
      _templateDetailError = 'Template UID is empty';
      _isTemplateDetailLoading = false;
      isTemplateLoaded = false;
      notifyListeners();
      return false;
    }

    _isTemplateDetailLoading = true;
    _templateDetailError = null;
    isTemplateLoaded = false;
    notifyListeners();

    try {
      debugPrint('📄 Loading template: $safeUid');

      final result = await TemplateRepository.instance.getTemplateByUid(
        uid: safeUid,
      );

      final detail = result.data;

      if (detail == null) {
        _templateDetailError = 'Template not found';
        return false;
      }

      // Updated model: data.items
      if (detail.data.items.isEmpty) {
        _templateDetailError = 'Template items are empty';
        return false;
      }

      final template = detail.data.items.first;
      final content = template.content?.trim() ?? '';

      if (content.isEmpty) {
        _templateDetailError = 'Template content is empty';
        return false;
      }

      _templateDetail = detail;

      dynamic decoded;

      try {
        decoded = jsonDecode(content);
      } catch (e) {
        debugPrint('❌ Invalid template JSON: $e');
        _templateDetailError = 'Invalid template content JSON';
        return false;
      }

      Map<String, dynamic>? root;

      if (decoded is Map) {
        root = Map<String, dynamic>.from(decoded);
      }

      // Background may be stored at the root (editor JSON) or inside the
      // first page / Fabric document (the template API's Fabric JSON).
      if (root != null) {
        dynamic backgroundValue =
            root['backgroundColor'] ??
                root['background'] ??
                root['background_color'];

        if (backgroundValue == null && root['pages'] is List) {
          final pages = root['pages'] as List;
          if (pages.isNotEmpty && pages.first is Map) {
            final firstPage = Map<String, dynamic>.from(pages.first as Map);
            final fabric = firstPage['fabric'];
            backgroundValue =
                firstPage['backgroundColor'] ??
                    firstPage['background_color'] ??
                    (fabric is Map ? fabric['background'] : null);
          }
        }

        final backgroundGradient = _parseGradient(backgroundValue);
        if (backgroundGradient != null) {
          _importedBackgroundGradient = backgroundGradient;
          _backgroundColor = Colors.transparent;
          _hasImportedRootBackground = true;
        } else {
          final background = _parseColor(backgroundValue);
          _hasImportedRootBackground =
              background != null && background.alpha > 0;
          if (_hasImportedRootBackground) {
            _backgroundColor = background!;
          }
        }
      }

      // Find objects
      List<dynamic> objects = [];
      final List<List<dynamic>> extraPageObjects = [];

      if (decoded is List) {
        objects = List<dynamic>.from(decoded);
      } else if (root != null && root['objects'] is List) {
        objects = List<dynamic>.from(root['objects']);
      } else if (root != null &&
          root['data'] is Map &&
          (root['data'] as Map)['objects'] is List) {
        objects = List<dynamic>.from((root['data'] as Map)['objects'] as List);
      } else if (root != null && root['data'] is List) {
        objects = List<dynamic>.from(root['data'] as List);
      } else if (root != null && root['pages'] is List) {
        final pages = root['pages'] as List;

        if (pages.isNotEmpty) {
          final firstPage = pages.first;

          if (firstPage is Map) {
            if (canvasWidth == null || canvasHeight == null) {
              final pageWidth = _toDouble(firstPage['width']);
              final pageHeight = _toDouble(firstPage['height']);

              if (pageWidth != null &&
                  pageHeight != null &&
                  pageWidth > 0 &&
                  pageHeight > 0) {
                setCanvasSize(pageWidth, pageHeight);
              }
            }

            final fabric = firstPage['fabric'];

            if (fabric is Map && fabric['objects'] is List) {
              objects = List<dynamic>.from(fabric['objects'] as List);
            } else if (firstPage['objects'] is List) {
              objects = List<dynamic>.from(firstPage['objects'] as List);
            }
          }

          for (final page in pages.skip(1)) {
            if (page is! Map) continue;

            final pageFabric = page['fabric'];

            if (pageFabric is Map && pageFabric['objects'] is List) {
              extraPageObjects.add(
                List<dynamic>.from(pageFabric['objects'] as List),
              );
            } else if (page['objects'] is List) {
              extraPageObjects.add(List<dynamic>.from(page['objects'] as List));
            }
          }
        }
      }

      // Canvas size
      if (canvasWidth != null &&
          canvasHeight != null &&
          canvasWidth > 0 &&
          canvasHeight > 0) {
        setCanvasSize(canvasWidth, canvasHeight);
      } else if (root != null) {
        final detected = _detectTemplateCanvasSize(root, objects);

        if (detected != null) {
          setCanvasSize(detected.width, detected.height);
        }
      }

      // Empty template
      if (objects.isEmpty) {
        debugPrint('⚠️ Template has no objects');

        _items.clear();

        if (canvasWidth != null &&
            canvasHeight != null &&
            canvasWidth > 0 &&
            canvasHeight > 0) {
          setCanvasSize(canvasWidth, canvasHeight);
        }

        isTemplateLoaded = true;
        _templateDetailError = null;

        debugPrint('✅ Empty template loaded: ${template.name}');
        return true;
      }

      // Filter valid objects
      final validObjects = objects
          .whereType<Map>()
          .map((e) => Map<String, dynamic>.from(e))
          .where(
            (object) => object['type'] != null || object['objectType'] != null,
      )
          .toList();

      debugPrint('📦 API objects: ${objects.length}');
      debugPrint('📦 Valid editor objects: ${validObjects.length}');

      final extraPages = extraPageObjects
          .map(
            (page) => page
            .whereType<Map>()
            .map((e) => Map<String, dynamic>.from(e))
            .where(
              (object) =>
          object['type'] != null || object['objectType'] != null,
        )
            .toList(),
      )
          .toList();

      // Load into editor
      loadItemsFromJson(
        validObjects,
        templateUid: safeUid,
        extraPages: extraPages,
      );

      isTemplateLoaded = true;
      _templateDetailError = null;

      debugPrint(
        '✅ Template loaded: ${template.name} | '
            '${_items.length} objects',
      );

      debugPrint('Template ID: ${template.id}');
      debugPrint('Template UID: ${template.uid}');
      debugPrint('Thumbnail S3 Key: ${template.thumbnailS3Key}');

      return true;
    } catch (e, stackTrace) {
      _templateDetailError = e
          .toString()
          .replaceFirst('Exception: ', '')
          .trim();

      if (_templateDetailError!.isEmpty) {
        _templateDetailError = 'Template not found';
      }

      isTemplateLoaded = false;

      debugPrint('❌ Template load failed [$safeUid]: $e');
      debugPrint('$stackTrace');

      return false;
    } finally {
      _isTemplateDetailLoading = false;
      notifyListeners();
    }
  }

  Size? _detectTemplateCanvasSize(
      Map<String, dynamic> root,
      List<dynamic> objects,
      ) {
    // 1. Fabric root width / height
    final rootWidth = _toDouble(root['width']);
    final rootHeight = _toDouble(root['height']);

    if (rootWidth != null &&
        rootHeight != null &&
        rootWidth > 0 &&
        rootHeight > 0) {
      return Size(rootWidth, rootHeight);
    }

    // 2. Pages format
    final pages = root['pages'];

    if (pages is List && pages.isNotEmpty) {
      final firstPage = pages.first;

      if (firstPage is Map) {
        final pageWidth = _toDouble(firstPage['width']);
        final pageHeight = _toDouble(firstPage['height']);

        if (pageWidth != null &&
            pageHeight != null &&
            pageWidth > 0 &&
            pageHeight > 0) {
          return Size(pageWidth, pageHeight);
        }

        final fabric = firstPage['fabric'];

        if (fabric is Map) {
          final fabricWidth = _toDouble(fabric['width']);
          final fabricHeight = _toDouble(fabric['height']);

          if (fabricWidth != null &&
              fabricHeight != null &&
              fabricWidth > 0 &&
              fabricHeight > 0) {
            return Size(fabricWidth, fabricHeight);
          }
        }
      }
    }

    // 3. Fallback: clip/background object
    for (final raw in objects) {
      if (raw is! Map) continue;

      final object = Map<String, dynamic>.from(raw);

      final name = object['name']?.toString().toLowerCase();
      final type = object['type']?.toString().toLowerCase();

      if (name == 'clip' || type == 'rect') {
        final width = _toDouble(object['width']);
        final height = _toDouble(object['height']);

        if (width != null && height != null && width > 0 && height > 0) {
          return Size(width, height);
        }
      }
    }

    return null;
  }

  double? _toDouble(dynamic value) {
    if (value is num) return value.toDouble();
    return double.tryParse(value?.toString() ?? '');
  }

  void setSelectedItem(String? type, String? id) {
    // Templates can come from different Fabric/API versions (`Text`,
    // `Textbox`, `IText`, etc.). Keep one canonical type inside the editor.
    final normalizedType = (type ?? '').trim().toLowerCase();
    selectedItemType =
    (normalizedType == 'textbox' ||
        normalizedType == 'i-text' ||
        normalizedType == 'itext' ||
        normalizedType == 'text')
        ? 'text'
        : type;
    selectedItemId = id;
    notifyListeners();
  }

  void setSelectedFrame(String frameUrl) {
    selectedFrameUrl = frameUrl;
    notifyListeners();
  }

  void clearSelection() {
    selectedItemType = null;
    selectedItemId = null;
    notifyListeners();
  }

  bool isTemplateLoaded = false;

  /// Convert Fabric origin-based coordinates into this editor's top-left
  /// coordinate system. This keeps center/right/bottom-origin objects aligned.
  Offset _fabricTopLeft({
    required Map<String, dynamic> json,
    required double left,
    required double top,
    required double width,
    required double height,
    required double scaleX,
    required double scaleY,
  }) {
    final visualWidth = width * scaleX;
    final visualHeight = height * scaleY;
    var x = left;
    var y = top;

    final originX = (json['originX']?.toString() ?? 'left').toLowerCase();
    final originY = (json['originY']?.toString() ?? 'top').toLowerCase();

    if (originX == 'center') {
      x -= visualWidth / 2.0;
    } else if (originX == 'right') {
      x -= visualWidth;
    }

    if (originY == 'center') {
      y -= visualHeight / 2.0;
    } else if (originY == 'bottom') {
      y -= visualHeight;
    }

    return Offset(x, y);
  }

  void loadItemsFromJson(
      List<Map<String, dynamic>> jsonList, {
        String? templateUid,
        List<List<Map<String, dynamic>>> extraPages = const [],
        bool appendAsPage = false,
      }) {
    try {
      jsonList = _flattenFabricObjects(jsonList);

      _items.clear();
      if (!appendAsPage) {
        _templateRawObjects.clear();
        _templateBackgroundIds.clear();
        _templateFlipX.clear();
        _templateFlipY.clear();
        _outlineStyles.clear();
        _outlineJoins.clear();
        _textLetterSpacing.clear();
        _textLineSpacing.clear();
        _textAlignment.clear();
        _textWeight.clear();
        _textStyle.clear();
        _textUnderline.clear();
      }

      var idIndex = 0;
      for (final json in jsonList) {
        final rawType = (json['type']?.toString() ?? '').trim();
        final type = rawType.toLowerCase();
        final objectName = (json['name']?.toString() ?? '').trim().toLowerCase();

        if (objectName == 'clip') {
          final fill = _parseColor(json['fill']);
          if ((_backgroundColor == Colors.white || _backgroundColor.alpha == 0) &&
              fill != null &&
              fill.alpha > 0) {
            _backgroundColor = fill;
          }
          continue;
        }

        final rawLeft = _toDouble(json['left']) ?? 0.0;
        final rawTop = _toDouble(json['top']) ?? 0.0;
        final width = math.max(1.0, _toDouble(json['width']) ?? 100.0);
        final height = math.max(1.0, _toDouble(json['height']) ?? 100.0);
        final scaleX = _toDouble(json['scaleX']) ?? 1.0;
        final scaleY = _toDouble(json['scaleY']) ?? 1.0;

        final importedPosition = _fabricTopLeft(
          json: json,
          left: rawLeft,
          top: rawTop,
          width: width,
          height: height,
          scaleX: scaleX,
          scaleY: scaleY,
        );

        final safeScale = scaleX.abs().clamp(0.01, 10.0);
        final importedHeight = height * (scaleY.abs() / safeScale);
        final angleDegrees = _toDouble(json['angle']) ?? 0.0;
        final rotation = angleDegrees * math.pi / 180.0;
        final opacity = (_toDouble(json['opacity']) ?? 1.0).clamp(0.0, 1.0);
        final id = 'template_${DateTime.now().microsecondsSinceEpoch}_${idIndex++}';

        final hasTextValue = json['text'] != null;
        final isTextObject =
            type == 'textbox' ||
                type == 'i-text' ||
                type == 'itext' ||
                type == 'text' ||
                hasTextValue;

        if (isTextObject) {
          final fontSize = _toDouble(json['fontSize']) ?? 36.0;
          final text = json['text']?.toString() ?? '';

          final item = EditorItem(
            id: id,
            type: 'text',
            text: text,
            position: importedPosition,
            width: width,
            height: importedHeight,
            scale: safeScale,
            rotation: rotation,
            opacity: opacity,
            fontSize: fontSize,
            color: _parseColor(json['fill']) ?? Colors.black,
            fontFamily: _cleanFontFamily(json['fontFamily']),
          );
          _items.add(item);
          _templateRawObjects[id] = Map<String, dynamic>.from(json);
          _templateFlipX[id] = json['flipX'] == true || scaleX < 0;
          _templateFlipY[id] = json['flipY'] == true || scaleY < 0;

          final charSpacing = _toDouble(json['charSpacing']) ?? 0.0;
          _textLetterSpacing[id] = (fontSize * charSpacing / 1000.0)
              .clamp(-20.0, 50.0)
              .toDouble();
          _textLineSpacing[id] = _effectiveTextLineHeight(
            rawLineHeight: _toDouble(json['lineHeight']) ?? 1.0,
            fontSize: fontSize,
            objectHeight: height,
            text: text,
          );
          _textAlignment[id] = _parseTextAlign(json['textAlign']);
          _textWeight[id] = _parseFontWeight(json['fontWeight']);
          _textStyle[id] = (json['fontStyle']?.toString() == 'italic')
              ? FontStyle.italic
              : FontStyle.normal;
          _textUnderline[id] = json['underline'] == true;
        } else if (type == 'image') {
          final imageUrl = _resolveTemplateSrc(
            json['src']?.toString() ?? '',
            templateUid,
          );
          if (imageUrl.isNotEmpty) {
            final isTemplateBackground = _isTemplateBackgroundObject(
              json,
              canvasWidth: canvasWidth,
              canvasHeight: canvasHeight,
              tolerant: true,
            );

            final imageItem = EditorItem(
              id: id,
              type: 'image',
              contentUrl: imageUrl,
              position: isTemplateBackground ? Offset.zero : importedPosition,
              width: isTemplateBackground ? canvasWidth : width,
              height: isTemplateBackground ? canvasHeight : importedHeight,
              scale: isTemplateBackground ? 1.0 : safeScale,
              rotation: isTemplateBackground ? 0.0 : rotation,
              opacity: opacity,
              isLocal: false,
            );
            _items.add(imageItem);

            if (isTemplateBackground) {
              _templateBackgroundIds.add(id);
            }

            _templateRawObjects[id] = Map<String, dynamic>.from(json);
            _templateFlipX[id] = json['flipX'] == true || scaleX < 0;
            _templateFlipY[id] = json['flipY'] == true || scaleY < 0;
          }
        } else {
          // Shapes, Rect, Path, etc.
          final rawStroke = _parseColor(json['stroke']);
          final rawStrokeWidth = _toDouble(json['strokeWidth']) ?? 0.0;

          final shapeItem = EditorItem(
            id: id,
            type: 'shape',
            text: type,
            position: importedPosition,
            width: width,
            height: importedHeight,
            scale: safeScale,
            rotation: rotation,
            opacity: opacity,
            color: _parseColor(json['fill']),
            outlineColor: rawStroke ?? const Color(0xFFD9D9D9),
            outlineWidth: rawStrokeWidth,
            borderRadius: _toDouble(json['rx']) ?? _toDouble(json['ry']) ?? 16.0,
          );
          _items.add(shapeItem);
          _templateRawObjects[id] = Map<String, dynamic>.from(json);
          _templateFlipX[id] = json['flipX'] == true || scaleX < 0;
          _templateFlipY[id] = json['flipY'] == true || scaleY < 0;
        }
      }

      isTemplateLoaded = true;
      if (appendAsPage) {
        _pages.add(_items.map((e) => e.copyWith()).toList());
        return;
      }

      _pages
        ..clear()
        ..add(_items.map((e) => e.copyWith()).toList());
      _currentPageIndex = 0;
      notifyListeners();
    } catch (e, stackTrace) {
      isTemplateLoaded = false;
      debugPrint('JSON Load Error: $e');
      debugPrint('$stackTrace');
      notifyListeners();
    }
  }

  String _cleanFontFamily(dynamic value) {
    final raw = value?.toString().trim() ?? '';
    if (raw.isEmpty) return 'Roboto';
    final first = raw.split(',').first.trim();
    final cleaned = first.replaceAll(RegExp(r'''^["']|["']$'''), '').trim();
    return cleaned.isEmpty ? 'Roboto' : cleaned;
  }

  double _effectiveTextLineHeight({
    required double rawLineHeight,
    required double fontSize,
    required double objectHeight,
    required String text,
  }) {
    final lineCount = math.max(1, '\n'.allMatches(text).length + 1);
    final raw = rawLineHeight.isFinite && rawLineHeight > 0
        ? rawLineHeight
        : 1.0;
    final measured = fontSize > 0 && objectHeight > 0
        ? objectHeight / (fontSize * lineCount)
        : raw;

    // Some Fabric exports contain an inflated lineHeight. The actual object
    // height is a safer source when it is internally consistent.
    if (measured.isFinite && measured >= 0.7 && measured <= 2.5) {
      return measured.clamp(0.7, 2.5).toDouble();
    }
    return raw.clamp(0.7, 2.5).toDouble();
  }

  String _resolveTemplateSrc(String rawSrc, String? templateUid) {
    final src = rawSrc.trim();
    if (src.isEmpty) return '';

    if (src.startsWith('data:') || src.startsWith('blob:')) {
      return src;
    }

    final uid = (templateUid ?? '').trim();

    // Fabric JSON `src` is the source asset identifier. Admin-uploaded
    // template assets are stored at templates/<uid>/<filename> in S3.
    // Always use the filename from JSON and inject the current template UID.
    String fileName = src;
    try {
      final uri = Uri.tryParse(src);
      if (uri != null && uri.pathSegments.isNotEmpty) {
        fileName = uri.pathSegments.last;
      } else {
        fileName = src.split('/').last;
      }
    } catch (_) {
      fileName = src.split('/').last;
    }

    fileName = fileName.split('?').first.split('#').first.trim();
    try {
      fileName = Uri.decodeComponent(fileName);
    } catch (_) {}
    fileName = fileName.trim();

    final parsedUri = Uri.tryParse(src);
    final isAbsoluteHttp =
        parsedUri != null &&
            (parsedUri.scheme == 'http' || parsedUri.scheme == 'https');
    final isLegacyTemplateHost =
        src.contains('temp-m2b-assets.s3.') || src.contains('amazonaws.com');
    if (isAbsoluteHttp && !isLegacyTemplateHost) {
      return src;
    }

    if (fileName.isEmpty || uid.isEmpty) {
      if (isAbsoluteHttp) return src;
      debugPrint(
        '⚠️ Template image URL could not be resolved. uid=$uid src=$src',
      );
      return '';
    }

    return 'https://temp-m2b-assets.s3.ap-south-1.amazonaws.com/'
        'templates/$uid/$fileName';
  }

  EditorItem _normalizeImportedItem(EditorItem item) {
    if (_isBackgroundLayer(item)) {
      return item.copyWith(position: Offset.zero);
    }

    final safeScale = _maxScaleForFrame(item, item.scale);
    final scaled = item.copyWith(scale: safeScale);
    return scaled.copyWith(
      position: _clampPositionForFrame(scaled, scaled.position),
    );
  }

  // ---------------------------------------------------------------------
  // FABRIC GROUP FLATTENING
  // ---------------------------------------------------------------------
  // A Fabric `group` (Canva-style grouped layers) used to fall into the
  // "unknown type" branch and became ONE grey rectangle, so none of the
  // text / images / shapes inside it were editable. We now expand every
  // group (recursively) into independent layers, applying the group's
  // translate / scale / rotate / flip / opacity to each child.
  List<Map<String, dynamic>> _flattenFabricObjects(
      List<Map<String, dynamic>> input,
      ) {
    final out = <Map<String, dynamic>>[];
    for (final json in input) {
      if (json['visible'] == false) continue; // hidden layers stay hidden

      final type = (json['type']?.toString() ?? '').toLowerCase();
      final children = json['objects'];
      final isContainer =
          (type == 'group' || type == 'activeselection') && children is List;
      if (!isContainer) {
        out.add(json);
        continue;
      }

      final gw = math.max(0.0, _toDouble(json['width']) ?? 0.0);
      final gh = math.max(0.0, _toDouble(json['height']) ?? 0.0);
      final gsx = _toDouble(json['scaleX']) ?? 1.0;
      final gsy = _toDouble(json['scaleY']) ?? 1.0;
      final gAngle = (_toDouble(json['angle']) ?? 0.0) * math.pi / 180.0;
      final gOpacity = (_toDouble(json['opacity']) ?? 1.0).clamp(0.0, 1.0);
      final cosA = math.cos(gAngle);
      final sinA = math.sin(gAngle);
      final gFlipX = json['flipX'] == true ? -1.0 : 1.0;
      final gFlipY = json['flipY'] == true ? -1.0 : 1.0;
      final sx = gsx * gFlipX;
      final sy = gsy * gFlipY;

      Offset rotate(double x, double y) =>
          Offset(x * cosA - y * sinA, x * sinA + y * cosA);

      // Group centre in canvas space (children are stored relative to it).
      final originXName = (json['originX']?.toString() ?? 'left').toLowerCase();
      final originYName = (json['originY']?.toString() ?? 'top').toLowerCase();
      final ox = originXName == 'center'
          ? 0.5
          : (originXName == 'right' ? 1.0 : 0.0);
      final oy = originYName == 'center'
          ? 0.5
          : (originYName == 'bottom' ? 1.0 : 0.0);
      final fromOrigin = rotate(
        (0.5 - ox) * gw * gsx.abs(),
        (0.5 - oy) * gh * gsy.abs(),
      );
      final centre = Offset(
        (_toDouble(json['left']) ?? 0.0) + fromOrigin.dx,
        (_toDouble(json['top']) ?? 0.0) + fromOrigin.dy,
      );

      final flatChildren = <Map<String, dynamic>>[];
      for (final raw in children) {
        if (raw is! Map) continue;
        final child = Map<String, dynamic>.from(raw);
        if (child['visible'] == false) continue;

        final cl = _toDouble(child['left']) ?? 0.0;
        final ct = _toDouble(child['top']) ?? 0.0;
        final p = rotate(cl * sx, ct * sy);

        child['left'] = centre.dx + p.dx;
        child['top'] = centre.dy + p.dy;
        child['scaleX'] = (_toDouble(child['scaleX']) ?? 1.0) * sx;
        child['scaleY'] = (_toDouble(child['scaleY']) ?? 1.0) * sy;
        child['angle'] =
            (_toDouble(child['angle']) ?? 0.0) + (gAngle * 180.0 / math.pi);
        child['opacity'] = ((_toDouble(child['opacity']) ?? 1.0) * gOpacity)
            .clamp(0.0, 1.0);
        flatChildren.add(child);
      }

      // Nested groups are expanded by the recursive call.
      out.addAll(_flattenFabricObjects(flatChildren));
    }
    return out;
  }

  TextAlign _parseTextAlign(dynamic value) {
    switch (value?.toString()) {
      case 'center':
        return TextAlign.center;
      case 'right':
        return TextAlign.right;
      case 'justify':
        return TextAlign.justify;
      default:
        return TextAlign.left;
    }
  }

  FontWeight _parseFontWeight(dynamic value) {
    final weight = int.tryParse(value?.toString() ?? '700') ?? 700;
    return weight >= 700 ? FontWeight.bold : FontWeight.normal;
  }

  String _outlineStyleFromFabric(
      dynamic dashArray, {
        double strokeWidth = 0,
        String? strokeCap,
      }) {
    if (dashArray is! List || dashArray.isEmpty || strokeWidth <= 0) {
      return 'solid';
    }

    final values = dashArray
        .map((e) => _toDouble(e))
        .whereType<double>()
        .where((e) => e >= 0)
        .toList();

    if (values.isEmpty) return 'solid';

    // Fabric dotted borders are commonly represented as [1, gap] or a
    // very small dash. Round caps make those dashes render as real dots.
    final first = values.first;
    if ((strokeCap == 'round' && first <= strokeWidth * 2.0) || first <= 2.0) {
      return first <= strokeWidth ? 'fine_dotted' : 'dotted';
    }
    return 'dashed';
  }

  String _outlineJoinFromFabric(String? join) {
    switch (join) {
      case 'miter':
        return 'miter';
      case 'bevel':
        return 'bevel';
      case 'round':
      default:
        return 'round';
    }
  }

  Gradient? _parseGradient(dynamic fill) {
    if (fill is! Map) return null;

    final type = fill['type']?.toString().toLowerCase();
    final stopsRaw = fill['colorStops'];
    if (stopsRaw is! List || stopsRaw.isEmpty) return null;

    final colors = <Color>[];
    final stops = <double>[];
    for (final raw in stopsRaw) {
      if (raw is! Map) continue;
      final color = _parseColor(raw['color']);
      final offset = _toDouble(raw['offset']);
      if (color != null && offset != null) {
        colors.add(color);
        stops.add(offset.clamp(0.0, 1.0).toDouble());
      }
    }
    if (colors.length < 2) return null;

    if (type == 'linear') {
      return LinearGradient(
        begin: Alignment.centerLeft,
        end: Alignment.centerRight,
        colors: colors,
        stops: stops,
      );
    }

    // Fabric radial gradients used by the admin templates are centered on
    // the page. Radius 1.0 maps the outer stop to the canvas edge.
    return RadialGradient(
      center: Alignment.center,
      radius: 1.0,
      colors: colors,
      stops: stops,
    );
  }

  Color? _parseColor(dynamic fillColor) {
    if (fillColor == null) return null;

    if (fillColor is Color) return fillColor;

    if (fillColor is num) {
      // Fabric can serialize colors as packed ARGB integers.
      final value = fillColor.toInt();
      return Color(value);
    }

    if (fillColor is Map) {
      final value =
          fillColor['color'] ?? fillColor['value'] ?? fillColor['fill'];
      final parsed = _parseColor(value);
      if (parsed != null) return parsed;
    }

    final raw = fillColor.toString().trim();
    if (raw.isEmpty ||
        raw.toLowerCase() == 'transparent' ||
        raw.toLowerCase() == 'none') {
      return Colors.transparent;
    }

    final value = raw.toLowerCase();
    const named = <String, Color>{
      'white': Colors.white,
      'black': Colors.black,
      'red': Colors.red,
      'green': Colors.green,
      'blue': Colors.blue,
      'yellow': Colors.yellow,
      'orange': Colors.orange,
      'grey': Colors.grey,
      'gray': Colors.grey,
    };
    final namedColor = named[value];
    if (namedColor != null) return namedColor;

    // CSS/Fabric colour variants. Accept 0x-prefixed packed values too.
    var hex = value;
    if (hex.startsWith('0x')) hex = hex.substring(2);
    if (hex.startsWith('#')) hex = hex.substring(1);
    if (RegExp(r'^[0-9a-f]{3}$').hasMatch(hex)) {
      hex = hex.split('').map((c) => '$c$c').join();
    }
    if (RegExp(r'^[0-9a-f]{6}$').hasMatch(hex)) {
      return Color(int.parse('FF$hex', radix: 16));
    }
    if (RegExp(r'^[0-9a-f]{8}$').hasMatch(hex)) {
      return Color(int.parse(hex, radix: 16));
    }

    // rgb(...) / rgba(...), including percentage RGB values.
    final rgb = RegExp(
      r'^rgba?\s*\(([^)]+)\)$',
      caseSensitive: false,
    ).firstMatch(value);
    if (rgb != null) {
      try {
        final parts = rgb.group(1)!.split(',').map((e) => e.trim()).toList();
        if (parts.length >= 3) {
          double channel(String s) {
            if (s.endsWith('%')) {
              return (double.parse(s.substring(0, s.length - 1)) * 2.55);
            }
            return double.parse(s);
          }

          final r = channel(parts[0]).round().clamp(0, 255);
          final g = channel(parts[1]).round().clamp(0, 255);
          final b = channel(parts[2]).round().clamp(0, 255);
          var a = 1.0;
          if (parts.length >= 4) {
            a = parts[3].endsWith('%')
                ? double.parse(parts[3].substring(0, parts[3].length - 1)) / 100
                : double.parse(parts[3]);
          }
          return Color.fromRGBO(r, g, b, a.clamp(0.0, 1.0));
        }
      } catch (_) {}
    }

    // Never silently turn an unknown/missing template color into black.
    return null;
  }

  void addText({String initialText = "New Text"}) {
    _saveState();
    final textId = DateTime.now().millisecondsSinceEpoch.toString();
    _items.add(
      EditorItem(
        id: textId,
        type: 'text',
        text: initialText,
        position: const Offset(120, 200),
        // Manual text starts at 100, matching the editor's default text size.
        fontSize: 100.0,
        width: 600,
        height: 180,
        color: Colors.black87,
      ),
    );
    // New text must use exactly the same selection/transform system as
    // template text, images, shapes and stickers.
    selectedItemType = 'text';
    selectedItemId = textId;
    _saveState();
    notifyListeners();
  }

  void addEmoji(String emojiText) {
    addText(initialText: emojiText);
  }

  /// Add a Freepik asset as a selectable group.
  ///
  /// The API currently returns PNG thumbnails for many assets (`free_svg:
  /// false`). We still create a `svg_group`/group-like item so the same
  /// toolbar is shown. If an SVG payload is available it is used directly;
  /// otherwise the PNG is kept as the group's source and can be split into
  /// raster child elements when the user presses UNGROUP ELEMENTS.
  void addFreePikElement(String thumbnailUrl) {
    debugPrint('Sticker URL: $thumbnailUrl');

    final uri = Uri.tryParse(thumbnailUrl);
    final path = uri?.path.toLowerCase() ?? '';

    final isRasterImage = path.endsWith('.png') ||
        path.endsWith('.jpg') ||
        path.endsWith('.jpeg') ||
        path.endsWith('.webp');

    final svg = isRasterImage
        ? null
        : FreePikService.svgForThumbnail(thumbnailUrl);

    debugPrint('Is raster image: $isRasterImage');
    debugPrint('SVG available: ${svg != null}');

    _saveState();

    final id = 'element_${DateTime.now().microsecondsSinceEpoch}';

    _items.add(
      EditorItem(
        id: id,
        type: isRasterImage ? 'image' : 'svg_group',
        contentUrl: isRasterImage
            ? thumbnailUrl
            : (svg != null && svg.trim().isNotEmpty
            ? svg
            : thumbnailUrl),
        position: const Offset(100, 150),
        width: 220,
        height: 220,
        isLocal: false,
        text: isRasterImage
            ? 'image'
            : (svg != null && svg.trim().isNotEmpty
            ? 'svg_group'
            : 'raster_group'),
      ),
    );

    selectedItemType = isRasterImage ? 'image' : 'svg_group';
    selectedItemId = id;

    notifyListeners();
  }

  /// Ungroups the SVG into individual drawable SVG elements. Every fragment
  /// keeps the original viewBox and group transforms, so all pieces retain
  /// their original positions when they become separate editor items.
  Future<void> ungroupSvgElement(String groupId) async {
    final index = _items.indexWhere((e) => e.id == groupId);
    if (index == -1) return;
    final group = _items[index];
    if (group.type != 'svg_group') return;

    final source = group.contentUrl ?? '';
    final isSvg = source.trimLeft().startsWith('<svg');

    if (isSvg) {
      final fragments = _extractSvgLeafFragments(source);
      if (fragments.isEmpty) return;

      _saveState();
      _items.removeAt(index);

      final created = <EditorItem>[];
      for (var i = 0; i < fragments.length; i++) {
        created.add(
          EditorItem(
            id: 'svg_${DateTime.now().microsecondsSinceEpoch}_$i',
            type: 'svg_element',
            contentUrl: fragments[i],
            position: group.position,
            width: group.width,
            height: group.height,
            scale: group.scale,
            rotation: group.rotation,
            opacity: group.opacity,
            isLocal: false,
          ),
        );
      }

      _items.insertAll(index, created);
      selectedItemId = created.first.id;
      selectedItemType = 'svg_element';
      notifyListeners();
      return;
    }

    await _ungroupRasterGroup(index, group);
  }

  Future<void> _ungroupRasterGroup(int index, EditorItem group) async {
    final source = group.contentUrl ?? '';
    if (source.isEmpty) return;

    try {
      final bytes = await _readImageBytes(source, group.isLocal);
      if (bytes == null || bytes.isEmpty) return;

      final codec = await ui.instantiateImageCodec(bytes);
      final frame = await codec.getNextFrame();
      final image = frame.image;
      final width = image.width;
      final height = image.height;
      final raw = await image.toByteData(format: ui.ImageByteFormat.rawRgba);
      if (raw == null) return;

      final rgba = raw.buffer.asUint8List();
      final boxes = _findAlphaComponents(rgba, width, height);
      image.dispose();
      codec.dispose();

      if (boxes.isEmpty) return;

      _saveState();
      _items.removeAt(index);

      final tempDir = await getTemporaryDirectory();
      final created = <EditorItem>[];
      var componentIndex = 0;

      for (final box in boxes) {
        final cropBytes = await _cropImageToPng(bytes, box);
        if (cropBytes == null || cropBytes.isEmpty) continue;

        final file = File(
          '${tempDir.path}/ungroup_${DateTime.now().microsecondsSinceEpoch}_${componentIndex++}.png',
        );
        await file.writeAsBytes(cropBytes, flush: true);

        final relX = box.left / width;
        final relY = box.top / height;
        final relW = box.width / width;
        final relH = box.height / height;

        created.add(
          EditorItem(
            id: 'raster_${DateTime.now().microsecondsSinceEpoch}_${created.length}',
            type: 'image',
            contentUrl: file.path,
            position: Offset(
              group.position.dx + group.width * relX,
              group.position.dy + group.height * relY,
            ),
            width: group.width * relW,
            height: group.height * relH,
            scale: group.scale,
            rotation: group.rotation,
            opacity: group.opacity,
            isLocal: true,
            text: 'rounded',
          ),
        );
      }

      if (created.isEmpty) {
        _items.insert(index, group);
        return;
      }

      _items.insertAll(index, created);
      selectedItemId = created.first.id;
      selectedItemType = 'image';
      notifyListeners();
    } catch (e) {
      debugPrint('Raster ungroup failed: $e');
    }
  }

  Future<Uint8List?> _readImageBytes(String source, bool isLocal) async {
    try {
      if (isLocal || source.startsWith('/') || source.startsWith('file://')) {
        return await File(source.replaceFirst('file://', '')).readAsBytes();
      }
      final response = await HttpClient()
          .getUrl(Uri.parse(source))
          .then((r) => r.close());
      if (response.statusCode != 200) return null;
      final chunks = <int>[];
      await for (final chunk in response) {
        chunks.addAll(chunk);
      }
      return Uint8List.fromList(chunks);
    } catch (e) {
      debugPrint('Image bytes load failed: $e');
      return null;
    }
  }

  List<ui.Rect> _findAlphaComponents(Uint8List rgba, int width, int height) {
    final pixelCount = width * height;
    final visited = Uint8List(pixelCount);
    final boxes = <ui.Rect>[];
    const alphaThreshold = 12;
    const minPixels = 8;

    final queue = List<int>.filled(pixelCount, 0);

    for (var start = 0; start < pixelCount; start++) {
      if (visited[start] != 0) continue;
      final alpha = rgba[start * 4 + 3];
      if (alpha < alphaThreshold) {
        visited[start] = 1;
        continue;
      }

      var head = 0;
      var tail = 0;
      queue[tail++] = start;
      visited[start] = 1;

      var minX = start % width;
      var maxX = minX;
      var minY = start ~/ width;
      var maxY = minY;
      var count = 0;

      while (head < tail) {
        final p = queue[head++];
        final x = p % width;
        final y = p ~/ width;
        count++;
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;

        void visit(int nx, int ny) {
          if (nx < 0 || nx >= width || ny < 0 || ny >= height) return;
          final n = ny * width + nx;
          if (visited[n] != 0) return;
          visited[n] = 1;
          if (rgba[n * 4 + 3] >= alphaThreshold) queue[tail++] = n;
        }

        visit(x - 1, y);
        visit(x + 1, y);
        visit(x, y - 1);
        visit(x, y + 1);
      }

      if (count >= minPixels) {
        boxes.add(
          ui.Rect.fromLTRB(
            minX.toDouble(),
            minY.toDouble(),
            (maxX + 1).toDouble(),
            (maxY + 1).toDouble(),
          ),
        );
      }
    }

    boxes.sort((a, b) => (a.top + a.left).compareTo(b.top + b.left));
    return boxes;
  }

  Future<Uint8List?> _cropImageToPng(Uint8List source, ui.Rect box) async {
    try {
      final codec = await ui.instantiateImageCodec(source);
      final frame = await codec.getNextFrame();
      final image = frame.image;
      final recorder = ui.PictureRecorder();
      final canvas = Canvas(recorder);
      final dst = ui.Rect.fromLTWH(0, 0, box.width, box.height);
      canvas.drawImageRect(image, box, dst, Paint());
      final picture = recorder.endRecording();
      final cropped = await picture.toImage(
        box.width.ceil(),
        box.height.ceil(),
      );
      final data = await cropped.toByteData(format: ui.ImageByteFormat.png);
      image.dispose();
      cropped.dispose();
      codec.dispose();
      return data?.buffer.asUint8List();
    } catch (e) {
      debugPrint('Image crop failed: $e');
      return null;
    }
  }

  List<String> _extractSvgLeafFragments(String source) {
    final svgMatch = RegExp(
      r'''<svg\b([^>]*)>''',
      caseSensitive: false,
    ).firstMatch(source);
    final attrs = svgMatch?.group(1) ?? '';
    final viewBox =
        RegExp(
          r'''\bviewBox\s*=\s*["']([^"']+)["']''',
          caseSensitive: false,
        ).firstMatch(attrs)?.group(1) ??
            '0 0 512 512';

    final root = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="$viewBox">';
    final tokens = RegExp(
      r'<[^>]+>',
      multiLine: true,
    ).allMatches(source).toList();
    final groups = <String>[];
    final fragments = <String>[];
    const drawable = <String>{
      'path',
      'rect',
      'circle',
      'ellipse',
      'polygon',
      'polyline',
      'line',
      'text',
      'image',
      'use',
    };

    for (final token in tokens) {
      final tag = token.group(0) ?? '';
      final closing = RegExp(r'</\s*([A-Za-z0-9:_-]+)\s*>').firstMatch(tag);
      if (closing != null) {
        if (closing.group(1)!.toLowerCase() == 'g' && groups.isNotEmpty) {
          groups.removeLast();
        }
        continue;
      }

      final opening = RegExp(r'<\s*([A-Za-z0-9:_-]+)\b').firstMatch(tag);
      if (opening == null) continue;
      final name = opening.group(1)!.toLowerCase();

      if (name == 'g') {
        if (!tag.trimRight().endsWith('/>')) groups.add(tag);
        continue;
      }

      if (!drawable.contains(name)) continue;

      final out = StringBuffer(root);
      for (final parent in groups) out.write(parent);
      out.write(tag);
      if (!tag.trimRight().endsWith('/>')) {
        final endTag = '</$name>';
        final after = source.substring(token.end);
        final end = after.toLowerCase().indexOf(endTag.toLowerCase());
        if (end >= 0) out.write(after.substring(0, end + endTag.length));
      }
      out.write('</svg>');
      fragments.add(out.toString());
    }
    return fragments;
  }

  void addShape(String url, {bool isLocal = false}) {
    addImage(url, isLocal: isLocal);
  }

  void addImage(String url, {bool isLocal = false}) {
    final value = url.trim();
    if (value.isEmpty) return;

    _saveState();

    final imageId = 'image_${DateTime.now().microsecondsSinceEpoch}';

    _items.add(
      EditorItem(
        id: imageId,
        type: 'image',
        contentUrl: value,
        position: const Offset(100, 150),
        width: 220,
        height: 220,
        isLocal: isLocal,
      ),
    );

    selectedItemType = 'image';
    selectedItemId = imageId;

    _saveState();
    notifyListeners();
  }
  void addVideo(
      String videoUrl, {
        bool isLocal = false,
        double width = 600,
        double height = 400,
      }) {
    if (videoUrl.trim().isEmpty) return;

    _saveState();

    final videoItem = EditorItem(
      id: "video_${DateTime.now().millisecondsSinceEpoch}",
      type: "video",
      contentUrl: videoUrl,
      position: const Offset(100, 100),
      width: width,
      height: height,
      isLocal: isLocal,
    );

    _items.add(videoItem);

    selectedItemType = "video";
    selectedItemId = videoItem.id;

    notifyListeners();
  }

  void updatePosition(String id, Offset newPos) {
    final index = _items.indexWhere((e) => e.id == id);
    if (index == -1) return;

    final item = _items[index];

    // Position is intentionally not hard-clamped here. The interactive
    // canvas calculates the valid drag range in canvas coordinates. A second
    // provider-level clamp caused the element to fight the finger, especially
    // after scaling/rotation.
    final safePosition = newPos;

    _items[index] = item.copyWith(
      position: _isBackgroundLayer(item) ? Offset.zero : safePosition,
    );
    notifyListeners();
  }

  void updateRotation(String id, double rot) {
    final index = _items.indexWhere((e) => e.id == id);
    if (index == -1 || !rot.isFinite) return;

    // Rotation must update only the angle. Re-fitting the rotated bounding
    // box on every pointer move changes scale and clamps position, which makes
    // image layers shrink and jump away from where the user placed them.
    _saveState();
    final current = _items[index];
    _items[index] = current.copyWith(
      rotation: rot,
      position: _isBackgroundLayer(current) ? Offset.zero : current.position,
      scale: current.scale,
      width: current.width,
      height: current.height,
    );
    notifyListeners();
  }

  void updateScale(String id, double scl) {
    final index = _items.indexWhere((e) => e.id == id);
    if (index == -1) return;

    _saveState();

    final current = _items[index];
    final requested = scl.isFinite ? scl : current.scale;
    final safeScale = _maxScaleForFrame(current, requested);

    final scaled = current.copyWith(scale: safeScale);
    _items[index] = scaled.copyWith(
      position: _clampPositionForFrame(scaled, scaled.position),
    );
    notifyListeners();
  }

  /// Updates the selected text's font size.
  /// Keeps the value finite and within a practical editor range.
  void updateFontSize(String id, double newSize) {
    final index = _items.indexWhere((e) => e.id == id);
    if (index == -1) return;

    final safeSize = newSize.isFinite
        ? newSize.clamp(8.0, 300.0).toDouble()
        : _items[index].fontSize;

    if ((_items[index].fontSize - safeSize).abs() < 0.01) return;

    _saveState();
    _items[index] = _items[index].copyWith(fontSize: safeSize);
    notifyListeners();
  }

  void updateOpacity(String id, double op) {
    int index = _items.indexWhere((e) => e.id == id);
    if (index != -1) {
      _saveState();
      _items[index] = _items[index].copyWith(opacity: op);
      notifyListeners();
    }
  }

  void updateTextContent(String id, String newText) {
    int index = _items.indexWhere((e) => e.id == id);
    if (index != -1) {
      _saveState();
      _items[index] = _items[index].copyWith(text: newText);
      _syncCurrentPage();
      notifyListeners();
    }
  }

  void setImageFilter(String id, String filterName) {
    final index = _items.indexWhere((e) => e.id == id);
    if (index != -1) {
      _saveState();
      _items[index] = _items[index].copyWith(filterType: filterName);
      _syncCurrentPage();
      notifyListeners();
    }
  }

  void updateImageColorAdjustments(
      String id, {
        double? brightness,
        double? contrast,
        double? saturation,
      }) {
    final index = _items.indexWhere((e) => e.id == id);
    if (index != -1) {
      _saveState();
      _items[index] = _items[index].copyWith(
        brightness: brightness ?? _items[index].brightness,
        contrast: contrast ?? _items[index].contrast,
        saturation: saturation ?? _items[index].saturation,
      );
      notifyListeners();
    }
  }

  void regenerateImageWithAi(String id, String prompt) {
    int index = _items.indexWhere((e) => e.id == id);
    if (index != -1) {
      _saveState();
      String encodedPrompt = Uri.encodeComponent(prompt);
      int seed = DateTime.now().millisecondsSinceEpoch % 10000;
      String aiImageUrl =
          "https://image.pollinations.ai/prompt/$encodedPrompt?seed=$seed&nologo=true";

      _items[index] = _items[index].copyWith(
        contentUrl: aiImageUrl,
        isLocal: false,
      );
      notifyListeners();
    }
  }

  Color textColor(String id) {
    final index = _items.indexWhere((e) => e.id == id);
    if (index == -1) return Colors.white;
    return _items[index].color ?? Colors.white;
  }

  void updateTextColor(String id, Color newColor) {
    int index = _items.indexWhere((e) => e.id == id);
    if (index != -1) {
      _saveState();
      _items[index] = _items[index].copyWith(color: newColor);
      notifyListeners();
    }
  }

  void setImageShape(String id, String shape, {double radius = 16.0}) {
    int index = _items.indexWhere((e) => e.id == id);
    if (index != -1) {
      _saveState();
      _items[index] = _items[index].copyWith(text: shape, borderRadius: radius);
      notifyListeners();
    }
  }

  void updateShapeFill(String id, Color color) {
    final index = _items.indexWhere((e) => e.id == id);
    if (index == -1) return;
    _saveState();
    final item = _items[index];
    _items[index] = item.copyWith(color: color);
    final raw = _templateRawObjects[id];
    if (raw != null) {
      raw['fill'] = colorToHex(color);
    }
    notifyListeners();
  }

  void updateOutline(String id, double width, Color color) {
    int index = _items.indexWhere((e) => e.id == id);
    if (index != -1) {
      _saveState();
      _items[index] = _items[index].copyWith(
        outlineWidth: width,
        outlineColor: color,
      );
      final raw = _templateRawObjects[id];
      if (raw != null) {
        raw['stroke'] = colorToHex(color);
        raw['strokeWidth'] = width;
      }
      notifyListeners();
    }
  }

  void bringToFront(String id) {
    int index = _items.indexWhere((e) => e.id == id);
    if (index != -1) {
      _saveState();
      EditorItem item = _items.removeAt(index);
      _items.add(item);
      notifyListeners();
    }
  }

  void sendToBack(String id) {
    int index = _items.indexWhere((e) => e.id == id);
    if (index != -1) {
      _saveState();
      EditorItem item = _items.removeAt(index);
      _items.insert(0, item);
      notifyListeners();
    }
  }

  void duplicateItem(String id) {
    _saveState();
    int index = _items.indexWhere((e) => e.id == id);
    if (index != -1) {
      final sourceId = _items[index].id ?? '';
      final newId = DateTime.now().millisecondsSinceEpoch.toString();
      EditorItem newItem = _items[index].copyWith(
        id: newId,
        position: _items[index].position + const Offset(20, 20),
      );
      _items.add(newItem);
      final outline = _outlineStyles[sourceId];
      if (outline != null) _outlineStyles[newId] = outline;
      final join = _outlineJoins[sourceId];
      if (join != null) _outlineJoins[newId] = join;
      notifyListeners();
    }
  }

  void removeItem(String id) {
    final index = _items.indexWhere((e) => e.id == id);
    if (index == -1) return;

    _saveState();
    _items.removeAt(index);

    if (selectedItemId == id) {
      selectedItemId = null;
      selectedItemType = null;
    }

    notifyListeners();
  }

  /// Exportable JSON for the current editor page.
  /// This intentionally keeps the existing EditorItem model untouched.
  Map<String, dynamic> exportCurrentPageJson() {
    String colorToHex(Color? color) {
      if (color == null) return '#FFFFFFFF';
      return '#${color.toARGB32().toRadixString(16).padLeft(8, '0').toUpperCase()}';
    }

    return {
      'version': 1,
      'page': currentPageIndex + 1,
      'backgroundColor': colorToHex(_backgroundColor),
      'music': _selectedMusicPath == null
          ? null
          : {'title': _selectedMusicTitle, 'localPath': _selectedMusicPath},
      'items': _items.map((item) {
        final id = item.id ?? '';
        return {
          'id': id,
          'type': item.type,
          'text': item.text,
          'contentUrl': item.contentUrl,
          'isLocal': item.isLocal,
          'left': item.position.dx,
          'top': item.position.dy,
          'width': item.width,
          'height': item.height,
          'scale': item.scale,
          'rotation': item.rotation,
          'opacity': item.opacity,
          'fontSize': item.fontSize,
          'fontFamily': item.fontFamily,
          'color': colorToHex(item.color),
          'filterType': item.filterType,
          'brightness': item.brightness,
          'contrast': item.contrast,
          'saturation': item.saturation,
          'borderRadius': item.borderRadius,
          'outlineWidth': item.outlineWidth,
          'outlineColor': colorToHex(item.outlineColor),
          'outlineStyle': outlineStyle(id),
          'outlineJoin': outlineJoin(id),
          'textFormatting': {
            'letterSpacing': textLetterSpacing(id),
            'lineSpacing': textLineSpacing(id),
            'alignment': textAlignment(id).name,
            'fontWeight': textWeight(id).value,
            'fontStyle': textStyle(id).name,
            'underline': textUnderline(id),
          },
        };
      }).toList(),
    };
  }

  void undo() {
    if (_historyIndex <= 0) return;

    _historyIndex--;

    _items
      ..clear()
      ..addAll(_history[_historyIndex].map((e) => e.copyWith()));

    notifyListeners();
  }

  void redo() {
    if (_historyIndex < _history.length - 1) {
      _historyIndex++;
      _items.clear();
      _items.addAll(_history[_historyIndex].map((e) => e.copyWith()));
      notifyListeners();
    }
  }

  bool _isDisposed = false;

  @override
  void dispose() {
    _isDisposed = true;
    super.dispose();
  }

  @override
  void notifyListeners() {
    if (_isDisposed) return;
    super.notifyListeners();
  }

  Future<void> fetchFreePikAssets(String query) async {
    final normalized = query.trim();

    if (normalized.isEmpty || _isDisposed) {
      return;
    }

    final requestId = (_elementCategoryRequestIds['__generic__'] ?? 0) + 1;

    _elementCategoryRequestIds['__generic__'] = requestId;

    if (_isDisposed) return;

    isFreePikLoading = true;
    freePikAssets = <String>[];

    if (!_isDisposed) {
      notifyListeners();
    }

    try {
      final result = await FreePikService.searchAssets(
        normalized,
        page: 1,
        limit: 30,
      ).timeout(const Duration(seconds: 20), onTimeout: () => <String>[]);
      if (_isDisposed ||
          _elementCategoryRequestIds['__generic__'] != requestId) {
        return;
      }

      freePikAssets = result.toSet().toList();
    } catch (e) {
      debugPrint("Error fetching assets: $e");

      if (_isDisposed ||
          _elementCategoryRequestIds['__generic__'] != requestId) {
        return;
      }

      freePikAssets = <String>[];
    } finally {
      if (_isDisposed ||
          _elementCategoryRequestIds['__generic__'] != requestId) {
        return;
      }

      isFreePikLoading = false;
      notifyListeners();
    }
  }

  Future<void> fetchFreePikStickers(String query) async {
    final normalized = query.trim();

    final requestId = (_elementCategoryRequestIds['__stickers__'] ?? 0) + 1;
    _elementCategoryRequestIds['__stickers__'] = requestId;

    isStickersLoading = true;
    freePikStickers = <String>[];
    notifyListeners();

    try {
      // IMPORTANT:
      // Use the dedicated /api/freepik/stickers endpoint.
      // Do NOT append "stickers" to the search term; that was causing
      // requests such as "stickers stickers".
      final result = await FreePikService.searchStickers(
        term: normalized.isEmpty || normalized == 'stickers'
            ? null
            : normalized,
        page: 1,
        perPage: 30,
      ).timeout(const Duration(seconds: 20), onTimeout: () => <String>[]);

      if (_elementCategoryRequestIds['__stickers__'] == requestId) {
        freePikStickers = result.toSet().toList();
      }
    } catch (e) {
      debugPrint("Error fetching stickers: $e");
      if (_elementCategoryRequestIds['__stickers__'] == requestId) {
        freePikStickers = <String>[];
      }
    } finally {
      if (_elementCategoryRequestIds['__stickers__'] == requestId) {
        isStickersLoading = false;
        notifyListeners();
      }
    }
  }

  void updateImageContent(String id, String newUrl) {
    int index = _items.indexWhere((e) => e.id == id);
    if (index != -1) {
      _saveState();
      _items[index] = _items[index].copyWith(
        contentUrl: newUrl,
        isLocal: !newUrl.startsWith('http'),
      );
      notifyListeners();
    }
  }

  void updateFontFamily(String itemId, String fontFamily) {
    final index = _items.indexWhere((e) => e.id == itemId);
    if (index == -1) return;

    final safeFont = fontFamily.trim();
    if (safeFont.isEmpty) return;

    if ((_items[index].fontFamily ?? '').trim() == safeFont) {
      return;
    }

    _saveState();

    // Use copyWith so the whole editor item is replaced. This guarantees
    // EditableItemWidget rebuilds immediately and the selected font is also
    // preserved by page/history/export state.
    _items[index] = _items[index].copyWith(fontFamily: safeFont);

    _syncCurrentPage();
    notifyListeners();
  }

  void updateFilter(String itemId, String filterType) {
    final index = items.indexWhere((e) => e.id == itemId);
    if (index != -1) {
      items[index] = items[index].copyWith(filterType: filterType);
      notifyListeners();
    }
  }

  void updateBrightness(String itemId, double value) {
    final index = items.indexWhere((e) => e.id == itemId);
    if (index != -1) {
      items[index] = items[index].copyWith(brightness: value);
      notifyListeners();
    }
  }

  void updateBorderRadius(String itemId, double radius) {
    final index = items.indexWhere((e) => e.id == itemId);
    if (index == -1) return;

    _saveState();
    items[index] = items[index].copyWith(
      borderRadius: radius.clamp(0.0, 500.0),
    );
    notifyListeners();
  }

  void updateImageShape(String id, String shape) {
    final index = items.indexWhere((e) => e.id == id);
    if (index == -1) return;

    _saveState();
    final radius = items[index].borderRadius;
    items[index] = items[index].copyWith(text: shape, borderRadius: radius);
    _syncCurrentPage();
    notifyListeners();
  }

  void updateSize(String id, double width, double height) {
    final index = items.indexWhere((e) => e.id == id);
    if (index == -1) return;

    _saveState();
    final current = items[index];
    items[index] = current.copyWith(
      width: width.isFinite
          ? width.clamp(20.0, 10000.0).toDouble()
          : current.width,
      height: height.isFinite
          ? height.clamp(20.0, 10000.0).toDouble()
          : current.height,
    );
    notifyListeners();
  }

  /// Updates the editor object's layout dimensions without changing its
  /// scale. This is the resize model used by the interactive selection box:
  /// each handle changes the corresponding width/height and the opposite
  /// edge/corner stays anchored.
  void updateItemSize(
      String id, {
        required double width,
        required double height,
        Offset? position,
      }) {
    final index = _items.indexWhere((e) => e.id == id);
    if (index == -1) return;

    final current = _items[index];
    final safeWidth = width.isFinite
        ? width.clamp(20.0, 10000.0).toDouble()
        : current.width;
    final safeHeight = height.isFinite
        ? height.clamp(20.0, 10000.0).toDouble()
        : current.height;

    _items[index] = current.copyWith(
      width: safeWidth,
      height: safeHeight,
      position: position ?? current.position,
    );
    notifyListeners();
  }

  void updateCroppedImage(String id, String newImagePath) {
    int index = _items.indexWhere((e) => e.id == id);
    if (index != -1) {
      _saveState();
      _items[index] = _items[index].copyWith(
        contentUrl: newImagePath,
        isLocal: true,
      );
      notifyListeners();
    }
  }

  List<PexelsVideoAsset> _pexelsVideoAssets = [];
  List<PexelsVideoAsset> get pexelsVideoAssets => _pexelsVideoAssets;

  // Kept for existing callers.
  List<String> get freePikVideos =>
      _pexelsVideoAssets.map((e) => e.videoUrl).toList();

  final bool _isVideoLoading = false;
  bool get isVideoLoading => _isVideoLoading;

  bool _isVideosLoading = false;
  bool get isVideosLoading => _isVideosLoading;

  Future<void> fetchFreePikVideos(String query) async {
    if (_isVideosLoading) return;

    _isVideosLoading = true;
    notifyListeners();

    try {
      final searchQuery = query.trim().isEmpty ? "background" : query.trim();

      debugPrint("Searching Pexels videos: $searchQuery");

      _pexelsVideoAssets =
      await FreePikService.searchPexelsVideoAssets(
        searchQuery,
        page: 1,
        limit: 24,
      ).timeout(
        const Duration(seconds: 15),
        onTimeout: () {
          debugPrint("Pexels video search timeout");
          return <PexelsVideoAsset>[];
        },
      );

      debugPrint("Pexels videos found: ${_pexelsVideoAssets.length}");
    } catch (e, stackTrace) {
      debugPrint("Fetch Freepik Videos Error: $e");
      debugPrint("$stackTrace");

      _pexelsVideoAssets = [];
    } finally {
      _isVideosLoading = false;
      notifyListeners();
    }
  }

  void setBackgroundImage(
      String imageUrl, {
        double canvasWidth = 1080.0,
        double canvasHeight = 1080.0,
        double? sourceWidth,
        double? sourceHeight,
      }) {
    _saveState();
    _removeBackgroundLayers();
    _backgroundColor = Colors.transparent;

    final bgId = 'bg_${DateTime.now().millisecondsSinceEpoch}';
    // Backgrounds are always anchored to the CURRENT editor canvas.
    // The source bitmap is rendered with BoxFit.cover, so every background
    // fills the full 1080x1350 default canvas (or the API template size).
    _items.insert(
      0,
      EditorItem(
        id: bgId,
        type: 'image',
        position: Offset.zero,
        width: canvasWidth,
        height: canvasHeight,
        scale: 1.0,
        contentUrl: imageUrl,
        isLocal: !imageUrl.startsWith('http'),
      ),
    );

    selectedItemType = 'image';
    selectedItemId = bgId;
    _syncCurrentPage();
    notifyListeners();
  }

  void setBackgroundVideo(
      String videoUrl, {
        double canvasWidth = 1080.0,
        double canvasHeight = 1080.0,
        double? sourceWidth,
        double? sourceHeight,
      }) {
    _saveState();
    _removeBackgroundLayers();
    _backgroundColor = Colors.transparent;

    final bgId = 'bg_video_${DateTime.now().millisecondsSinceEpoch}';
    final sw = (sourceWidth != null && sourceWidth.isFinite && sourceWidth > 0)
        ? sourceWidth
        : canvasWidth;
    final sh =
    (sourceHeight != null && sourceHeight.isFinite && sourceHeight > 0)
        ? sourceHeight
        : canvasHeight;

    final coverScale = math.max(canvasWidth / sw, canvasHeight / sh);
    final safeScale = coverScale.isFinite && coverScale > 0 ? coverScale : 1.0;
    final renderedWidth = sw * safeScale;
    final renderedHeight = sh * safeScale;
    final left = (canvasWidth - renderedWidth) / 2.0;
    final top = (canvasHeight - renderedHeight) / 2.0;

    _items.insert(
      0,
      EditorItem(
        id: bgId,
        type: 'video',
        position: Offset(left, top),
        width: sw,
        height: sh,
        scale: safeScale,
        contentUrl: videoUrl,
        isLocal: !videoUrl.startsWith('http'),
      ),
    );

    selectedItemType = 'video';
    selectedItemId = bgId;
    _syncCurrentPage();
    notifyListeners();
  }

  Color get backgroundColor => _backgroundColor;

  String? get backgroundImageUrl {
    final bgItem = _items.firstWhere(
          (item) =>
      item.position.dx == 0 &&
          item.position.dy == 0 &&
          item.type == 'image',
      orElse: () => EditorItem(id: '', type: '', position: Offset.zero),
    );
    return bgItem.contentUrl;
  }

  String? get backgroundVideoUrl {
    final bgItem = _items.firstWhere(
          (item) =>
      item.position.dx == 0 &&
          item.position.dy == 0 &&
          item.type == 'video',
      orElse: () => EditorItem(id: '', type: '', position: Offset.zero),
    );
    return bgItem.contentUrl;
  }

  void replaceBackgroundImage(
      String imageUrl,
      String selectedItemIdToRemove, {
        double canvasWidth = 1080.0,
        double canvasHeight = 1350.0,
        double? sourceWidth,
        double? sourceHeight,
      }) {
    _saveState();
    _removeBackgroundLayers();
    _items.removeWhere((item) => item.id == selectedItemIdToRemove);
    _backgroundColor = Colors.transparent;

    final bgId = 'bg_${DateTime.now().millisecondsSinceEpoch}';
    // Keep the background layer exactly the current canvas size.
    // The renderer uses BoxFit.cover, so sourceWidth/sourceHeight never
    // shrink the background layer itself.
    _items.insert(
      0,
      EditorItem(
        id: bgId,
        type: 'image',
        position: Offset.zero,
        width: canvasWidth,
        height: canvasHeight,
        scale: 1.0,
        rotation: 0.0,
        contentUrl: imageUrl,
        isLocal: !imageUrl.startsWith('http'),
      ),
    );

    selectedItemType = 'image';
    selectedItemId = bgId;
    _syncCurrentPage();
    notifyListeners();
  }

  final Map<String, double> _imageFilterIntensity = {};
  final Map<String, double> _imageTint = {};
  final Map<String, double> _imageBlur = {};

  double imageFilterIntensity(String id) => _imageFilterIntensity[id] ?? 1.0;
  double imageTint(String id) => _imageTint[id] ?? 0.0;
  double imageBlur(String id) => _imageBlur[id] ?? 0.0;

  void updateImageFilterIntensity(String id, double value) {
    _saveState();
    _imageFilterIntensity[id] = value.clamp(0.0, 1.0);
    _syncCurrentPage();
    notifyListeners();
  }

  void updateImageTint(String id, double value) {
    _saveState();
    _imageTint[id] = value.clamp(-100.0, 100.0);
    _syncCurrentPage();
    notifyListeners();
  }

  void updateImageBlur(String id, double value) {
    _saveState();
    _imageBlur[id] = value.clamp(0.0, 20.0);
    _syncCurrentPage();
    notifyListeners();
  }

  final Map<String, bool> _imageFlipX = {};
  final Map<String, bool> _imageFlipY = {};

  bool isImageFlippedX(String id) => _imageFlipX[id] ?? false;
  bool isImageFlippedY(String id) => _imageFlipY[id] ?? false;

  void flipImageHorizontal(String id) {
    if (id.isEmpty) return;
    _saveState();
    // The renderer uses templateFlipX/FlipY for both API and user-added
    // images. Toggle the same state used by the actual paint layer.
    _templateFlipX[id] = !(_templateFlipX[id] ?? false);
    _imageFlipX[id] = _templateFlipX[id]!;
    _syncCurrentPage();
    notifyListeners();
  }

  void flipImageVertical(String id) {
    if (id.isEmpty) return;
    _saveState();
    // Keep vertical flip in the same state consumed by the renderer.
    _templateFlipY[id] = !(_templateFlipY[id] ?? false);
    _imageFlipY[id] = _templateFlipY[id]!;
    _syncCurrentPage();
    notifyListeners();
  }

  bool _isTemplateBackgroundObject(
      Map<String, dynamic> json, {
        double? canvasWidth,
        double? canvasHeight,
        bool tolerant = false,
      }) {
    final type = json['type']?.toString().toLowerCase().trim();
    if (type != 'image') return false;

    final left = _toDouble(json['left']) ?? 0.0;
    final top = _toDouble(json['top']) ?? 0.0;
    final width = _toDouble(json['width']) ?? 0.0;
    final height = _toDouble(json['height']) ?? 0.0;
    final scaleX = (_toDouble(json['scaleX']) ?? 1.0).abs();
    final scaleY = (_toDouble(json['scaleY']) ?? 1.0).abs();

    if (width <= 0 || height <= 0) return false;

    final cw = (canvasWidth != null && canvasWidth > 0)
        ? canvasWidth
        : this.canvasWidth;
    final ch = (canvasHeight != null && canvasHeight > 0)
        ? canvasHeight
        : this.canvasHeight;

    final renderedWidth = width * scaleX;
    final renderedHeight = height * scaleY;

    final originTolerance = tolerant ? 12.0 : 2.0;
    final coverageRatio = tolerant ? 0.82 : 0.995;

    final atOrigin =
        left.abs() <= originTolerance && top.abs() <= originTolerance;

    final coversCanvas =
        renderedWidth >= cw * coverageRatio &&
            renderedHeight >= ch * coverageRatio;

    return atOrigin && coversCanvas;
  }

  bool isCanvasBackgroundItem(EditorItem item) {
    return _isBackgroundLayer(item);
  }

  bool _isBackgroundLayer(EditorItem item) {
    final isBackgroundType =
        item.type == 'image' || item.type == 'video' || item.type == 'shape';

    if (!isBackgroundType) return false;

    // API/Fabric background IDs are explicitly tracked while importing the
    // template. This is the important path for replacing API backgrounds.
    if (item.id != null && _templateBackgroundIds.contains(item.id)) {
      return true;
    }

    // bg_ IDs are stable for backgrounds created by the editor.
    if (item.id?.startsWith('bg_') == true) {
      return true;
    }

    // Backward compatibility for older saved projects.
    return item.position.dx.abs() < 1.0 &&
        item.position.dy.abs() < 1.0 &&
        item.width >= 1000 &&
        item.height >= 1000;
  }

  void _removeBackgroundLayers() {
    _items.removeWhere(_isBackgroundLayer);
  }

  void setBackgroundColor(Color color) {
    _saveState();

    // A color background replaces any image/video background.
    _removeBackgroundLayers();
    _backgroundColor = color;
    selectedItemId = null;
    selectedItemType = null;
    selectedFrameUrl = null;

    // Keep the current page state in sync immediately.
    _syncCurrentPage();
    notifyListeners();
  }

  // ========================= PAGE MANAGEMENT =========================
  final List<List<EditorItem>> _pages = [];
  int _currentPageIndex = 0;

  int get pageCount => _pages.isEmpty ? 1 : _pages.length;
  int get currentPageIndex => _currentPageIndex;

  void _syncCurrentPage() {
    if (_pages.isEmpty) {
      _pages.add(_items.map((e) => e.copyWith()).toList());
      _currentPageIndex = 0;
      return;
    }
    _pages[_currentPageIndex] = _items.map((e) => e.copyWith()).toList();
  }

  void addPage({bool duplicateCurrent = false}) {
    _syncCurrentPage();
    final source = duplicateCurrent
        ? _items
        .map(
          (e) => e.copyWith(
        id: '${DateTime.now().microsecondsSinceEpoch}_${e.id}',
      ),
    )
        .toList()
        : <EditorItem>[];
    _pages.add(source);
    _currentPageIndex = _pages.length - 1;
    _items
      ..clear()
      ..addAll(source.map((e) => e.copyWith()));
    clearSelection();
    notifyListeners();
  }

  void duplicateCurrentPage() => addPage(duplicateCurrent: true);

  void switchPage(int index) {
    if (index < 0 || index >= pageCount || index == _currentPageIndex) return;
    _syncCurrentPage();
    _currentPageIndex = index;
    final page = _pages[index];
    _items
      ..clear()
      ..addAll(page.map((e) => e.copyWith()));
    clearSelection();
    notifyListeners();
  }

  void deleteCurrentPage() {
    if (pageCount <= 1) {
      _items.clear();
      clearSelection();
      notifyListeners();
      return;
    }
    _pages.removeAt(_currentPageIndex);
    if (_currentPageIndex >= _pages.length) {
      _currentPageIndex = _pages.length - 1;
    }
    _items
      ..clear()
      ..addAll(_pages[_currentPageIndex].map((e) => e.copyWith()));
    clearSelection();
    notifyListeners();
  }

  // ============================================================
  // COPY ENTIRE CURRENT PAGE
  // ============================================================
  void copyCurrentPage() {
    _syncCurrentPage();

    if (_items.isEmpty) {
      debugPrint('Copy page: no items');
      return;
    }

    _copiedPageItems = _items.map((item) => item.copyWith()).toList();
    _copiedPageIndex = _currentPageIndex;
    _copiedPageBackgroundColor = _backgroundColor;

    _copiedLetterSpacing.clear();
    _copiedLineSpacing.clear();
    _copiedAlignment.clear();
    _copiedWeight.clear();
    _copiedStyle.clear();
    _copiedUnderline.clear();
    _copiedFilterIntensity.clear();

    for (final item in _items) {
      final id = item.id;
      if (id == null) continue;

      _copiedLetterSpacing[id] = textLetterSpacing(id);
      _copiedLineSpacing[id] = textLineSpacing(id);
      _copiedAlignment[id] = textAlignment(id);
      _copiedWeight[id] = textWeight(id);
      _copiedStyle[id] = textStyle(id);
      _copiedUnderline[id] = textUnderline(id);
      _copiedFilterIntensity[id] = imageFilterIntensity(id);
    }

    notifyListeners();
  }

  // ============================================================
  // PASTE ENTIRE COPIED PAGE INTO ANOTHER PAGE
  // ============================================================
  bool pasteCopiedPage() {
    if (!hasCopiedPage) {
      debugPrint('Paste page: nothing copied');
      return false;
    }

    _saveState();

    final pastedItems = <EditorItem>[];

    for (var i = 0; i < _copiedPageItems!.length; i++) {
      final source = _copiedPageItems![i];
      final oldId = source.id ?? 'item_$i';
      final newId =
          'page_${_currentPageIndex}_${DateTime.now().microsecondsSinceEpoch}_$i';

      pastedItems.add(source.copyWith(id: newId));

      _textLetterSpacing[newId] = _copiedLetterSpacing[oldId] ?? 0.0;
      _textLineSpacing[newId] = _copiedLineSpacing[oldId] ?? 1.0;
      _textAlignment[newId] = _copiedAlignment[oldId] ?? TextAlign.left;
      _textWeight[newId] = _copiedWeight[oldId] ?? FontWeight.bold;
      _textStyle[newId] = _copiedStyle[oldId] ?? FontStyle.normal;
      _textUnderline[newId] = _copiedUnderline[oldId] ?? false;
      _imageFilterIntensity[newId] = _copiedFilterIntensity[oldId] ?? 1.0;
      _imageTint[newId] = _imageTint[oldId] ?? 0.0;
      _imageBlur[newId] = _imageBlur[oldId] ?? 0.0;
    }

    // Paste means duplicate into the current page. Do not wipe existing
    // content; this also works when copying and pasting on the same page.
    _items.addAll(pastedItems);

    // Restore the copied page background.
    if (_copiedPageBackgroundColor != null) {
      _backgroundColor = _copiedPageBackgroundColor!;
    }

    selectedItemId = pastedItems.isNotEmpty ? pastedItems.first.id : null;
    selectedItemType = pastedItems.isNotEmpty ? pastedItems.first.type : null;

    _syncCurrentPage();
    notifyListeners();

    debugPrint(
      'FULL PAGE PASTED: ${pastedItems.length} items -> '
          'Page ${_currentPageIndex + 1}',
    );

    return true;
  }

  void copySelectedItem() {
    final id = selectedItemId;

    if (id == null) return;

    final index = _items.indexWhere((e) => e.id == id);

    if (index == -1) return;

    // Store a copy, don't duplicate on current page.
    _copiedItem = _items[index].copyWith();

    // Remember which page copied from.
    _copiedFromPageIndex = _currentPageIndex;

    notifyListeners();
  }

  bool pasteCopiedItem() {
    if (_copiedItem == null) return false;

    _saveState();

    final source = _copiedItem!;

    final newItem = source.copyWith(
      id: 'item_${DateTime.now().microsecondsSinceEpoch}',
      position: source.position + const Offset(30, 30),
    );

    _items.add(newItem);

    selectedItemId = newItem.id;
    selectedItemType = newItem.type;

    _syncCurrentPage();

    notifyListeners();

    return true;
  }

  /// Updates position, scale and rotation in a single provider notification.
  /// Used by interactive canvas/background gestures.
  void updateItemTransform(
      String id, {
        Offset? position,
        double? scale,
        double? rotation,
        double? width,
        double? height,
        bool clampToFrame = true,
      }) {
    final index = _items.indexWhere((item) => item.id == id);
    if (index == -1) return;

    final current = _items[index];

    if (_isBackgroundLayer(current)) {
      _items[index] = current.copyWith(
        position: Offset.zero,
        scale: scale ?? current.scale,
        rotation: rotation ?? current.rotation,
        width: width ?? current.width,
        height: height ?? current.height,
      );

      notifyListeners();
      return;
    }

    final nextRotation = (rotation ?? current.rotation).isFinite
        ? (rotation ?? current.rotation)
        : current.rotation;

    // Rotation-only gestures must never trigger frame-fit scaling or
    // position clamping. Those corrections made images shrink and jump
    // toward a different canvas location while the rotation handle moved.
    final rotationOnly = rotation != null &&
        position == null &&
        scale == null &&
        width == null &&
        height == null;

    if (rotationOnly) {
      _items[index] = current.copyWith(rotation: nextRotation);
      notifyListeners();
      return;
    }

    final rotated = current.copyWith(rotation: nextRotation);
    final requestedScale = scale ?? current.scale;
    final safeScale = !requestedScale.isFinite
        ? current.scale
        : clampToFrame
        ? _maxScaleForFrame(rotated, requestedScale)
        : requestedScale.clamp(0.02, 10.0).toDouble();

    final transformed = rotated.copyWith(
      scale: safeScale,
      width: (width ?? current.width).clamp(12.0, 4000.0).toDouble(),
      height: (height ?? current.height).clamp(12.0, 4000.0).toDouble(),
    );

    final requestedPosition = position ?? current.position;
    final nextPosition = clampToFrame
        ? _clampPositionForFrame(transformed, requestedPosition)
        : requestedPosition;

    _items[index] = transformed.copyWith(position: nextPosition);

    notifyListeners();
  }

  // Call this when user finished panning/scaling/rotating
  // so the final state is committed to history for Undo/Redo.
  void commitTransform() {
    _saveState();
  }
}
