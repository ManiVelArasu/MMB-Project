import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:archive/archive.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_svg/svg.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_picker/image_picker.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:mmb_app/ui/screens/video_widget/editor_video.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:video_player/video_player.dart';
import '../../Api Model/editor_model.dart';
import '../../Repository/freePic.dart';
import '../../component/custom_widget.dart';
import '../../core/api/api_endpoints.dart';
import '../../network/provider/editor_provider.dart';
import '../industry/widgets/editable.dart';
import '../../network/provider/custom_theme_provider.dart';
import '../../network/provider/home_screen_provider.dart';

class TemplateEditScreen extends StatelessWidget {
  final String? resizeSize;
  final String? templateUid;

  const TemplateEditScreen({super.key, this.resizeSize, this.templateUid});

  bool _isSelectedCanvasBackground(EditorProvider provider) {
    final id = provider.selectedItemId;
    if (id == null) return false;

    final item = provider.items.where((e) => e.id == id).toList();
    if (item.isEmpty) return false;

    final value = item.first;
    return value.id?.startsWith('bg_') == true ||
        (value.position.dx == 0 &&
            value.position.dy == 0 &&
            value.width >= 1000 &&
            value.height >= 1000);
  }

  @override
  Widget build(BuildContext context) {
    final args = ModalRoute.of(context)?.settings.arguments;
    String resolvedResizeSize = resizeSize ?? '';

    if (args is String && args.trim().isNotEmpty) {
      resolvedResizeSize = args.trim();
    } else if (args is Map) {
      final value = args['resizeSize'] ?? args['resize_size'];
      if (value is String && value.trim().isNotEmpty) {
        resolvedResizeSize = value.trim();
      }
    }

    return ChangeNotifierProvider(
      create: (_) => EditorProvider(),
      child: Scaffold(
        body: SafeArea(
          child: EditorView(
            resizeSize: resolvedResizeSize,
            templateUid:
                templateUid ??
                (args is Map
                    ? (args['templateUid'] ??
                              args['template_uid'] ??
                              args['uid'])
                          ?.toString()
                    : null),
          ),
        ),
      ),
    );
  }
}

class EditorView extends StatefulWidget {
  final String resizeSize;
  final String? templateUid;

  const EditorView({super.key, required this.resizeSize, this.templateUid});

  @override
  State<EditorView> createState() => _EditorViewState();
}

class _EditorViewState extends State<EditorView> {
  bool _showFlipOptions = false;

  Size _getCanvasSize() {
    final size = widget.resizeSize.toLowerCase();

    if (size.contains('4:5')) {
      return const Size(1080, 1350);
    }
    if (size.contains('9:16')) {
      return const Size(1080, 1920);
    }
    if (size.contains('horizontal')) {
      return const Size(1200, 628);
    }
    if (size.contains('portrait')) {
      return const Size(1080, 1350);
    }
    // Default editor canvas when no template UID/resize is supplied.
    // Keep the standard portrait template size used by the app.
    return const Size(1080, 1350);
  }

  bool _isCanvasBackground(EditorItem item) {
    if (item.id?.startsWith('bg_') == true &&
        (item.type == 'image' ||
            item.type == 'video' ||
            item.type == 'shape')) {
      return true;
    }

    // Admin-uploaded Fabric templates can store the full-canvas background
    // as an ordinary image object instead of an editor-generated bg_* item.
    return item.type == 'image' &&
        item.position.dx.abs() < 1.0 &&
        item.position.dy.abs() < 1.0 &&
        (item.width - 1080.0).abs() < 2.0 &&
        (item.height - 1080.0).abs() < 2.0;
  }

  Widget _buildCanvasBackground(EditorProvider provider) {
    final bgItems = provider.items.where(_isCanvasBackground).toList();

    if (bgItems.isEmpty) {
      return Container(color: provider.backgroundColor);
    }

    final bg = bgItems.last;
    if (bg.type == 'image' &&
        bg.contentUrl != null &&
        bg.contentUrl!.isNotEmpty) {
      return Center(
        child: Transform.rotate(
          angle: bg.rotation.isFinite ? bg.rotation : 0.0,
          child: Transform.scale(
            scale: bg.scale.isFinite ? bg.scale.clamp(0.01, 10.0) : 1.0,
            child: Opacity(
              opacity: bg.opacity.isFinite ? bg.opacity.clamp(0.0, 1.0) : 1.0,
              child: SizedBox(
                width: provider.canvasWidth,
                height: provider.canvasHeight,
                child: FittedBox(
                  fit: BoxFit.fill,
                  child: SizedBox(
                    width: bg.width,
                    height: bg.height,
                    child: EditableItemWidget.buildStandaloneMediaContent(
                      context,
                      bg,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      );
    }

    if (bg.type == 'video' &&
        bg.contentUrl != null &&
        bg.contentUrl!.isNotEmpty) {
      return Opacity(
        opacity: bg.opacity.isFinite ? bg.opacity.clamp(0.0, 1.0) : 1.0,
        child: Transform.rotate(
          angle: bg.rotation.isFinite ? bg.rotation : 0.0,
          child: Transform.scale(
            scale: bg.scale.isFinite ? bg.scale.clamp(0.01, 10.0) : 1.0,
            child: SizedBox(
              width: bg.width,
              height: bg.height,
              child: EditorVideoWidget(videoUrl: bg.contentUrl!),
            ),
          ),
        ),
      );
    }

    return Container(color: provider.backgroundColor);
  }

  Future<String?> _prepareCropSource(String source) async {
    if (!source.startsWith('http://') && !source.startsWith('https://')) {
      return source;
    }

    try {
      final client = HttpClient();
      final request = await client.getUrl(Uri.parse(source));
      final response = await request.close();
      if (response.statusCode != 200) return null;
      final bytes = await response.fold<List<int>>(
        <int>[],
        (buffer, data) => buffer..addAll(data),
      );
      client.close();
      final dir = await getTemporaryDirectory();
      final file = File(
        '${dir.path}/editor_crop_${DateTime.now().millisecondsSinceEpoch}.jpg',
      );
      await file.writeAsBytes(bytes, flush: true);
      return file.path;
    } catch (_) {
      return null;
    }
  }

  Future<void> _cropSelectedImage(
    BuildContext context,
    EditorProvider provider,
    String itemId,
  ) async {
    final item = provider.items.where((e) => e.id == itemId).isEmpty
        ? null
        : provider.items.firstWhere((e) => e.id == itemId);
    if (item == null ||
        item.type != 'image' ||
        (item.contentUrl ?? '').isEmpty) {
      return;
    }

    final sourcePath = await _prepareCropSource(item.contentUrl!);
    if (sourcePath == null) {
      Fluttertoast.showToast(msg: 'Unable to open image for crop');
      return;
    }

    final cropped = await ImageCropper().cropImage(
      sourcePath: sourcePath,
      compressFormat: ImageCompressFormat.jpg,
      compressQuality: 95,
      uiSettings: [
        AndroidUiSettings(
          toolbarTitle: 'Crop Image',
          toolbarColor: Colors.black,
          toolbarWidgetColor: Colors.white,
          lockAspectRatio: false,
          hideBottomControls: false,
        ),
        IOSUiSettings(title: 'Crop Image', aspectRatioLockEnabled: false),
      ],
    );

    if (cropped != null) {
      provider.updateCroppedImage(itemId, cropped.path);
    }
  }

  Future<Size?> _resolveNetworkImageSize(String url) async {
    try {
      final completer = Completer<Size>();
      final provider = NetworkImage(url);
      final stream = provider.resolve(const ImageConfiguration());
      late final ImageStreamListener listener;
      listener = ImageStreamListener(
        (info, _) {
          final image = info.image;
          completer.complete(
            Size(image.width.toDouble(), image.height.toDouble()),
          );
          stream.removeListener(listener);
        },
        onError: (error, stack) {
          if (!completer.isCompleted) completer.complete(null);
          stream.removeListener(listener);
        },
      );
      stream.addListener(listener);
      return await completer.future.timeout(const Duration(seconds: 10));
    } catch (_) {
      return null;
    }
  }

  Future<Size?> _resolveNetworkVideoSize(String url) async {
    VideoPlayerController? controller;
    try {
      controller = VideoPlayerController.networkUrl(Uri.parse(url));
      await controller.initialize().timeout(const Duration(seconds: 15));
      final size = controller.value.size;
      if (size.width > 0 && size.height > 0) {
        return size;
      }
      return null;
    } catch (_) {
      return null;
    } finally {
      await controller?.dispose();
    }
  }

  Future<bool> _confirmReplaceBackground(
    BuildContext context,
    EditorProvider provider,
    String imageUrl, {
    String? selectedItemId,
  }) async {
    final replace = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const AppText('Replace Background?'),
        content: const AppText(
          'The current background will be removed and this image will become the full-size background.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('CANCEL'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const AppText('REPLACE BACKGROUND'),
          ),
        ],
      ),
    );

    if (replace == true) {
      if (selectedItemId != null) {
        // Media image -> full-size background.
        // This also removes the selected media item so it is not rendered twice.
        final canvasSize = Size(provider.canvasWidth, provider.canvasHeight);
        // Replace immediately. Do NOT wait for the remote image dimensions.
        // The provider already sizes the background to the current canvas and
        // the renderer uses cover behavior.
        provider.replaceBackgroundImage(
          imageUrl,
          selectedItemId,
          canvasWidth: canvasSize.width,
          canvasHeight: canvasSize.height,
        );
      } else {
        // Background/stock image -> full-size background.
        // setBackgroundImage creates/selects the new bg_ layer.
        final canvasSize = Size(provider.canvasWidth, provider.canvasHeight);
        // Replace immediately. Do NOT wait for the remote image dimensions.
        provider.setBackgroundImage(
          imageUrl,
          canvasWidth: canvasSize.width,
          canvasHeight: canvasSize.height,
        );
      }

      // Repaint immediately so the newly selected/replaced background is
      // visible at once, without waiting for the bottom sheet to close.
      if (mounted) setState(() {});

      // Close the selection sheet, then keep the new background selected.
      // The image editor bottom toolbar is driven by selectedItemType.
      final bgItems = provider.items.where(_isCanvasBackground).toList();

      if (bgItems.isNotEmpty) {
        final bg = bgItems.last;
        provider.setSelectedItem(bg.type, bg.id);
      }

      if (mounted) {
        setState(() {
          _bottomNavIndex = 3;
        });
      }

      return true;
    }
    return false;
  }

  int _bottomNavIndex = 0;
  bool _isInitialized = false;
  final GlobalKey _canvasKey = GlobalKey();

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_isInitialized) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _loadTemplateJsonAndInitEditor();
      });
      _isInitialized = true;
    }
  }

  Future<void> _loadTemplateJsonAndInitEditor() async {
    final provider = Provider.of<EditorProvider>(context, listen: false);
    final hasExplicitResize = widget.resizeSize.trim().isNotEmpty;
    final resizeCanvas = hasExplicitResize ? _getCanvasSize() : null;

    final uid = widget.templateUid?.trim() ?? '';
    if (uid.isNotEmpty) {
      await provider.loadTemplateByUid(uid);
    } else {
      final canvasSize = resizeCanvas ?? _getCanvasSize();
      provider.setCanvasSize(canvasSize.width, canvasSize.height);
      debugPrint('ℹ️ No template UID supplied; opening blank editor');
    }
    provider.fetchFreePikAssets("furniture");
    provider.fetchFreePikStickers("stickers");
  }

  Future<void> _addLocalShape(
    BuildContext context,
    EditorProvider provider,
    String assetPath,
  ) async {
    try {
      final pictureInfo = await vg.loadPicture(SvgAssetLoader(assetPath), null);

      const outputSize = 512.0;

      final sourceSize = pictureInfo.size;

      final sourceWidth = sourceSize.width > 0 ? sourceSize.width : outputSize;

      final sourceHeight = sourceSize.height > 0
          ? sourceSize.height
          : outputSize;

      final recorder = ui.PictureRecorder();

      final canvas = Canvas(recorder);

      final scale = math.min(
        outputSize / sourceWidth,
        outputSize / sourceHeight,
      );

      canvas.translate(
        (outputSize - sourceWidth * scale) / 2,
        (outputSize - sourceHeight * scale) / 2,
      );

      canvas.scale(scale);

      canvas.drawPicture(pictureInfo.picture);

      final picture = recorder.endRecording();

      final image = await picture.toImage(
        outputSize.toInt(),
        outputSize.toInt(),
      );

      final byteData = await image.toByteData(format: ui.ImageByteFormat.png);

      pictureInfo.picture.dispose();
      picture.dispose();
      image.dispose();

      if (byteData == null) {
        throw Exception('Unable to render SVG');
      }

      final dir = await getTemporaryDirectory();

      final file = File(
        "${dir.path}/shape_${DateTime.now().microsecondsSinceEpoch}.png",
      );

      await file.writeAsBytes(byteData.buffer.asUint8List(), flush: true);

      provider.addImage(file.path, isLocal: true);

      if (context.mounted) {
        Navigator.pop(context);
      }
    } catch (_) {
      if (context.mounted) {
        Fluttertoast.showToast(msg: "Unable to add shape");
      }
    }
  }

  Widget _buildTab(bool isSelected, String title, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          AppText(
            title,
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: isSelected ? Colors.red : Colors.grey,
            ),
          ),
          if (isSelected)
            Container(
              height: 2,
              width: 30,
              color: Colors.red,
              margin: const EdgeInsets.only(top: 4),
            ),
        ],
      ),
    );
  }

  Widget _textSheetContainer({
    required bool isDark,
    required Widget child,
    double height = 0.42,
  }) {
    return Container(
      height: WidgetsBinding.instance.platformDispatcher.views.isNotEmpty
          ? WidgetsBinding
                    .instance
                    .platformDispatcher
                    .views
                    .first
                    .physicalSize
                    .height /
                WidgetsBinding
                    .instance
                    .platformDispatcher
                    .views
                    .first
                    .devicePixelRatio *
                height
          : 320,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF1E1E1E) : Colors.white,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
      ),
      child: child,
    );
  }

  Widget _formatToggle({
    required IconData icon,
    required String label,
    required bool selected,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        width: 64,
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          color: selected
              ? Colors.red.withValues(alpha: .10)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: selected ? Colors.red : Colors.grey.shade300,
          ),
        ),
        child: Column(
          children: [
            Icon(
              icon,
              color: selected ? Colors.red : Colors.grey.shade700,
              size: 20,
            ),
            const SizedBox(height: 3),
            Text(label, style: const TextStyle(fontSize: 9)),
          ],
        ),
      ),
    );
  }

  Widget _buildImageAdjustSlider(
    String title,
    double value,
    double min,
    double max,
    ValueChanged<double> onChanged,
  ) {
    return Row(
      children: [
        SizedBox(width: 88, child: Text(title)),
        Expanded(
          child: Slider(
            value: value.clamp(min, max),
            min: min,
            max: max,
            onChanged: onChanged,
          ),
        ),
        SizedBox(
          width: 42,
          child: Text(value.toStringAsFixed(1), textAlign: TextAlign.right),
        ),
      ],
    );
  }

  void _showFramesBottomSheet(
    BuildContext context,
    EditorProvider provider,
    bool isDark,
  ) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (modalContext) {
        return Container(
          height: MediaQuery.of(context).size.height * 0.45,
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          decoration: BoxDecoration(
            color: isDark ? const Color(0xFF1E1E1E) : Colors.white,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  AppText(
                    "My Frames",
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                      color: isDark ? Colors.white : Colors.black,
                    ),
                  ),
                  InkWell(
                    onTap: () => Navigator.pop(modalContext),
                    child: Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: isDark
                            ? const Color(0xFF2A1A1C)
                            : Colors.red.shade50,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.close,
                        color: Colors.red,
                        size: 18,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Expanded(
                child: GridView.builder(
                  scrollDirection: Axis.horizontal,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 1,
                    mainAxisSpacing: 14,
                  ),
                  itemCount: 4,
                  itemBuilder: (context, index) {
                    return GestureDetector(
                      onTap: () {
                        provider.setSelectedFrame(
                          "assets/images/thumbnail1.png",
                        );
                        Navigator.pop(modalContext);
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                          color: isDark
                              ? const Color(0xFF2C2C2C)
                              : Colors.grey.shade50,
                        ),
                        child: const Center(
                          child: Icon(
                            Icons.image_rounded,
                            size: 40,
                            color: Colors.blueAccent,
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _showTemplatesBottomSheet(
    BuildContext context,
    EditorProvider provider,
    bool isDark,
  ) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (modalContext) {
        return ChangeNotifierProvider(
          create: (_) => HomeScreenProvider(),
          child: Container(
            height: MediaQuery.of(modalContext).size.height * 0.72,
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
            decoration: BoxDecoration(
              color: isDark ? const Color(0xFF17191E) : Colors.white,
              borderRadius: const BorderRadius.vertical(
                top: Radius.circular(28),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 38,
                      height: 4,
                      decoration: BoxDecoration(
                        color: isDark
                            ? Colors.grey.shade700
                            : Colors.grey.shade300,
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    const Spacer(),
                    InkWell(
                      onTap: () => Navigator.pop(modalContext),
                      borderRadius: BorderRadius.circular(20),
                      child: Container(
                        padding: const EdgeInsets.all(7),
                        decoration: BoxDecoration(
                          color: isDark
                              ? const Color(0xFF2A1A1C)
                              : Colors.red.shade50,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.close,
                          color: Colors.red,
                          size: 18,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                AppText(
                  'Templates',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    color: isDark ? Colors.white : Colors.black,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Choose a template to replace the current design',
                  style: TextStyle(
                    fontSize: 12,
                    color: isDark ? Colors.white60 : Colors.black54,
                  ),
                ),
                const SizedBox(height: 12),
                Expanded(
                  child: Consumer<HomeScreenProvider>(
                    builder: (sheetContext, homeProvider, _) {
                      final categories = homeProvider.templateCategories;

                      if (categories.isEmpty) {
                        return const Center(
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Color(0xFFE53935),
                          ),
                        );
                      }

                      return ListView.builder(
                        physics: const BouncingScrollPhysics(),
                        padding: const EdgeInsets.only(bottom: 18),
                        itemCount: categories.length,
                        itemBuilder: (context, categoryIndex) {
                          final category = categories[categoryIndex];
                          final categoryName = category.name?.trim() ?? '';
                          final slug = category.slug?.trim() ?? '';

                          if (slug.isEmpty) {
                            return const SizedBox.shrink();
                          }

                          final templates = homeProvider.templatesForCategory(
                            slug,
                          );
                          final loading = homeProvider.isTemplateLoading(slug);

                          if (!loading && templates.isEmpty) {
                            return const SizedBox.shrink();
                          }

                          return Padding(
                            padding: const EdgeInsets.only(bottom: 18),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Expanded(
                                      child: Text(
                                        categoryName,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w800,
                                          color: isDark
                                              ? Colors.white
                                              : Colors.black,
                                        ),
                                      ),
                                    ),
                                    if (loading)
                                      const SizedBox(
                                        width: 16,
                                        height: 16,
                                        child: CircularProgressIndicator(
                                          strokeWidth: 1.8,
                                          color: Color(0xFFE53935),
                                        ),
                                      ),
                                  ],
                                ),
                                const SizedBox(height: 9),
                                if (loading && templates.isEmpty)
                                  SizedBox(
                                    height: 150,
                                    child: ListView.separated(
                                      scrollDirection: Axis.horizontal,
                                      itemCount: 3,
                                      separatorBuilder: (_, __) =>
                                          const SizedBox(width: 10),
                                      itemBuilder: (_, __) => Container(
                                        width: 108,
                                        decoration: BoxDecoration(
                                          color: isDark
                                              ? const Color(0xFF25272D)
                                              : Colors.grey.shade100,
                                          borderRadius: BorderRadius.circular(
                                            14,
                                          ),
                                        ),
                                      ),
                                    ),
                                  )
                                else
                                  SizedBox(
                                    height: 150,
                                    child: ListView.separated(
                                      scrollDirection: Axis.horizontal,
                                      physics: const BouncingScrollPhysics(),
                                      itemCount: templates.length,
                                      separatorBuilder: (_, __) =>
                                          const SizedBox(width: 10),
                                      itemBuilder: (_, templateIndex) {
                                        final template =
                                            templates[templateIndex];
                                        final uid = _templateStringValue(
                                          template,
                                          const [
                                            'uid',
                                            'templateUid',
                                            'template_uid',
                                          ],
                                        );
                                        final imageKey = _templateStringValue(
                                          template,
                                          const [
                                            'thumbnailS3Key',
                                            'thumbnail_s3_key',
                                            'previewS3Key',
                                            'preview_s3_key',
                                            's3Key',
                                            's3_key',
                                            'thumbnail',
                                            'image',
                                            'preview',
                                          ],
                                        );

                                        final imageUrl = _templateImageUrl(
                                          imageKey,
                                        );

                                        return GestureDetector(
                                          onTap: uid.isEmpty
                                              ? null
                                              : () async {
                                                  Navigator.pop(modalContext);

                                                  // IMPORTANT:
                                                  // Do not pass resizeSize dimensions here.
                                                  // The selected template's own API/Fabric JSON
                                                  // determines its canvas width and height.
                                                  await provider
                                                      .loadTemplateByUid(uid);

                                                  if (mounted) {
                                                    setState(() {});
                                                  }
                                                },
                                          child: Container(
                                            width: 108,
                                            decoration: BoxDecoration(
                                              color: isDark
                                                  ? const Color(0xFF25272D)
                                                  : Colors.grey.shade100,
                                              borderRadius:
                                                  BorderRadius.circular(14),
                                              border: Border.all(
                                                color: isDark
                                                    ? Colors.grey.shade800
                                                    : Colors.grey.shade200,
                                              ),
                                            ),
                                            child: ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(14),
                                              child: imageUrl.isEmpty
                                                  ? const Center(
                                                      child: Icon(
                                                        Icons.image_outlined,
                                                        color: Colors.grey,
                                                        size: 30,
                                                      ),
                                                    )
                                                  : Image.network(
                                                      imageUrl,
                                                      fit: BoxFit.cover,
                                                      errorBuilder:
                                                          (
                                                            _,
                                                            __,
                                                            ___,
                                                          ) => const Center(
                                                            child: Icon(
                                                              Icons
                                                                  .broken_image_outlined,
                                                              color:
                                                                  Colors.grey,
                                                              size: 30,
                                                            ),
                                                          ),
                                                    ),
                                            ),
                                          ),
                                        );
                                      },
                                    ),
                                  ),
                              ],
                            ),
                          );
                        },
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  String _templateStringValue(dynamic item, List<String> keys) {
    if (item is Map) {
      for (final key in keys) {
        final value = item[key];
        if (value != null && value.toString().trim().isNotEmpty) {
          return value.toString().trim();
        }
      }
    }

    for (final key in keys) {
      try {
        dynamic value;
        switch (key) {
          case 'uid':
            value = item.uid;
            break;
          case 'templateUid':
            value = item.templateUid;
            break;
          case 'template_uid':
            value = item.template_uid;
            break;
          case 'thumbnailS3Key':
            value = item.thumbnailS3Key;
            break;
          case 'thumbnail_s3_key':
            value = item.thumbnail_s3_key;
            break;
          case 'previewS3Key':
            value = item.previewS3Key;
            break;
          case 'preview_s3_key':
            value = item.preview_s3_key;
            break;
          case 's3Key':
            value = item.s3Key;
            break;
          case 's3_key':
            value = item.s3_key;
            break;
          case 'thumbnail':
            value = item.thumbnail;
            break;
          case 'image':
            value = item.image;
            break;
          case 'preview':
            value = item.preview;
            break;
        }
        if (value != null && value.toString().trim().isNotEmpty) {
          return value.toString().trim();
        }
      } catch (_) {
        // Try the next possible property name.
      }
    }

    return '';
  }

  String _templateImageUrl(String value) {
    final url = value.trim();
    if (url.isEmpty) return '';
    if (url.startsWith('http://') || url.startsWith('https://')) {
      return url;
    }
    if (url.startsWith('/')) {
      return '${ApiEndpoints.cdnImageUrl}$url';
    }
    return '${ApiEndpoints.cdnImageUrl}/$url';
  }

  void _showMyBrandBottomSheet(
    BuildContext context,
    EditorProvider provider,
    bool isDark,
  ) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (modalContext) {
        return SafeArea(
          child: Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: isDark ? const Color(0xFF1E1E1E) : Colors.white,
              borderRadius: const BorderRadius.vertical(
                top: Radius.circular(28),
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    AppText(
                      "Upload Brand Assets",
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w800,
                        color: isDark ? Colors.white : Colors.black,
                      ),
                    ),
                    InkWell(
                      onTap: () => Navigator.pop(modalContext),
                      child: Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: isDark
                              ? const Color(0xFF2A1A1C)
                              : Colors.red.shade50,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.close,
                          color: Colors.red,
                          size: 18,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  onPressed: () async {
                    Navigator.pop(modalContext);
                    final picker = ImagePicker();
                    final image = await picker.pickImage(
                      source: ImageSource.gallery,
                    );
                    if (image != null) {
                      provider.addImage(image.path, isLocal: true);
                    }
                  },
                  child: const AppText(
                    "UPLOAD LOGO / IMAGE",
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showTextStylesBottomSheet(
    BuildContext context,
    EditorProvider provider,
    bool isDark,
  ) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (modalContext) {
        return SafeArea(
          child: Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: isDark ? const Color(0xFF1E1E1E) : Colors.white,
              borderRadius: const BorderRadius.vertical(
                top: Radius.circular(28),
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    AppText(
                      "Add Text",
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w800,
                        color: isDark ? Colors.white : Colors.black,
                      ),
                    ),
                    InkWell(
                      onTap: () => Navigator.pop(modalContext),
                      child: Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: isDark
                              ? const Color(0xFF2A1A1C)
                              : Colors.red.shade50,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.close,
                          color: Colors.red,
                          size: 18,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Center(
                    child: AppText(
                      "My Heading",
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                        color: isDark ? Colors.white : Colors.black,
                      ),
                    ),
                  ),
                  onTap: () {
                    _addTextCentered(provider, "My Heading");
                    Navigator.pop(modalContext);
                  },
                ),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Center(
                    child: AppText(
                      "My Sub Title",
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                        color: isDark ? Colors.white : Colors.black,
                      ),
                    ),
                  ),
                  onTap: () {
                    _addTextCentered(provider, "My Sub Title");
                    Navigator.pop(modalContext);
                  },
                ),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Center(
                    child: AppText(
                      "My Text",
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                        color: isDark ? Colors.white : Colors.black,
                      ),
                    ),
                  ),
                  onTap: () {
                    _addTextCentered(provider, "My Text");
                    Navigator.pop(modalContext);
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _addTextCentered(EditorProvider provider, String text) {
    provider.addText(initialText: text);

    // Newly added text should start at the visual center of the canvas
    // instead of the provider's default/top-left position.
    final textItems = provider.items
        .where((item) => item.type == 'text' || item.type == 'textbox')
        .toList();

    if (textItems.isEmpty) return;

    final item = textItems.last;
    final canvasSize = Size(
      provider.canvasWidth > 0 ? provider.canvasWidth : 1080.0,
      provider.canvasHeight > 0 ? provider.canvasHeight : 1080.0,
    );

    // `EditorItem.position` is the item's TOP-LEFT position on the canvas.
    // Put the whole text box at the visual center instead of placing its
    // top-left corner at the center (which pushes half of the text off-screen).
    final itemWidth = item.width * item.scale;
    final itemHeight = item.height * item.scale;

    final centeredX = ((canvasSize.width - itemWidth) / 2)
        .clamp(0.0, math.max(0.0, canvasSize.width - itemWidth))
        .toDouble();
    final centeredY = ((canvasSize.height - itemHeight) / 2)
        .clamp(0.0, math.max(0.0, canvasSize.height - itemHeight))
        .toDouble();

    provider.updateItemTransform(
      item.id ?? '',
      position: Offset(centeredX, centeredY),
    );

    if (mounted) {
      setState(() {});
    }
  }

  bool isStickerProxyCategory(String category) {
    final normalized = category.trim().toLowerCase();
    return normalized == 'stickers' ||
        normalized == 'social media' ||
        normalized == 'e-commerce';
  }

  void _showMediaBottomSheet(
    BuildContext context,
    EditorProvider provider,
    bool isDark,
  ) {
    int selectedTab = 1; // 0 uploads, 1 elements, 2 images
    String? expandedCategory;
    bool sheetOpen = true;
    final searchController = TextEditingController();

    const categories = <Map<String, String>>[
      {'title': 'Shapes', 'query': 'shapes'},
      {'title': 'Stickers', 'query': 'stickers'},
      {'title': 'Social Media', 'query': 'social media'},
      {'title': 'E-commerce', 'query': 'e-commerce'},
    ];

    const imageCategories = <Map<String, String>>[
      {'title': 'Nature', 'query': 'nature'},
      {'title': 'People', 'query': 'people'},
      {'title': 'Business', 'query': 'business'},
      {'title': 'Animals', 'query': 'animals'},
      {'title': 'Travel', 'query': 'travel'},
      {'title': 'Food', 'query': 'food'},
      {'title': 'Technology', 'query': 'technology'},
      {'title': 'Fashion', 'query': 'fashion'},
      {'title': 'Architecture', 'query': 'architecture'},
      {'title': 'Background', 'query': 'background'},
    ];

    void loadCategory(
      String query,
      void Function(void Function()) setState, {
      int limit = 4,
      bool force = false,
    }) {
      if (query == 'shapes') {
        if (!force && provider.elementCategoryAssets(query).isNotEmpty) return;
        if (provider.isElementCategoryLoading(query)) return;
        provider.fetchElementCategory(query, limit: limit).then((_) {
          if (!sheetOpen) return;
          setState(() {});
        });
        setState(() {});
        return;
      }
      if (isStickerProxyCategory(query)) {
        if (!force && provider.elementCategoryAssets(query).isNotEmpty) return;
        if (provider.isElementCategoryLoading(query)) return;
        provider.fetchElementCategory(query, limit: limit).then((_) {
          if (!sheetOpen) return;
          setState(() {});
        });
        setState(() {});
        return;
      }
      if (!force && provider.elementCategoryAssets(query).isNotEmpty) {
        return;
      }
      if (provider.isElementCategoryLoading(query)) return;

      provider.fetchElementCategory(query, limit: limit).then((_) {
        if (!sheetOpen) return;
        setState(() {});
      });
      setState(() {});
    }

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (modalContext) {
        return StatefulBuilder(
          builder: (sheetContext, setSheetState) {
            if (selectedTab == 1 && expandedCategory == null) {
              for (final category in categories) {
                loadCategory(category['query']!, setSheetState);
              }
            }

            Widget elementCard(
              String url, {
              bool locked = false,
              VoidCallback? onTap,
            }) {
              final isLocalShape = url.startsWith('assets/shapes/');
              final bool isSvg = url
                  .toLowerCase()
                  .split('?')
                  .first
                  .endsWith('.svg');

              final Widget preview = url.isEmpty
                  ? const Icon(
                      Icons.image_not_supported_outlined,
                      color: Colors.grey,
                    )
                  : isLocalShape
                  ? SvgPicture.asset(
                      url,
                      fit: BoxFit.contain,
                      width: 58,
                      height: 58,
                      placeholderBuilder: (_) => const Center(
                        child: SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(strokeWidth: 1.5),
                        ),
                      ),
                      errorBuilder: (_, __, ___) => const Icon(
                        Icons.broken_image_outlined,
                        color: Colors.grey,
                      ),
                    )
                  : isSvg
                  ? SvgPicture.network(
                      url,
                      fit: BoxFit.contain,
                      placeholderBuilder: (_) => const Center(
                        child: SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(strokeWidth: 1.5),
                        ),
                      ),
                      errorBuilder: (_, __, ___) =>
                          const Icon(Icons.image_outlined, color: Colors.grey),
                    )
                  : Image.network(
                      url,
                      fit: BoxFit.contain,
                      errorBuilder: (_, __, ___) =>
                          const Icon(Icons.image_outlined, color: Colors.grey),
                      loadingBuilder: (context, child, progress) {
                        if (progress == null) return child;
                        return const Center(
                          child: SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(strokeWidth: 1.5),
                          ),
                        );
                      },
                    );

              return GestureDetector(
                onTap: locked
                    ? null
                    : onTap ??
                          () {
                            if (isLocalShape) {
                              _addLocalShape(modalContext, provider, url);
                            } else {
                              provider.addFreePikElement(url);
                              Navigator.pop(modalContext);
                            }
                          },
                child: Stack(
                  children: [
                    Container(
                      height: 58,
                      width: 58,
                      decoration: BoxDecoration(
                        color: isDark
                            ? const Color(0xFF24262B)
                            : const Color(0xFFF8F8F8),
                        borderRadius: BorderRadius.circular(9),
                        border: Border.all(
                          color: locked
                              ? (isDark
                                    ? Colors.orange.withOpacity(.55)
                                    : Colors.orange.shade200)
                              : (isDark
                                    ? Colors.white12
                                    : const Color(0xFFE8E8E8)),
                        ),
                      ),
                      clipBehavior: Clip.antiAlias,
                      child: Opacity(opacity: locked ? .38 : 1, child: preview),
                    ),
                    if (locked)
                      Positioned.fill(
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(.18),
                            borderRadius: BorderRadius.circular(9),
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: const [
                              Icon(
                                Icons.lock_rounded,
                                size: 24,
                                color: Colors.orange,
                              ),
                              SizedBox(height: 2),
                              Text(
                                'LOCKED',
                                style: TextStyle(
                                  color: Colors.orange,
                                  fontSize: 7,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                  ],
                ),
              );
            }

            Widget assetCategoryCard(
              AssetCategoryItem item, {
              bool isShape = false,
            }) {
              final url = item.previewKey;
              final isLocalShape = url.startsWith('assets/shapes/');

              return elementCard(
                url,
                locked: item.isLocked,
                onTap: item.isLocked
                    ? null
                    : () async {
                        if (isLocalShape) {
                          await _addLocalShape(modalContext, provider, url);
                        } else if (isShape) {
                          // Shapes and masks must become real shape layers.
                          provider.addShape(url, isLocal: false);

                          if (modalContext.mounted) {
                            Navigator.pop(modalContext);
                          }
                        } else {
                          // Other API assets are normal image layers.
                          provider.addImage(url, isLocal: false);

                          if (modalContext.mounted) {
                            Navigator.pop(modalContext);
                          }
                        }
                      },
              );
            }

            Widget categoryTitle(String title, String query) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        title,
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w800,
                          color: isDark
                              ? Colors.white
                              : const Color(0xFF151515),
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        provider.resetElementCategoryRequest(query);
                        provider.fetchElementCategoryAll(query).then((_) {
                          if (sheetOpen) setSheetState(() {});
                        });
                        setSheetState(() => expandedCategory = query);
                      },
                      child: const Text(
                        'View all',
                        style: TextStyle(
                          color: Colors.red,
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ],
                ),
              );
            }

            Widget categorySection(Map<String, String> category) {
              final title = category['title']!;
              final query = category['query']!;

              final bool stickerProxy = isStickerProxyCategory(query);

              final List<AssetCategoryItem> assetItems = stickerProxy
                  ? const <AssetCategoryItem>[]
                  : provider.assetCategoryItems(query);

              final List<String> stickerItems = stickerProxy
                  ? provider.elementCategoryAssets(query)
                  : const <String>[];

              final previewAssets = assetItems.take(4).toList();
              final previewStickers = stickerItems.take(4).toList();

              final bool hasItems = stickerProxy
                  ? previewStickers.isNotEmpty
                  : previewAssets.isNotEmpty;

              final bool isLoading = stickerProxy
                  ? (provider.isFreePikStickerCategoryLoading[query] ?? false)
                  : provider.isElementCategoryLoading(query);

              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  categoryTitle(title, query),

                  SizedBox(
                    height: 58,
                    child: isLoading
                        ? const Center(
                            child: SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(
                                strokeWidth: 1.8,
                              ),
                            ),
                          )
                        : !hasItems
                        ? const Center(
                            child: Text(
                              'No items found',
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 11,
                              ),
                            ),
                          )
                        : Row(
                            children: stickerProxy
                                ? previewStickers.map((url) {
                                    return Expanded(
                                      child: Padding(
                                        padding: const EdgeInsets.only(
                                          right: 8,
                                        ),
                                        child: elementCard(url),
                                      ),
                                    );
                                  }).toList()
                                : previewAssets.map((item) {
                                    return Expanded(
                                      child: Padding(
                                        padding: const EdgeInsets.only(
                                          right: 8,
                                        ),
                                        child: assetCategoryCard(
                                          item,
                                          isShape: query == 'shapes',
                                        ),
                                      ),
                                    );
                                  }).toList(),
                          ),
                  ),

                  const SizedBox(height: 18),
                ],
              );
            }

            Widget elementsView() {
              if (expandedCategory != null) {
                final query = expandedCategory!;
                final title = categories.firstWhere(
                  (e) => e['query'] == query,
                )['title']!;
                final bool stickerProxy = isStickerProxyCategory(query);
                final List<AssetCategoryItem> assetItems = stickerProxy
                    ? const <AssetCategoryItem>[]
                    : provider.assetCategoryItems(query);
                final List<String> stickerItems = stickerProxy
                    ? provider.elementCategoryAssets(query)
                    : const <String>[];
                return Column(
                  children: [
                    Row(
                      children: [
                        IconButton(
                          onPressed: () =>
                              setSheetState(() => expandedCategory = null),
                          icon: const Icon(Icons.arrow_back_rounded),
                        ),
                        Expanded(
                          child: Text(
                            title,
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                      ],
                    ),
                    Expanded(
                      child:
                          (isStickerProxyCategory(query)
                              ? (provider
                                        .isFreePikStickerCategoryLoading[query] ??
                                    false)
                              : provider.isElementCategoryLoading(query))
                          ? const Center(
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : GridView.builder(
                              padding: const EdgeInsets.fromLTRB(4, 4, 4, 20),
                              gridDelegate:
                                  const SliverGridDelegateWithFixedCrossAxisCount(
                                    crossAxisCount: 4,
                                    crossAxisSpacing: 10,
                                    mainAxisSpacing: 10,
                                  ),
                              itemCount: isStickerProxyCategory(query)
                                  ? stickerItems.length
                                  : assetItems.length,
                              itemBuilder: (_, index) =>
                                  isStickerProxyCategory(query)
                                  ? elementCard(stickerItems[index])
                                  : assetCategoryCard(
                                      assetItems[index],
                                      isShape: query == 'shapes',
                                    ),
                            ),
                    ),
                  ],
                );
              }
              return ListView(
                padding: const EdgeInsets.fromLTRB(4, 12, 4, 20),
                children: categories.map(categorySection).toList(),
              );
            }

            Widget uploadsView() {
              return Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  GestureDetector(
                    onTap: () async {
                      Navigator.pop(modalContext);
                      final image = await ImagePicker().pickImage(
                        source: ImageSource.camera,
                      );
                      if (image != null)
                        provider.addImage(image.path, isLocal: true);
                    },
                    child: _mediaPickerTile(isDark, Icons.camera_alt, 'CAMERA'),
                  ),
                  const SizedBox(width: 12),
                  GestureDetector(
                    onTap: () async {
                      Navigator.pop(modalContext);
                      final image = await ImagePicker().pickImage(
                        source: ImageSource.gallery,
                      );
                      if (image != null)
                        provider.addImage(image.path, isLocal: true);
                    },
                    child: _mediaPickerTile(
                      isDark,
                      Icons.photo_library,
                      'GALLERY',
                    ),
                  ),
                ],
              );
            }

            Widget imagesView() {
              const defaultQuery = 'background';
              final images = provider.mediaImageAssets;

              if (!provider.isMediaImagesLoading &&
                  images.isEmpty &&
                  provider.mediaImageAssets.isEmpty) {
                Future.microtask(() => provider.fetchMediaImages(defaultQuery));
              }

              Widget imageChip(String title, String query) {
                final selected = provider.mediaImagesQuery == query;
                return GestureDetector(
                  onTap: () {
                    searchController.text = query;
                    provider.fetchMediaImages(query).then((_) {
                      if (sheetOpen) setSheetState(() {});
                    });
                    setSheetState(() {});
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 7,
                    ),
                    decoration: BoxDecoration(
                      color: selected
                          ? const Color(0xFFFFE9E9)
                          : (isDark ? const Color(0xFF24262B) : Colors.white),
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(
                        color: selected
                            ? Colors.redAccent
                            : (isDark
                                  ? Colors.white24
                                  : const Color(0xFFE0E0E0)),
                      ),
                    ),
                    child: Text(
                      title,
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: selected
                            ? Colors.redAccent
                            : (isDark ? Colors.white : Colors.black87),
                      ),
                    ),
                  ),
                );
              }

              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    height: 42,
                    decoration: BoxDecoration(
                      color: isDark ? const Color(0xFF24262B) : Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: isDark
                            ? Colors.white24
                            : const Color(0xFFD9D9D9),
                      ),
                    ),
                    child: TextField(
                      controller: searchController,
                      onSubmitted: (value) {
                        provider.fetchMediaImages(
                          value.trim().isEmpty ? defaultQuery : value.trim(),
                        );
                      },
                      onChanged: (value) {
                        if (value.trim().isEmpty) {
                          provider.fetchMediaImages(defaultQuery);
                        }
                      },
                      decoration: InputDecoration(
                        hintText: 'Search images...',
                        prefixIcon: const Icon(Icons.search_rounded, size: 20),
                        suffixIcon: IconButton(
                          icon: const Icon(Icons.search_rounded, size: 20),
                          onPressed: () {
                            final value = searchController.text.trim();
                            provider.fetchMediaImages(
                              value.isEmpty ? defaultQuery : value,
                            );
                          },
                        ),
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 10,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    height: 38,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: imageCategories.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 8),
                      itemBuilder: (_, index) {
                        final category = imageCategories[index];
                        return imageChip(
                          category['title']!,
                          category['query']!,
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 12),
                  Expanded(
                    child: provider.isMediaImagesLoading
                        ? const Center(
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : images.isEmpty
                        ? const Center(
                            child: Text(
                              'No images found',
                              style: TextStyle(color: Colors.grey),
                            ),
                          )
                        : GridView.builder(
                            padding: const EdgeInsets.only(bottom: 20),
                            gridDelegate:
                                const SliverGridDelegateWithFixedCrossAxisCount(
                                  crossAxisCount: 2,
                                  crossAxisSpacing: 10,
                                  mainAxisSpacing: 10,
                                  childAspectRatio: 0.92,
                                ),
                            itemCount: images.length,
                            itemBuilder: (_, index) {
                              return GestureDetector(
                                onTap: () {
                                  provider.addImage(
                                    images[index],
                                    isLocal: false,
                                  );
                                  Navigator.pop(modalContext);
                                },
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: isDark
                                        ? const Color(0xFF24262B)
                                        : const Color(0xFFF7F7F7),
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(
                                      color: isDark
                                          ? Colors.white12
                                          : const Color(0xFFE6E6E6),
                                    ),
                                  ),
                                  clipBehavior: Clip.antiAlias,
                                  child: Image.network(
                                    images[index],
                                    fit: BoxFit.cover,
                                    errorBuilder: (_, __, ___) =>
                                        const SizedBox.shrink(),
                                    loadingBuilder: (context, child, progress) {
                                      if (progress == null) return child;
                                      return const Center(
                                        child: SizedBox(
                                          width: 18,
                                          height: 18,
                                          child: CircularProgressIndicator(
                                            strokeWidth: 1.6,
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                                ),
                              );
                            },
                          ),
                  ),
                ],
              );
            }

            return Container(
              height: MediaQuery.of(sheetContext).size.height * .72,
              decoration: BoxDecoration(
                color: isDark ? const Color(0xFF17191E) : Colors.white,
                borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(24),
                ),
              ),
              child: SafeArea(
                top: false,
                child: Column(
                  children: [
                    const SizedBox(height: 10),
                    Container(
                      width: 42,
                      height: 4,
                      decoration: BoxDecoration(
                        color: isDark ? Colors.white38 : Colors.black26,
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(16, 14, 12, 4),
                      child: Row(
                        children: [
                          if (expandedCategory != null)
                            IconButton(
                              onPressed: () =>
                                  setSheetState(() => expandedCategory = null),
                              icon: const Icon(Icons.arrow_back_rounded),
                            ),
                          Expanded(
                            child: Text(
                              'Media',
                              style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.w800,
                                color: isDark ? Colors.white : Colors.black,
                              ),
                            ),
                          ),
                          IconButton(
                            onPressed: () {
                              sheetOpen = false;
                              Navigator.pop(modalContext);
                            },
                            icon: const Icon(
                              Icons.close_rounded,
                              color: Colors.red,
                              size: 28,
                            ),
                          ),
                        ],
                      ),
                    ),
                    if (expandedCategory == null)
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: Row(
                          children: [
                            _backgroundTab(
                              title: 'UPLOADS',
                              selected: selectedTab == 0,
                              onTap: () => setSheetState(() => selectedTab = 0),
                            ),
                            const SizedBox(width: 24),
                            _backgroundTab(
                              title: 'ELEMENTS',
                              selected: selectedTab == 1,
                              onTap: () => setSheetState(() => selectedTab = 1),
                            ),
                            const SizedBox(width: 24),
                            _backgroundTab(
                              title: 'IMAGES',
                              selected: selectedTab == 2,
                              onTap: () {
                                setSheetState(() => selectedTab = 2);
                                if (provider.mediaImageAssets.isEmpty &&
                                    !provider.isMediaImagesLoading) {
                                  provider.fetchMediaImages('background');
                                }
                              },
                            ),
                          ],
                        ),
                      ),
                    Divider(
                      height: 18,
                      color: isDark ? Colors.white10 : Colors.black12,
                    ),
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: selectedTab == 0
                            ? uploadsView()
                            : selectedTab == 1
                            ? elementsView()
                            : imagesView(),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    ).whenComplete(() {
      sheetOpen = false;
      searchController.dispose();
    });
  }

  Widget _mediaPickerTile(bool isDark, IconData icon, String title) {
    return Container(
      width: 95,
      height: 95,
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF2A1A1C) : const Color(0xFFFFECEE),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: Colors.red, size: 28),
          const SizedBox(height: 6),
          Text(
            title,
            style: const TextStyle(
              color: Colors.red,
              fontSize: 10,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  void _showBackgroundBottomSheet(
    BuildContext context,
    EditorProvider provider,
    bool isDark,
  ) {
    int selectedTab = 0; // 0 images, 1 videos, 2 colors
    String searchQuery = 'background';
    String videoSearchQuery = 'background';
    bool sheetOpen = true;
    bool backgroundRequestStarted = false;
    final searchController = TextEditingController(text: searchQuery);
    final videoSearchController = TextEditingController(text: videoSearchQuery);

    const chips = <String>[
      'Abstract background',
      'Gradient',
      'Soft background',
      'Minimal',
      'Nature',
      'Texture',
    ];

    void fetchImages(String query, void Function(void Function()) setState) {
      final value = query.trim().isEmpty ? 'background' : query.trim();
      searchQuery = value;
      setState(() {});

      provider.fetchBackgroundAssets(value).then((_) {
        if (!sheetOpen) return;
        setState(() {});
      });
    }

    void fetchVideos(String query, void Function(void Function()) setState) {
      final value = query.trim().isEmpty ? 'background' : query.trim();
      videoSearchQuery = value;
      setState(() {});

      provider.fetchFreePikVideos(value).then((_) {
        if (!sheetOpen) return;
        setState(() {});
      });
    }

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (modalContext) {
        return StatefulBuilder(
          builder: (sheetContext, setSheetState) {
            if (selectedTab == 0 && !backgroundRequestStarted) {
              backgroundRequestStarted = true;
              Future.microtask(() async {
                await provider.fetchBackgroundAssets(searchQuery);
                if (sheetOpen) {
                  setSheetState(() {});
                }
              });
            }

            Widget searchBox({required bool forVideos}) {
              final controller = forVideos
                  ? videoSearchController
                  : searchController;
              final currentQuery = forVideos ? videoSearchQuery : searchQuery;
              return Container(
                height: 42,
                decoration: BoxDecoration(
                  color: isDark ? const Color(0xFF24262B) : Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: isDark ? Colors.white24 : const Color(0xFFD9D9D9),
                  ),
                ),
                child: TextField(
                  controller: controller,
                  onSubmitted: (value) => forVideos
                      ? fetchVideos(value, setSheetState)
                      : fetchImages(value, setSheetState),
                  onChanged: (value) {
                    if (forVideos) {
                      videoSearchQuery = value;
                    } else {
                      searchQuery = value;
                    }
                    setSheetState(() {});
                  },
                  style: TextStyle(
                    fontSize: 13,
                    color: isDark ? Colors.white : const Color(0xFF222222),
                  ),
                  decoration: InputDecoration(
                    hintText: forVideos
                        ? 'Search background videos...'
                        : 'Search background...',
                    hintStyle: TextStyle(
                      color: isDark ? Colors.white54 : const Color(0xFF8A8A8A),
                      fontSize: 13,
                    ),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 10,
                    ),
                    suffixIcon: IconButton(
                      icon: Icon(
                        Icons.search_rounded,
                        size: 21,
                        color: isDark
                            ? Colors.white70
                            : const Color(0xFF444444),
                      ),
                      onPressed: () => forVideos
                          ? fetchVideos(controller.text, setSheetState)
                          : fetchImages(controller.text, setSheetState),
                    ),
                  ),
                ),
              );
            }

            Widget chip(String title) {
              final selected = searchQuery.toLowerCase() == title.toLowerCase();
              return GestureDetector(
                onTap: () {
                  searchController.text = title;
                  fetchImages(title, setSheetState);
                },
                child: Container(
                  margin: const EdgeInsets.only(right: 8),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 7,
                  ),
                  decoration: BoxDecoration(
                    color: selected
                        ? (isDark
                              ? const Color(0xFF4A2024)
                              : const Color(0xFFFFE7E7))
                        : (isDark ? const Color(0xFF24262B) : Colors.white),
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(
                      color: selected
                          ? Colors.red.shade300
                          : (isDark ? Colors.white24 : const Color(0xFFE2E2E2)),
                    ),
                  ),
                  child: Text(
                    title,
                    style: TextStyle(
                      fontSize: 11.5,
                      fontWeight: FontWeight.w600,
                      color: selected
                          ? Colors.red
                          : (isDark ? Colors.white70 : const Color(0xFF444444)),
                    ),
                  ),
                ),
              );
            }

            Widget videoChip(String title) {
              final selected =
                  videoSearchQuery.toLowerCase() == title.toLowerCase();
              return GestureDetector(
                onTap: () {
                  videoSearchController.text = title;
                  fetchVideos(title, setSheetState);
                },
                child: Container(
                  margin: const EdgeInsets.only(right: 8),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 7,
                  ),
                  decoration: BoxDecoration(
                    color: selected
                        ? (isDark
                              ? const Color(0xFF4A2024)
                              : const Color(0xFFFFE7E7))
                        : (isDark ? const Color(0xFF24262B) : Colors.white),
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(
                      color: selected
                          ? Colors.red.shade300
                          : (isDark ? Colors.white24 : const Color(0xFFE2E2E2)),
                    ),
                  ),
                  child: Text(
                    title,
                    style: TextStyle(
                      fontSize: 11.5,
                      fontWeight: FontWeight.w600,
                      color: selected
                          ? Colors.red
                          : (isDark ? Colors.white70 : const Color(0xFF444444)),
                    ),
                  ),
                ),
              );
            }

            Widget imageCard(String url, double height) {
              return GestureDetector(
                onTap: () async {
                  final replaced = await _confirmReplaceBackground(
                    context,
                    provider,
                    url,
                  );
                  if (replaced && Navigator.canPop(modalContext)) {
                    Navigator.pop(modalContext);
                  }
                },
                child: Container(
                  height: height,
                  decoration: BoxDecoration(
                    color: isDark
                        ? const Color(0xFF24262B)
                        : const Color(0xFFF5F5F5),
                    borderRadius: BorderRadius.circular(9),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: Image.network(
                    url,
                    fit: BoxFit.cover,
                    width: double.infinity,
                    errorBuilder: (_, __, ___) => const SizedBox.shrink(),
                    loadingBuilder: (context, child, progress) {
                      if (progress == null) return child;
                      return const Center(
                        child: SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        ),
                      );
                    },
                  ),
                ),
              );
            }

            Widget imageResults() {
              if (provider.isBackgroundLoading) {
                return const Center(
                  child: CircularProgressIndicator(strokeWidth: 2),
                );
              }

              final items = provider.backgroundAssets
                  .where((u) {
                    final uri = Uri.tryParse(u);
                    return uri != null &&
                        (uri.scheme == 'http' || uri.scheme == 'https');
                  })
                  .take(24)
                  .toList();
              if (items.isEmpty) {
                return Center(
                  child: Text(
                    'No backgrounds found',
                    style: TextStyle(
                      color: isDark ? Colors.white54 : Colors.grey,
                      fontSize: 13,
                    ),
                  ),
                );
              }

              return ListView.builder(
                padding: const EdgeInsets.fromLTRB(4, 10, 4, 20),
                itemCount: (items.length / 2).ceil(),
                itemBuilder: (_, rowIndex) {
                  final leftIndex = rowIndex * 2;
                  final rightIndex = leftIndex + 1;
                  final rowHeight = rowIndex % 3 == 0
                      ? 170.0
                      : rowIndex % 3 == 1
                      ? 118.0
                      : 145.0;

                  return Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(child: imageCard(items[leftIndex], rowHeight)),
                        const SizedBox(width: 10),
                        Expanded(
                          child: rightIndex < items.length
                              ? imageCard(
                                  items[rightIndex],
                                  rowHeight * (rowIndex.isEven ? .78 : 1.18),
                                )
                              : const SizedBox.shrink(),
                        ),
                      ],
                    ),
                  );
                },
              );
            }

            Widget colorsView() {
              const colors = [
                Colors.white,
                Colors.black,
                Color(0xFFF44336),
                Color(0xFFE91E63),
                Color(0xFF9C27B0),
                Color(0xFF673AB7),
                Color(0xFF3F51B5),
                Color(0xFF2196F3),
                Color(0xFF03A9F4),
                Color(0xFF00BCD4),
                Color(0xFF009688),
                Color(0xFF4CAF50),
                Color(0xFF8BC34A),
                Color(0xFFFFEB3B),
                Color(0xFFFFC107),
                Color(0xFFFF9800),
                Color(0xFFFF5722),
                Color(0xFF795548),
              ];
              return GridView.builder(
                padding: const EdgeInsets.all(8),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 6,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                ),
                itemCount: colors.length,
                itemBuilder: (_, index) => InkWell(
                  borderRadius: BorderRadius.circular(10),
                  onTap: () {
                    provider.setBackgroundColor(colors[index]);
                    Navigator.pop(modalContext);
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      color: colors[index],
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.grey.shade300),
                    ),
                  ),
                ),
              );
            }

            Widget videosView() {
              if (!provider.isVideosLoading &&
                  provider.pexelsVideoAssets.isEmpty) {
                Future.microtask(
                  () => provider.fetchFreePikVideos(videoSearchQuery),
                );
              }
              if (provider.isVideosLoading) {
                return const Center(
                  child: CircularProgressIndicator(strokeWidth: 2),
                );
              }

              final assets = provider.pexelsVideoAssets;
              if (assets.isEmpty) {
                return const Center(
                  child: Text(
                    'No videos found',
                    style: TextStyle(color: Colors.grey),
                  ),
                );
              }

              return GridView.builder(
                padding: const EdgeInsets.fromLTRB(4, 10, 4, 20),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  childAspectRatio: 1.35,
                ),
                itemCount: assets.length,
                itemBuilder: (_, index) {
                  final asset = assets[index];
                  return GestureDetector(
                    onTap: () async {
                      final replace = await showDialog<bool>(
                        context: context,
                        builder: (dialogContext) => AlertDialog(
                          title: const Text('Replace Background?'),
                          content: const Text(
                            'The current background will be replaced with this video.',
                          ),
                          actions: [
                            TextButton(
                              onPressed: () =>
                                  Navigator.pop(dialogContext, false),
                              child: const Text('CANCEL'),
                            ),
                            FilledButton(
                              style: FilledButton.styleFrom(
                                backgroundColor: Colors.red,
                              ),
                              onPressed: () =>
                                  Navigator.pop(dialogContext, true),
                              child: const Text('REPLACE'),
                            ),
                          ],
                        ),
                      );
                      if (replace == true) {
                        final canvasSize = Size(
                          provider.canvasWidth > 0
                              ? provider.canvasWidth
                              : 1080.0,
                          provider.canvasHeight > 0
                              ? provider.canvasHeight
                              : 1080.0,
                        );
                        final sourceSize = await _resolveNetworkVideoSize(
                          asset.videoUrl,
                        );
                        provider.setBackgroundVideo(
                          asset.videoUrl,
                          canvasWidth: canvasSize.width,
                          canvasHeight: canvasSize.height,
                          sourceWidth: sourceSize?.width,
                          sourceHeight: sourceSize?.height,
                        );
                        provider.clearSelection();
                        if (mounted) setState(() {});
                        if (Navigator.canPop(modalContext))
                          Navigator.pop(modalContext);
                      }
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        color: isDark
                            ? const Color(0xFF24262B)
                            : const Color(0xFFF4F4F4),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      clipBehavior: Clip.antiAlias,
                      child: Stack(
                        fit: StackFit.expand,
                        children: [
                          if (asset.thumbnailUrl != null)
                            Image.network(
                              asset.thumbnailUrl!,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) =>
                                  const SizedBox.shrink(),
                            ),
                          Container(color: Colors.black26),
                          const Center(
                            child: Icon(
                              Icons.play_circle_fill_rounded,
                              size: 42,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              );
            }

            return Container(
              height: MediaQuery.of(sheetContext).size.height * .86,
              decoration: BoxDecoration(
                color: isDark ? const Color(0xFF17191E) : Colors.white,
                borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(24),
                ),
              ),
              child: SafeArea(
                top: false,
                child: Column(
                  children: [
                    const SizedBox(height: 10),
                    Container(
                      width: 42,
                      height: 4,
                      decoration: BoxDecoration(
                        color: isDark ? Colors.white38 : Colors.black26,
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(16, 14, 12, 4),
                      child: Row(
                        children: [
                          const Expanded(
                            child: Text(
                              'Background',
                              style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ),
                          IconButton(
                            onPressed: () {
                              sheetOpen = false;
                              Navigator.pop(modalContext);
                            },
                            icon: const Icon(
                              Icons.close_rounded,
                              color: Colors.red,
                              size: 30,
                            ),
                          ),
                        ],
                      ),
                    ),
                    if (selectedTab == 0) ...[
                      Padding(
                        padding: const EdgeInsets.fromLTRB(6, 4, 6, 8),
                        child: searchBox(forVideos: false),
                      ),
                      SizedBox(
                        height: 38,
                        child: ListView(
                          padding: const EdgeInsets.symmetric(horizontal: 6),
                          scrollDirection: Axis.horizontal,
                          children: chips.map(chip).toList(),
                        ),
                      ),
                    ] else if (selectedTab == 1) ...[
                      Padding(
                        padding: const EdgeInsets.fromLTRB(6, 4, 6, 8),
                        child: searchBox(forVideos: true),
                      ),
                      SizedBox(
                        height: 38,
                        child: ListView(
                          padding: const EdgeInsets.symmetric(horizontal: 6),
                          scrollDirection: Axis.horizontal,
                          children: [
                            'Abstract',
                            'Loop',
                            'Animation',
                            'Nature',
                            'Technology',
                            'Texture',
                          ].map(videoChip).toList(),
                        ),
                      ),
                    ],
                    Padding(
                      padding: const EdgeInsets.fromLTRB(6, 0, 6, 0),
                      child: Row(
                        children: [
                          _backgroundTab(
                            title: 'IMAGES',
                            selected: selectedTab == 0,
                            onTap: () => setSheetState(() => selectedTab = 0),
                          ),
                          const SizedBox(width: 24),
                          _backgroundTab(
                            title: 'VIDEOS',
                            selected: selectedTab == 1,
                            onTap: () => setSheetState(() => selectedTab = 1),
                          ),
                          const SizedBox(width: 24),
                          _backgroundTab(
                            title: 'COLORS',
                            selected: selectedTab == 2,
                            onTap: () => setSheetState(() => selectedTab = 2),
                          ),
                        ],
                      ),
                    ),
                    Divider(
                      height: 1,
                      color: isDark ? Colors.white10 : Colors.black12,
                    ),
                    Expanded(
                      child: selectedTab == 0
                          ? imageResults()
                          : selectedTab == 1
                          ? videosView()
                          : colorsView(),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    ).whenComplete(() {
      sheetOpen = false;
      searchController.dispose();
      videoSearchController.dispose();
    });
  }

  Widget _backgroundTab({
    required String title,
    required bool selected,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w800,
              color: selected ? Colors.black : Colors.grey,
            ),
          ),
          const SizedBox(height: 4),
          AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            height: 2,
            width: selected ? 46 : 0,
            color: Colors.red,
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<EditorProvider>();
    final themeProvider = context.watch<CustomThemeProvider>();
    final isDark = themeProvider.isDarkMode;
    final hasTemplateUid = (widget.templateUid?.trim() ?? '').isNotEmpty;
    if (hasTemplateUid && provider.isTemplateDetailLoading) {
      return Scaffold(
        backgroundColor: isDark ? const Color(0xFF121212) : Colors.white,
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(
                width: 42,
                height: 42,
                child: CircularProgressIndicator(strokeWidth: 3),
              ),
              const SizedBox(height: 16),
              AppText(
                'Loading template...',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: isDark ? Colors.white70 : Colors.black54,
                ),
              ),
            ],
          ),
        ),
      );
    }

    // IMPORTANT:
    // For an API template, canvas size MUST come from the template JSON/API.
    // Never use widget.resizeSize to resize an already-loaded template.
    // resizeSize is only used for a blank/new editor.
    final Size canvasSize = hasTemplateUid
        ? Size(
            provider.canvasWidth > 0 ? provider.canvasWidth : 1080.0,
            provider.canvasHeight > 0 ? provider.canvasHeight : 1080.0,
          )
        : _getCanvasSize();

    final double aspectRatio = canvasSize.width / canvasSize.height;

    return Scaffold(
      backgroundColor: isDark
          ? const Color(0xFF121212)
          : const Color(0xFFF0F2F5),
      appBar: AppBar(
        backgroundColor: isDark ? const Color(0xFF1E1E1E) : Colors.white,
        elevation: 1,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.red),
          onPressed: () => Navigator.pop(context),
        ),
        title: AppText(
          widget.resizeSize,
          style: TextStyle(
            color: isDark ? Colors.white : Colors.black,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.undo_rounded, color: Colors.grey),
            onPressed: () => provider.undo(),
          ),
          IconButton(
            tooltip: 'Pages',
            icon: const Icon(
              Icons.dashboard_customize_rounded,
              color: Colors.grey,
            ),
            onPressed: () => _showPagesSheet(context, provider, isDark),
          ),
          IconButton(
            tooltip: 'Copy Page',
            icon: const Icon(Icons.copy_all_rounded, color: Colors.grey),
            onPressed: () {
              provider.copyCurrentPage();
              Fluttertoast.showToast(
                msg: 'Page copied. Go to another page and paste.',
              );
            },
          ),
          IconButton(
            tooltip: 'Paste Page',
            icon: Icon(
              Icons.content_paste_rounded,
              color: provider.canPasteCopiedPage
                  ? Colors.grey
                  : Colors.grey.shade400,
            ),
            onPressed: !provider.canPasteCopiedPage
                ? null
                : () {
                    final pasted = provider.pasteCopiedPage();
                    if (pasted) {
                      Fluttertoast.showToast(
                        msg:
                            'Copied page pasted to Page ${provider.currentPageIndex + 1}',
                      );
                    }
                  },
          ),
          IconButton(
            tooltip: 'Download',

            icon: const Icon(Icons.download_rounded, color: Colors.red),
            onPressed: () => _showExportSheet(context),
          ),
          IconButton(
            icon: const Icon(Icons.redo_rounded, color: Colors.grey),
            onPressed: () => provider.redo(),
          ),
        ],
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: RepaintBoundary(
            key: _canvasKey,
            child: AspectRatio(
              aspectRatio: aspectRatio,
              child: Container(
                decoration: BoxDecoration(color: provider.backgroundColor),
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    final double scaleX =
                        constraints.maxWidth / canvasSize.width;
                    final double scaleY =
                        constraints.maxHeight / canvasSize.height;

                    final backgroundItems = provider.items
                        .where(_isCanvasBackground)
                        .toList();

                    return ClipRect(
                      child: Stack(
                        clipBehavior: Clip.none,
                        children: [
                          Positioned.fill(
                            child: DecoratedBox(
                              decoration: BoxDecoration(
                                color: provider.backgroundColor,
                                gradient: provider.importedBackgroundGradient,
                              ),
                            ),
                          ),

                          if (backgroundItems.isNotEmpty)
                            _InteractiveBackgroundLayer(
                              key: ValueKey(backgroundItems.last.id),
                              item: backgroundItems.last,
                              scaleX: scaleX,
                              scaleY: scaleY,
                              canvasWidth: canvasSize.width,
                              canvasHeight: canvasSize.height,
                              onSelected: () {
                                final bg = backgroundItems.last;

                                // Select the background exactly like a normal
                                // image layer so the image editor toolbar opens.
                                provider.setSelectedItem(bg.type, bg.id);

                                if (mounted) {
                                  setState(() {
                                    _bottomNavIndex = 3;
                                  });
                                }
                              },
                            ),

                          // Render the selected item last. Its selection
                          // controls (especially the 3-dot menu) extend a
                          // little outside the image bounds; keeping the
                          // selected item on top prevents another overlapping
                          // image/text layer from stealing that touch.
                          ...(() {
                            final normalItems = provider.items
                                .where(
                                  (item) =>
                                      !_isCanvasBackground(item) &&
                                      item.id != provider.selectedItemId,
                                )
                                .toList();
                            final selectedItems = provider.items
                                .where(
                                  (item) =>
                                      !_isCanvasBackground(item) &&
                                      item.id == provider.selectedItemId,
                                )
                                .toList();
                            final orderedItems = [
                              ...normalItems,
                              ...selectedItems,
                            ];

                            return orderedItems.map((item) {
                              return Positioned(
                                left: item.position.dx * scaleX,
                                top: item.position.dy * scaleY,
                                child: Transform.scale(
                                  scale: scaleX,
                                  alignment: Alignment.topLeft,
                                  child: EditableItemWidget(
                                    item: item,
                                    onItemSelected: (type, id) {
                                      provider.setSelectedItem(type, id);
                                    },
                                  ),
                                ),
                              );
                            });
                          })(),

                          // -----------------------------------------
                          // FRAME ATTACHED TO SELECTED IMAGE
                          // -----------------------------------------
                          if (provider.selectedFrameUrl != null &&
                              provider.selectedItemId != null)
                            Builder(
                              builder: (_) {
                                final selected = provider.items
                                    .where(
                                      (e) => e.id == provider.selectedItemId,
                                    )
                                    .toList();

                                if (selected.isEmpty ||
                                    selected.first.type != 'image') {
                                  return const SizedBox.shrink();
                                }

                                final item = selected.first;
                                return Positioned(
                                  left: item.position.dx * scaleX,
                                  top: item.position.dy * scaleY,
                                  width: item.width * item.scale * scaleX,
                                  height: item.height * item.scale * scaleY,
                                  child: IgnorePointer(
                                    child: Transform.rotate(
                                      angle: item.rotation.isFinite
                                          ? item.rotation
                                          : 0.0,
                                      child: Image.asset(
                                        provider.selectedFrameUrl!,
                                        fit: BoxFit.fill,
                                      ),
                                    ),
                                  ),
                                );
                              },
                            ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ),
          ),
        ),
      ),
      bottomNavigationBar: _buildEditorBottomBar(context, provider, isDark),
    );
  }

  Widget _buildEditorBottomBar(
    BuildContext context,
    EditorProvider provider,
    bool isDark,
  ) {
    final type = (provider.selectedItemType ?? '').toLowerCase();
    if (type == 'text' || type == 'textbox') {
      return _buildTextEditorToolbar(context, provider, isDark);
    }

    // IMPORTANT: There is already one persistent editor bottom sheet in this
    // screen. Do not create/open another modal bottom sheet when an object is
    // tapped. Every selectable visual object must switch that SAME existing
    // sheet to the appropriate controls.
    //
    // Image-like/template objects (including background images, raster groups,
    // and generic image/shape objects coming from Fabric) use the existing
    // Image editor toolbar. This keeps CROP/PHOTO/FLIP/FILTER/MASK and the
    // existing Front/Back/Duplicate/Delete controls visible.
    if (type == 'image' ||
        type == 'background' ||
        type == 'video' ||
        type == 'raster_group' ||
        type == 'shape' ||
        type == 'rect' ||
        type == 'ellipse' ||
        type == 'circle' ||
        type == 'line' ||
        type == 'path' ||
        type == 'polygon' ||
        type == 'svg_group' ||
        type == 'svg_element' ||
        type == 'group') {
      return _buildImageEditorToolbar(context, provider, isDark);
    }

    return Container(
      height: 78,
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF1A1A1A) : Colors.black,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        child: Row(
          children: [
            _bottomTool(
              Image.asset("assets/images/templates.png"),
              'TEMPLATES',
              () => _showTemplatesBottomSheet(context, provider, isDark),
            ),
            _bottomTool(
              Image.asset("assets/images/brush.png"),
              'FRAMES',
              () => _showFramesBottomSheet(context, provider, isDark),
            ),
            /*_bottomTool(
             Image.asset("assets/images/text.png"),
              'MY BRAND',
                  () => _showMyBrandBottomSheet(context, provider, isDark),
            ),*/
            _bottomTool(
              Image.asset("assets/images/text.png"),
              'TEXT',
              () => _showTextStylesBottomSheet(context, provider, isDark),
            ),
            _bottomTool(
              Image.asset("assets/images/gallery.png"),
              'MEDIA',
              () => _showMediaBottomSheet(context, provider, isDark),
            ),
            _bottomTool(
              Image.asset("assets/images/gallery.png"),
              'BACKGROUND',
              () => _showBackgroundBottomSheet(context, provider, isDark),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _showTextColorPicker(
    BuildContext context,
    EditorProvider provider,
    String id,
    bool isDark,
  ) async {
    var hsv = HSVColor.fromColor(provider.textColor(id));

    final picked = await showDialog<Color>(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setState) {
            final current = hsv.toColor();

            return AlertDialog(
              title: const Text('Text Color'),
              content: SizedBox(
                width: 340,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      height: 54,
                      decoration: BoxDecoration(
                        color: current,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.grey.shade400),
                      ),
                    ),
                    const SizedBox(height: 16),

                    // Hue
                    Row(
                      children: [
                        const SizedBox(width: 42, child: Text('Hue')),
                        Expanded(
                          child: Slider(
                            min: 0,
                            max: 360,
                            value: hsv.hue,
                            onChanged: (v) {
                              setState(() {
                                hsv = hsv.withHue(v);
                              });
                            },
                          ),
                        ),
                      ],
                    ),

                    // Saturation
                    Row(
                      children: [
                        const SizedBox(width: 42, child: Text('Sat')),
                        Expanded(
                          child: Slider(
                            min: 0,
                            max: 1,
                            value: hsv.saturation,
                            onChanged: (v) {
                              setState(() {
                                hsv = hsv.withSaturation(v);
                              });
                            },
                          ),
                        ),
                      ],
                    ),

                    // Brightness
                    Row(
                      children: [
                        const SizedBox(width: 42, child: Text('Val')),
                        Expanded(
                          child: Slider(
                            min: 0,
                            max: 1,
                            value: hsv.value,
                            onChanged: (v) {
                              setState(() {
                                hsv = hsv.withValue(v);
                              });
                            },
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 4),
                    Text(
                      '#${current.value.toRadixString(16).substring(2).toUpperCase()}',
                      style: const TextStyle(fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext),
                  child: const Text('CANCEL'),
                ),
                FilledButton(
                  onPressed: () => Navigator.pop(dialogContext, current),
                  child: const Text('APPLY'),
                ),
              ],
            );
          },
        );
      },
    );

    if (picked != null) {
      provider.updateTextColor(id, picked);
    }
  }

  Widget _buildTextEditorToolbar(
    BuildContext context,
    EditorProvider provider,
    bool isDark,
  ) {
    final id = provider.selectedItemId;
    if (id == null) return const SizedBox.shrink();

    // Use the complete Google Fonts catalog instead of a hard-coded
    // seven-font list. The existing horizontal toolbar can scroll through
    // the complete catalog.
    final fonts = GoogleFonts.asMap().keys.toList()..sort();

    final alignments = <Map<String, dynamic>>[
      {
        'label': 'LEFT',
        'icon': Icons.format_align_left_rounded,
        'value': TextAlign.left,
      },
      {
        'label': 'CENTER',
        'icon': Icons.format_align_center_rounded,
        'value': TextAlign.center,
      },
      {
        'label': 'RIGHT',
        'icon': Icons.format_align_right_rounded,
        'value': TextAlign.right,
      },
      {
        'label': 'JUSTIFY',
        'icon': Icons.format_align_justify_rounded,
        'value': TextAlign.justify,
      },
    ];

    final palette = <Color>[
      Colors.white,
      Colors.black,
      Colors.red,
      Colors.orange,
      Colors.amber,
      Colors.green,
      Colors.blue,
      Colors.purple,
      Colors.pink,
    ];

    return Container(
      height: 150,
      padding: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF1A1A1A) : Colors.black,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          SizedBox(
            height: 62,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 10),
              children: [
                _bottomTool(
                  Icons.edit_rounded,
                  'EDIT',
                  () => _showTextEditDialog(context, provider, id),
                ),
                _bottomTool(
                  Icons.format_size_rounded,
                  'SIZE',
                  () => _showTextSizeBottomSheet(context, provider, id, isDark),
                ),
                ...fonts.map(
                  (font) => _bottomTool(
                    Icons.font_download_rounded,
                    font,
                    () => provider.updateFontFamily(id, font),
                    selected:
                        (provider.items
                                    .firstWhere(
                                      (e) => e.id == id,
                                      orElse: () => provider.items.first,
                                    )
                                    .fontFamily ??
                                '')
                            .trim()
                            .toLowerCase() ==
                        font.toLowerCase(),
                  ),
                ),
                _bottomTool(
                  Icons.format_bold_rounded,
                  'BOLD',
                  () => provider.toggleTextBold(id),
                  selected: provider.textWeight(id) == FontWeight.bold,
                ),
                _bottomTool(
                  Icons.format_italic_rounded,
                  'ITALIC',
                  () => provider.toggleTextItalic(id),
                  selected: provider.textStyle(id) == FontStyle.italic,
                ),
                _bottomTool(
                  Icons.format_underlined_rounded,
                  'UNDERLINE',
                  () => provider.toggleTextUnderline(id),
                  selected: provider.textUnderline(id),
                ),
                ...alignments.map(
                  (item) => _bottomTool(
                    item['icon'] as IconData,
                    item['label'] as String,
                    () => provider.updateTextAlignment(
                      id,
                      item['value'] as TextAlign,
                    ),
                    selected: provider.textAlignment(id) == item['value'],
                  ),
                ),
                _bottomTool(
                  Icons.colorize_rounded,
                  'COLOR',
                  () => _showTextColorPicker(context, provider, id, isDark),
                ),
                ...palette.map(
                  (color) => _colorTool(
                    color,
                    () => provider.updateTextColor(id, color),
                  ),
                ),
                _bottomTool(
                  Icons.flip_to_front_rounded,
                  'FRONT',
                  () => provider.bringToFront(id),
                ),
                _bottomTool(
                  Icons.flip_to_back_rounded,
                  'BACK',
                  () => provider.sendToBack(id),
                ),
                _bottomTool(
                  Icons.copy_rounded,
                  'DUPLICATE',
                  () => provider.duplicateItem(id),
                ),
                _bottomTool(
                  Icons.delete_outline_rounded,
                  'DELETE',
                  () => provider.removeItem(id),
                  danger: true,
                ),
                _bottomTool(
                  Icons.close_rounded,
                  'CLOSE',
                  provider.clearSelection,
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 10),
              children: [
                _bottomSliderTool(
                  'FONT SIZE',
                  provider.items
                      .firstWhere(
                        (e) => e.id == id,
                        orElse: () => provider.items.first,
                      )
                      .fontSize,
                  8,
                  300,
                  (v) => provider.updateFontSize(id, v),
                ),
                _bottomSliderTool(
                  'LETTER SPACING',
                  provider.textLetterSpacing(id),
                  -2,
                  20,
                  (v) => provider.updateTextLetterSpacing(id, v),
                ),
                _bottomSliderTool(
                  'LINE SPACING',
                  provider.textLineSpacing(id),
                  .7,
                  3,
                  (v) => provider.updateTextLineSpacing(id, v),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _showTextSizeBottomSheet(
    BuildContext context,
    EditorProvider provider,
    String id,
    bool isDark,
  ) {
    final item = provider.items.firstWhere(
      (e) => e.id == id,
      orElse: () => provider.items.first,
    );

    double size = item.fontSize.isFinite
        ? item.fontSize.clamp(8.0, 300.0).toDouble()
        : 32.0;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (modalContext) {
        return StatefulBuilder(
          builder: (sheetContext, setSheetState) {
            final current = provider.items.firstWhere(
              (e) => e.id == id,
              orElse: () => item,
            );
            final currentSize = current.fontSize.isFinite
                ? current.fontSize.clamp(8.0, 300.0).toDouble()
                : size;

            return Container(
              padding: const EdgeInsets.fromLTRB(18, 12, 18, 24),
              decoration: BoxDecoration(
                color: isDark ? const Color(0xFF17191F) : Colors.white,
                borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(24),
                ),
              ),
              child: SafeArea(
                top: false,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 42,
                      height: 4,
                      decoration: BoxDecoration(
                        color: isDark ? Colors.white24 : Colors.black26,
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    const SizedBox(height: 14),
                    Row(
                      children: [
                        Icon(
                          Icons.format_size_rounded,
                          color: isDark ? Colors.white : Colors.black87,
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'Text Size',
                            style: TextStyle(
                              color: isDark ? Colors.white : Colors.black87,
                              fontSize: 17,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                        Text(
                          currentSize.round().toString(),
                          style: const TextStyle(
                            color: Colors.amber,
                            fontSize: 16,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ],
                    ),
                    SliderTheme(
                      data: SliderTheme.of(sheetContext).copyWith(
                        activeTrackColor: Colors.amber,
                        thumbColor: Colors.amber,
                        overlayColor: Colors.amber.withValues(alpha: .15),
                      ),
                      child: Slider(
                        value: currentSize,
                        min: 8,
                        max: 300,
                        onChanged: (v) {
                          size = v;
                          setSheetState(() {});
                          provider.updateFontSize(id, v);
                        },
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          '8',
                          style: TextStyle(
                            color: isDark ? Colors.white54 : Colors.black54,
                            fontSize: 11,
                          ),
                        ),
                        Text(
                          '300',
                          style: TextStyle(
                            color: isDark ? Colors.white54 : Colors.black54,
                            fontSize: 11,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildSvgGroupToolbar(
    BuildContext context,
    EditorProvider provider,
    bool isDark,
  ) {
    final id = provider.selectedItemId;
    if (id == null) return const SizedBox.shrink();
    final item = provider.items.firstWhere(
      (e) => e.id == id,
      orElse: () => provider.items.first,
    );

    return Container(
      height: 150,
      padding: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF1A1A1A) : Colors.black,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          SizedBox(
            height: 64,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 10),
              children: [
                _bottomTool(
                  Icons.unfold_more_rounded,
                  'UNGROUP ELEMENTS',
                  () => provider.ungroupSvgElement(id),
                ),
                _bottomTool(
                  Icons.flip_to_front_rounded,
                  'FRONT',
                  () => provider.bringToFront(id),
                ),
                _bottomTool(
                  Icons.flip_to_back_rounded,
                  'BACK',
                  () => provider.sendToBack(id),
                ),
                _bottomTool(
                  Icons.copy_rounded,
                  'DUPLICATE',
                  () => provider.duplicateItem(id),
                ),
                _bottomTool(
                  Icons.delete_outline_rounded,
                  'DELETE',
                  () => provider.removeItem(id),
                  danger: true,
                ),
                _bottomTool(
                  Icons.close_rounded,
                  'CLOSE',
                  provider.clearSelection,
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 10),
              children: [
                _bottomSliderTool(
                  'SCALE',
                  item.scale.clamp(.1, 10.0),
                  .1,
                  10,
                  (v) => provider.updateScale(id, v),
                ),
                _bottomSliderTool(
                  'ROTATION',
                  item.rotation.clamp(0.0, math.pi * 2),
                  0,
                  math.pi * 2,
                  (v) => provider.updateRotation(id, v),
                ),
                _bottomSliderTool(
                  'OPACITY',
                  item.opacity.clamp(0.0, 1.0),
                  0,
                  1,
                  (v) => provider.updateOpacity(id, v),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSvgElementToolbar(
    BuildContext context,
    EditorProvider provider,
    bool isDark,
  ) {
    final id = provider.selectedItemId;
    if (id == null) return const SizedBox.shrink();
    final item = provider.items.firstWhere(
      (e) => e.id == id,
      orElse: () => provider.items.first,
    );

    return Container(
      height: 150,
      padding: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF1A1A1A) : Colors.black,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          SizedBox(
            height: 64,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 10),
              children: [
                _bottomTool(
                  Icons.flip_to_front_rounded,
                  'FRONT',
                  () => provider.bringToFront(id),
                ),
                _bottomTool(
                  Icons.flip_to_back_rounded,
                  'BACK',
                  () => provider.sendToBack(id),
                ),
                _bottomTool(
                  Icons.copy_rounded,
                  'DUPLICATE',
                  () => provider.duplicateItem(id),
                ),
                _bottomTool(
                  Icons.delete_outline_rounded,
                  'DELETE',
                  () => provider.removeItem(id),
                  danger: true,
                ),
                _bottomTool(
                  Icons.close_rounded,
                  'CLOSE',
                  provider.clearSelection,
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 10),
              children: [
                _bottomSliderTool(
                  'SCALE',
                  item.scale.clamp(.1, 10.0),
                  .1,
                  10,
                  (v) => provider.updateScale(id, v),
                ),
                _bottomSliderTool(
                  'ROTATION',
                  item.rotation.clamp(0.0, math.pi * 2),
                  0,
                  math.pi * 2,
                  (v) => provider.updateRotation(id, v),
                ),
                _bottomSliderTool(
                  'OPACITY',
                  item.opacity.clamp(0.0, 1.0),
                  0,
                  1,
                  (v) => provider.updateOpacity(id, v),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMaskPreview(String url) {
    final clean = url.toLowerCase().split('?').first.split('#').first;
    final isSvg = clean.endsWith('.svg') || clean.endsWith('.svgz');

    if (isSvg) {
      return SvgPicture.network(
        url,
        fit: BoxFit.contain,
        placeholderBuilder: (_) => const Center(
          child: SizedBox(
            width: 18,
            height: 18,
            child: CircularProgressIndicator(strokeWidth: 1.5),
          ),
        ),
        errorBuilder: (_, __, ___) =>
            const Icon(Icons.broken_image_outlined, color: Colors.grey),
      );
    }

    return Image.network(
      url,
      fit: BoxFit.contain,
      errorBuilder: (_, __, ___) =>
          const Icon(Icons.broken_image_outlined, color: Colors.grey),
      loadingBuilder: (context, child, progress) {
        if (progress == null) return child;
        return const Center(
          child: SizedBox(
            width: 18,
            height: 18,
            child: CircularProgressIndicator(strokeWidth: 1.5),
          ),
        );
      },
    );
  }

  void _showApiMaskSheet(
    BuildContext context,
    EditorProvider provider,
    String itemId,
  ) {
    String query = '';
    bool requested = false;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (sheetContext) {
        return StatefulBuilder(
          builder: (sheetContext, setState) {
            if (!requested) {
              requested = true;
              WidgetsBinding.instance.addPostFrameCallback((_) async {
                await provider.fetchElementCategory(
                  'masks',
                  page: 1,
                  limit: 30,
                );
                if (sheetContext.mounted) setState(() {});
              });
            }

            final masks = provider.assetCategoryItems('masks');
            final q = query.trim().toLowerCase();
            final filtered = q.isEmpty
                ? masks
                : masks.where((m) => m.name.toLowerCase().contains(q)).toList();
            final loading = provider.isElementCategoryLoading('masks');

            return SizedBox(
              height: MediaQuery.of(sheetContext).size.height * .70,
              child: Column(
                children: [
                  const SizedBox(height: 10),
                  Container(
                    width: 42,
                    height: 5,
                    decoration: BoxDecoration(
                      color: Colors.black26,
                      borderRadius: BorderRadius.circular(20),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 14, 12, 10),
                    child: Row(
                      children: [
                        const Expanded(
                          child: Text(
                            'Image Masks',
                            style: TextStyle(
                              fontSize: 21,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        IconButton(
                          onPressed: () => Navigator.pop(sheetContext),
                          icon: const Icon(Icons.close_rounded),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: TextField(
                      onChanged: (value) => setState(() => query = value),
                      decoration: InputDecoration(
                        hintText: 'Search image masks',
                        prefixIcon: const Icon(Icons.search_rounded),
                        filled: true,
                        fillColor: Colors.grey.shade100,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(14),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Expanded(
                    child: loading && filtered.isEmpty
                        ? const Center(child: CircularProgressIndicator())
                        : filtered.isEmpty
                        ? const Center(child: Text('No mask found'))
                        : GridView.builder(
                            padding: const EdgeInsets.fromLTRB(16, 4, 16, 20),
                            gridDelegate:
                                const SliverGridDelegateWithFixedCrossAxisCount(
                                  crossAxisCount: 3,
                                  crossAxisSpacing: 10,
                                  mainAxisSpacing: 10,
                                  childAspectRatio: 1,
                                ),
                            itemCount: filtered.length,
                            itemBuilder: (_, index) {
                              final mask = filtered[index];
                              final url = provider.assetCdnUrl(mask.previewKey);
                              return InkWell(
                                borderRadius: BorderRadius.circular(14),
                                onTap: url.isEmpty
                                    ? null
                                    : () {
                                        // Apply the selected mask only to the image
                                        // whose Image > MASK toolbar opened this sheet.
                                        provider.setImageMask(
                                          itemId,
                                          name: mask.name,
                                          url: url,
                                        );
                                        Navigator.pop(sheetContext);
                                      },
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: Colors.grey.shade100,
                                    borderRadius: BorderRadius.circular(14),
                                    border: Border.all(color: Colors.black12),
                                  ),
                                  clipBehavior: Clip.antiAlias,
                                  child: url.isEmpty
                                      ? const Icon(
                                          Icons.image_not_supported_outlined,
                                        )
                                      : _buildMaskPreview(url),
                                ),
                              );
                            },
                          ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildImageEditorToolbar(
    BuildContext context,
    EditorProvider provider,
    bool isDark,
  ) {
    final id = provider.selectedItemId;
    if (id == null) return const SizedBox.shrink();

    final item = provider.items.firstWhere(
      (e) => e.id == id,
      orElse: () => provider.items.first,
    );

    const filters = <String>[
      'normal',
      'festive',
      'drama',
      'cali',
      'epic',
      'street',
      'grayscale',
      'rosie',
      'edge',
      'nordic',
      'selfie',
      'blues',
      'whimsical',
      'summer',
      'retro',
    ];

    return Container(
      height: 300,
      padding: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF1A1A1A) : Colors.black,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          SizedBox(
            height: 64,
            child: ListView(
              key: PageStorageKey<String>('image-tools-$id'),
              scrollDirection: Axis.horizontal,
              controller: ScrollController(),
              padding: const EdgeInsets.symmetric(horizontal: 10),
              children: [
                _bottomTool(Icons.wallpaper_rounded, 'REPLACE BG', () async {
                  final url = item.contentUrl;
                  if (url != null && url.isNotEmpty) {
                    await _confirmReplaceBackground(
                      context,
                      provider,
                      url,
                      selectedItemId: id,
                    );
                  }
                }),
                _bottomTool(
                  Icons.crop_rounded,
                  'CROP',
                  () => _cropSelectedImage(context, provider, id),
                ),
                _bottomTool(Icons.photo_library_rounded, 'PHOTO', () async {
                  final image = await ImagePicker().pickImage(
                    source: ImageSource.gallery,
                  );
                  if (image != null)
                    provider.addImage(image.path, isLocal: true);
                }),
                _bottomTool(
                  Icons.flip_rounded,
                  'FLIP',
                  () => setState(() => _showFlipOptions = !_showFlipOptions),
                  selected: _showFlipOptions,
                ),
                _bottomTool(
                  Icons.flip_to_front_rounded,
                  'FRONT',
                  () => provider.bringToFront(id),
                ),
                _bottomTool(
                  Icons.flip_to_back_rounded,
                  'BACK',
                  () => provider.sendToBack(id),
                ),
                _bottomTool(
                  Icons.copy_rounded,
                  'DUPLICATE',
                  () => provider.duplicateItem(id),
                ),
                _bottomTool(
                  Icons.delete_outline_rounded,
                  'DELETE',
                  () => provider.removeItem(id),
                  danger: true,
                ),
                _bottomTool(
                  Icons.close_rounded,
                  'CLOSE',
                  provider.clearSelection,
                ),
              ],
            ),
          ),
          if (_showFlipOptions)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(14, 2, 14, 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Padding(
                    padding: EdgeInsets.only(bottom: 6),
                    child: Text(
                      'Flip',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  Row(
                    children: [
                      Expanded(
                        child: _flipOption(
                          Icons.flip_rounded,
                          'Flip Horizontal',
                          () => provider.flipImageHorizontal(id),
                        ),
                      ),
                      Expanded(
                        child: _flipOption(
                          Icons.flip_rounded,
                          'Flip Vertical',
                          () => provider.flipImageVertical(id),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          SizedBox(
            height: 64,
            child: ListView(
              key: PageStorageKey<String>('image-filter-tools-$id'),
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 10),
              children: [
                _labelledHorizontalList(
                  'FILTER',
                  filters,
                  (value) => provider.setImageFilter(id, value),
                  selected: item.filterType,
                ),
                _bottomTool(
                  Icons.category_rounded,
                  'MASK',
                  () => _showApiMaskSheet(context, provider, id),
                  selected:
                      provider.imageMaskUrl(id) != null ||
                      (item.text != null &&
                          item.text!.trim().isNotEmpty &&
                          item.text != 'image'),
                ),
              ],
            ),
          ),
          const SizedBox(height: 4),
          Expanded(
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 10),
              children: [
                _bottomSliderTool(
                  'FILTER INTENSITY',
                  provider.imageFilterIntensity(id),
                  0,
                  1,
                  (v) => provider.updateImageFilterIntensity(id, v),
                ),
                _bottomSliderTool(
                  'BRIGHTNESS',
                  item.brightness,
                  -1,
                  1,
                  (v) =>
                      provider.updateImageColorAdjustments(id, brightness: v),
                ),
                _bottomSliderTool(
                  'CONTRAST',
                  item.contrast,
                  .5,
                  2,
                  (v) => provider.updateImageColorAdjustments(id, contrast: v),
                ),
                _bottomSliderTool(
                  'TINT',
                  provider.imageTint(id),
                  -100,
                  100,
                  (v) => provider.updateImageTint(id, v),
                ),
                _bottomSliderTool(
                  'SATURATION',
                  item.saturation,
                  0,
                  2,
                  (v) =>
                      provider.updateImageColorAdjustments(id, saturation: v),
                ),
                _bottomSliderTool(
                  'BLUR',
                  provider.imageBlur(id),
                  0,
                  20,
                  (v) => provider.updateImageBlur(id, v),
                ),
                _bottomSliderTool(
                  'SCALE',
                  item.scale.clamp(.5, 3.0),
                  .5,
                  3,
                  (v) => provider.updateScale(id, v),
                ),
                _bottomSliderTool(
                  'ROTATION',
                  item.rotation.clamp(0.0, math.pi * 2),
                  0,
                  math.pi * 2,
                  (v) => provider.updateRotation(id, v),
                ),
                _bottomSliderTool(
                  'OPACITY',
                  item.opacity.clamp(0.0, 1.0),
                  0,
                  1,
                  (v) => provider.updateOpacity(id, v),
                ),
                _outlineStyleTools(
                  provider.outlineStyle(id),
                  (style) => provider.updateOutlineStyle(id, style),
                ),
                _bottomSliderTool(
                  'OUTLINE WIDTH',
                  item.outlineWidth.clamp(0.0, 20.0),
                  0,
                  20,
                  (v) => provider.updateOutline(id, v, Colors.white),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _outlineStyleTools(String selected, ValueChanged<String> onChanged) {
    const styles = <String>['none', 'solid', 'dashed', 'dotted', 'fine_dotted'];
    const labels = <String>['None', 'Solid', 'Dashed', 'Dotted', 'Fine Dotted'];

    return SizedBox(
      width: 310,
      height: 88,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.only(left: 4, bottom: 5),
            child: Text(
              'OUTLINE',
              style: TextStyle(
                color: Colors.white70,
                fontSize: 11,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          SizedBox(
            height: 58,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: styles.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (_, index) {
                final style = styles[index];
                final isSelected = selected == style;
                return GestureDetector(
                  onTap: () => onChanged(style),
                  child: SizedBox(
                    width: 54,
                    child: Column(
                      children: [
                        Container(
                          width: 50,
                          height: 38,
                          decoration: BoxDecoration(
                            color: isSelected
                                ? const Color(0xFFFFECEE)
                                : const Color(0xFFF3F3F3),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: isSelected
                                  ? const Color(0xFFE53935)
                                  : Colors.transparent,
                            ),
                          ),
                          child: CustomPaint(
                            painter: _OutlineStylePreviewPainter(style),
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          labels[index],
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: isSelected
                                ? const Color(0xFFE53935)
                                : Colors.white70,
                            fontSize: 8,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _flipOption(IconData icon, String label, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 19, color: Colors.white70),
            const SizedBox(width: 7),
            Flexible(
              child: Text(
                label,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _bottomTool(
    dynamic icon,
    String label,
    VoidCallback onTap, {
    bool selected = false,
    bool danger = false,
  }) {
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          constraints: const BoxConstraints(minWidth: 58),
          padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
          decoration: BoxDecoration(
            color: danger
                ? Colors.red.withValues(alpha: .16)
                : selected
                ? Colors.amber.withValues(alpha: .18)
                : const Color(0xFF1F232C),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: selected ? Colors.amber : Colors.white10),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Icon OR Image.asset
              if (icon is IconData)
                Icon(icon, color: danger ? Colors.red : Colors.white, size: 19)
              else if (icon is Widget)
                SizedBox(width: 19, height: 19, child: icon),

              const SizedBox(height: 3),

              Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 8,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _colorTool(Color color, VoidCallback onTap) {
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          width: 46,
          padding: const EdgeInsets.symmetric(vertical: 7),
          decoration: BoxDecoration(
            color: const Color(0xFF1F232C),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 22,
                height: 22,
                decoration: BoxDecoration(
                  color: color,
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white54),
                ),
              ),
              const SizedBox(height: 3),
              const Text(
                'COLOR',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 7,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _labelledHorizontalList(
    String title,
    List<String> values,
    ValueChanged<String> onSelected, {
    String? selected,
  }) {
    return Container(
      margin: const EdgeInsets.only(right: 10),
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
      decoration: BoxDecoration(
        color: const Color(0xFF151820),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 5),
            child: Text(
              title,
              style: const TextStyle(
                color: Colors.amber,
                fontSize: 8,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
          ...values.map(
            (value) => Padding(
              padding: const EdgeInsets.only(left: 4),
              child: InkWell(
                onTap: () => onSelected(value),
                borderRadius: BorderRadius.circular(9),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 6,
                  ),
                  decoration: BoxDecoration(
                    color: selected == value
                        ? Colors.amber.withValues(alpha: .18)
                        : const Color(0xFF252A34),
                    borderRadius: BorderRadius.circular(9),
                    border: Border.all(
                      color: selected == value ? Colors.amber : Colors.white10,
                    ),
                  ),
                  child: Text(
                    value.toUpperCase(),
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 7,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _bottomSliderTool(
    String title,
    double value,
    double min,
    double max,
    ValueChanged<double> onChanged,
  ) {
    final safeValue = value.isFinite ? value.clamp(min, max).toDouble() : min;
    return Container(
      width: 175,
      margin: const EdgeInsets.only(right: 10),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: const Color(0xFF1F232C),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                title,
                style: const TextStyle(
                  color: Colors.white70,
                  fontSize: 8,
                  fontWeight: FontWeight.w800,
                ),
              ),
              Text(
                title == 'OPACITY'
                    ? '${(safeValue * 100).round()}%'
                    : safeValue.toStringAsFixed(1),
                style: const TextStyle(
                  color: Colors.amber,
                  fontSize: 8,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
          Expanded(
            child: Slider(
              value: safeValue,
              min: min,
              max: max,
              activeColor: Colors.amber,
              onChanged: onChanged,
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _showTextEditDialog(
    BuildContext context,
    EditorProvider provider,
    String itemId,
  ) async {
    final item = provider.items.firstWhere(
      (e) => e.id == itemId,
      orElse: () => provider.items.first,
    );
    final controller = TextEditingController(text: item.text ?? '');

    // Let the dialog return the edited text first. Updating the provider
    // while the dialog route is still being deactivated can trigger
    // InheritedElement.debugDeactivated (_dependents.isEmpty) in Flutter.
    final newText = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Edit Text'),
        content: TextField(
          controller: controller,
          autofocus: true,
          maxLines: 5,
          decoration: const InputDecoration(
            hintText: 'Enter text',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('CANCEL'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(controller.text),
            child: const Text('SAVE'),
          ),
        ],
      ),
    );

    // The showDialog Future completes when the route is popped, but Flutter
    // may still be deactivating the dialog subtree in the same frame.
    // Updating the ChangeNotifier immediately here can therefore rebuild the
    // editor while the dialog's inherited elements still have dependents,
    // causing: InheritedElement.debugDeactivated (_dependents.isEmpty).
    // Wait until the current frame has completely finished before notifying
    // the editor provider.
    await WidgetsBinding.instance.endOfFrame;

    controller.dispose();

    if (!mounted) return;
    if (newText != null && newText != item.text) {
      provider.updateTextContent(itemId, newText);
    }
  }

  Widget _buildTextActionItem(IconData icon, String label) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, color: Colors.white, size: 20),
        const SizedBox(height: 5),
        AppText(
          label,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 9,
            fontWeight: FontWeight.w700,
            letterSpacing: 0.5,
          ),
        ),
      ],
    );
  }

  Widget _buildBottomNavItem(IconData icon, String label, bool isSelected) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(
          icon,
          color: isSelected ? Colors.white : Colors.grey.shade500,
          size: 22,
        ),
        const SizedBox(height: 5),
        AppText(
          label,
          style: TextStyle(
            color: isSelected ? Colors.white : Colors.grey.shade500,
            fontSize: 10,
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    );
  }

  Future<File?> _renderCurrentPagePng(EditorProvider provider) async {
    final boundary = _canvasKey.currentContext?.findRenderObject();
    if (boundary is! RenderRepaintBoundary) return null;

    final image = await boundary.toImage(pixelRatio: 3.0);
    final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
    if (byteData == null) return null;

    final bytes = byteData.buffer.asUint8List();
    final dir = await getTemporaryDirectory();
    final file = File(
      '${dir.path}/MMB_Page_${provider.currentPageIndex + 1}_${DateTime.now().millisecondsSinceEpoch}.png',
    );
    await file.writeAsBytes(bytes, flush: true);
    return file;
  }

  Future<void> _downloadCurrentPage(BuildContext context) async {
    final provider = context.read<EditorProvider>();
    try {
      final file = await _renderCurrentPagePng(provider);
      if (file == null) {
        Fluttertoast.showToast(msg: 'Canvas is not ready');
        return;
      }

      // Open the native Android/iOS save/share sheet for the rendered PNG.
      // The rendered file contains only the canvas, not selection dots/handles.
      if (!context.mounted) return;
      await Share.shareXFiles(
        [XFile(file.path, mimeType: 'image/png')],
        subject: 'MMB Design PNG',
        text: 'Save this MMB design image.',
      );
    } catch (e) {
      debugPrint('Download error: $e');
      Fluttertoast.showToast(msg: 'Unable to download design');
    }
  }

  Future<void> _exportCurrentPageJson(BuildContext context) async {
    final provider = context.read<EditorProvider>();
    try {
      final json = provider.exportCurrentPageJson();
      final prettyJson = const JsonEncoder.withIndent('  ').convert(json);
      final dir = await getTemporaryDirectory();
      final file = File(
        '${dir.path}/MMB_Page_${provider.currentPageIndex + 1}_${DateTime.now().millisecondsSinceEpoch}.json',
      );
      await file.writeAsString(prettyJson, flush: true);

      if (!context.mounted) return;
      await Share.shareXFiles(
        [XFile(file.path, mimeType: 'application/json')],
        subject: 'MMB Editor JSON',
        text: 'Exported MMB editor page JSON.',
      );
      Fluttertoast.showToast(msg: 'JSON ready to save/share');
    } catch (e) {
      debugPrint('JSON export error: $e');
      Fluttertoast.showToast(msg: 'Unable to export JSON');
    }
  }

  Future<void> _exportCurrentPageZip(BuildContext context) async {
    final provider = context.read<EditorProvider>();
    try {
      final pngFile = await _renderCurrentPagePng(provider);
      if (pngFile == null) {
        Fluttertoast.showToast(msg: 'Canvas is not ready');
        return;
      }

      final json = provider.exportCurrentPageJson();
      final jsonBytes = utf8.encode(
        const JsonEncoder.withIndent('  ').convert(json),
      );

      final archive = Archive();
      archive.addFile(
        ArchiveFile(
          'MMB_Page_${provider.currentPageIndex + 1}.json',
          jsonBytes.length,
          jsonBytes,
        ),
      );

      final pngBytes = await pngFile.readAsBytes();
      archive.addFile(
        ArchiveFile(
          'MMB_Page_${provider.currentPageIndex + 1}.png',
          pngBytes.length,
          pngBytes,
        ),
      );

      final zipBytes = ZipEncoder().encode(archive);

      final dir = await getTemporaryDirectory();
      final zipFile = File(
        '${dir.path}/MMB_Page_${provider.currentPageIndex + 1}_${DateTime.now().millisecondsSinceEpoch}.zip',
      );
      await zipFile.writeAsBytes(zipBytes, flush: true);

      if (!context.mounted) return;
      /*await SharePl.shareXFiles(
        [XFile(zipFile.path, mimeType: 'application/zip')],
        subject: 'MMB Editor Project ZIP',
        text: 'Exported MMB page JSON and PNG.',
      );*/
    } catch (e) {
      debugPrint('ZIP export error: $e');
      Fluttertoast.showToast(msg: 'Unable to create ZIP');
    }
  }

  void _showExportSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (modalContext) {
        return Container(
          padding: const EdgeInsets.fromLTRB(18, 12, 18, 24),
          decoration: const BoxDecoration(
            color: Color(0xFF111318),
            borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
          ),
          child: SafeArea(
            top: false,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 42,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.white24,
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                const SizedBox(height: 16),
                const Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'DOWNLOAD / EXPORT',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 17,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: _exportTile(
                        icon: Icons.image_rounded,
                        title: 'Image',
                        subtitle: 'PNG',
                        onTap: () {
                          Navigator.pop(modalContext);
                          _downloadCurrentPage(context);
                        },
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _exportTile(
                        icon: Icons.data_object_rounded,
                        title: 'JSON',
                        subtitle: 'Page data',
                        onTap: () {
                          Navigator.pop(modalContext);
                          _exportCurrentPageJson(context);
                        },
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _exportTile(
                        icon: Icons.folder_zip_rounded,
                        title: 'ZIP',
                        subtitle: 'JSON + PNG',
                        onTap: () {
                          Navigator.pop(modalContext);
                          _exportCurrentPageZip(context);
                        },
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _exportTile({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: .06),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white10),
        ),
        child: Column(
          children: [
            Icon(icon, color: const Color(0xFFFFC107), size: 28),
            const SizedBox(height: 8),
            Text(
              title,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 3),
            Text(
              subtitle,
              style: const TextStyle(color: Colors.white54, fontSize: 10),
            ),
          ],
        ),
      ),
    );
  }

  void _showPagesSheet(
    BuildContext context,
    EditorProvider provider,
    bool isDark,
  ) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (modalContext) {
        return StatefulBuilder(
          builder: (sheetContext, setModalState) {
            return Container(
              height: MediaQuery.of(context).size.height * .58,
              decoration: BoxDecoration(
                color: isDark ? const Color(0xFF17191E) : Colors.white,
                borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(28),
                ),
              ),
              padding: const EdgeInsets.fromLTRB(18, 14, 18, 20),
              child: Column(
                children: [
                  Container(
                    width: 42,
                    height: 4,
                    decoration: BoxDecoration(
                      color: Colors.grey.shade500,
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          'Pages',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                            color: isDark ? Colors.white : Colors.black,
                          ),
                        ),
                      ),
                      IconButton(
                        tooltip: 'Add page',
                        onPressed: () {
                          provider.addPage();
                          setModalState(() {});
                        },
                        icon: const Icon(
                          Icons.add_circle_rounded,
                          color: Colors.red,
                        ),
                      ),
                      IconButton(
                        tooltip: 'Duplicate page',
                        onPressed: () {
                          provider.duplicateCurrentPage();
                          setModalState(() {});
                        },
                        icon: const Icon(
                          Icons.library_add_rounded,
                          color: Colors.red,
                        ),
                      ),
                      IconButton(
                        tooltip: 'Delete page',
                        onPressed: () {
                          provider.deleteCurrentPage();
                          setModalState(() {});
                        },
                        icon: const Icon(
                          Icons.delete_outline_rounded,
                          color: Colors.red,
                        ),
                      ),
                    ],
                  ),
                  const Divider(),
                  Expanded(
                    child: GridView.builder(
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 3,
                            crossAxisSpacing: 12,
                            mainAxisSpacing: 12,
                            childAspectRatio: .82,
                          ),
                      itemCount: provider.pageCount,
                      itemBuilder: (_, index) {
                        final selected = index == provider.currentPageIndex;
                        return GestureDetector(
                          onTap: () {
                            provider.switchPage(index);
                            Navigator.pop(modalContext);
                          },
                          child: Container(
                            decoration: BoxDecoration(
                              color: isDark
                                  ? const Color(0xFF252932)
                                  : Colors.grey.shade100,
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(
                                color: selected
                                    ? Colors.red
                                    : Colors.transparent,
                                width: 2,
                              ),
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.description_rounded,
                                  size: 42,
                                  color: selected ? Colors.red : Colors.grey,
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  'Page ${index + 1}',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w700,
                                    color: isDark ? Colors.white : Colors.black,
                                  ),
                                ),
                                if (selected)
                                  const Padding(
                                    padding: EdgeInsets.only(top: 4),
                                    child: Text(
                                      'CURRENT',
                                      style: TextStyle(
                                        color: Colors.red,
                                        fontSize: 9,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}

class _TransformSelectionOverlay extends StatefulWidget {
  final EditorItem item;
  final double scaleX;
  final double scaleY;
  final bool isBackground;
  final double canvasWidth;
  final double canvasHeight;

  const _TransformSelectionOverlay({
    super.key,
    required this.item,
    required this.scaleX,
    required this.scaleY,
    required this.canvasWidth,
    required this.canvasHeight,
    this.isBackground = false,
  });

  @override
  State<_TransformSelectionOverlay> createState() =>
      _TransformSelectionOverlayState();
}

class _TransformSelectionOverlayState
    extends State<_TransformSelectionOverlay> {
  final GlobalKey _overlayKey = GlobalKey();

  double _startScale = 1.0;
  double _startRotation = 0.0;
  Offset _startPosition = Offset.zero;
  Offset _startFocalPoint = Offset.zero;
  Offset _rotationCenterGlobal = Offset.zero;
  double _rotationStartAngle = 0.0;

  // Actual source-image aspect ratio. The editor renders normal images with
  // BoxFit.contain, so the visible pixels can be smaller than item.width/height.
  double _imageAspectRatio = 1.0;
  bool _imageAspectReady = false;

  double _resizeStartScale = 1.0;
  Offset _resizeStartLocal = Offset.zero;
  Offset _resizeStartGlobal = Offset.zero;
  Offset _resizeStartPosition = Offset.zero;

  EditorProvider get _provider => context.read<EditorProvider>();

  // Normal media items are rendered inside a Transform.scale(scaleX), so
  // both axes use the canvas width scale. Background media is rendered by
  // _InteractiveBackgroundLayer with independent X/Y canvas scales.
  bool get _isText =>
      widget.item.type == 'text' || widget.item.type == 'textbox';

  Size get _naturalTextSize {
    final id = widget.item.id ?? '';
    final painter = TextPainter(
      text: TextSpan(
        text: widget.item.text ?? '',
        style: TextStyle(
          fontSize: widget.item.fontSize,
          color: widget.item.color ?? Colors.black,
          fontWeight: _provider.textWeight(id),
          fontStyle: _provider.textStyle(id),
          decoration: _provider.textUnderline(id)
              ? TextDecoration.underline
              : TextDecoration.none,
          letterSpacing: _provider.textLetterSpacing(id),
          height: _provider.textLineSpacing(id),
          fontFamily: (widget.item.fontFamily ?? '').trim().isEmpty
              ? null
              : widget.item.fontFamily!.trim(),
        ),
      ),
      maxLines: 1,
      textDirection: TextDirection.ltr,
    )..layout();
    return Size(math.max(1.0, painter.width), math.max(1.0, painter.height));
  }

  double get _baseVisualWidth =>
      _isText ? _naturalTextSize.width : widget.item.width;
  double get _baseVisualHeight =>
      _isText ? _naturalTextSize.height : widget.item.height;

  double get _width => _baseVisualWidth * widget.item.scale * widget.scaleX;

  double get _height =>
      _baseVisualHeight *
      widget.item.scale *
      (widget.isBackground ? widget.scaleY : widget.scaleX);

  // Text now has a natural-size layout box, so its selection rectangle starts
  // exactly at item.position and only compensates for center scaling using the
  // measured text dimensions. Media keeps the same behavior.
  // Fabric `left` / `top` are the object's top-left origin. The rendered
  // EditableItemWidget also scales from top-left, so the selection overlay
  // must use the exact same origin with no center compensation.
  double get _left => widget.item.position.dx * widget.scaleX;

  double get _top => widget.item.position.dy * widget.scaleY;

  @override
  void initState() {
    super.initState();
    _loadImageAspectRatio();
  }

  Future<void> _loadImageAspectRatio() async {
    if (widget.item.type != 'image') {
      return;
    }

    final url = (widget.item.contentUrl ?? '').trim();
    if (url.isEmpty) return;

    try {
      final ImageProvider provider;
      if (url.startsWith('file://') || url.startsWith('/data/')) {
        provider = FileImage(File(url.replaceFirst('file://', '')));
      } else if (url.startsWith('http://') || url.startsWith('https://')) {
        provider = NetworkImage(url);
      } else {
        provider = FileImage(File(url));
      }

      final stream = provider.resolve(const ImageConfiguration());
      late final ImageStreamListener listener;
      listener = ImageStreamListener(
        (info, _) {
          final w = info.image.width.toDouble();
          final h = info.image.height.toDouble();
          if (w > 0 && h > 0 && mounted) {
            setState(() {
              _imageAspectRatio = w / h;
              _imageAspectReady = true;
            });
          }
          stream.removeListener(listener);
        },
        onError: (_, __) {
          stream.removeListener(listener);
        },
      );
      stream.addListener(listener);
    } catch (_) {
      // Keep the editor box as the fallback for unsupported image sources.
    }
  }

  double get _baseBoxWidth =>
      _baseVisualWidth * widget.item.scale * widget.scaleX;

  double get _baseBoxHeight =>
      _baseVisualHeight *
      widget.item.scale *
      (widget.isBackground ? widget.scaleY : widget.scaleX);

  // Exact visible rectangle produced by BoxFit.contain inside the item's
  // layout box. This is the rectangle the selection UI must surround.
  // Selection bounds MUST match the exact rendered editor item bounds.
  // Do not calculate a second rectangle from the source image aspect ratio;
  // the image widget is already laid out inside this editor box.
  Rect get _visualRect {
    final boxW = _baseBoxWidth;
    final boxH = _baseBoxHeight;
    return Rect.fromLTWH(0, 0, boxW, boxH);
  }

  @override
  Widget build(BuildContext context) {
    final width = _baseBoxWidth;
    final height = _baseBoxHeight;
    final visual = _visualRect;

    if (!width.isFinite || !height.isFinite || width <= 0 || height <= 0) {
      return const SizedBox.shrink();
    }

    return Positioned(
      left: _left,
      top: _top,
      width: width,
      height: height,
      child: Transform.rotate(
        angle: widget.item.rotation.isFinite ? widget.item.rotation : 0.0,
        alignment: Alignment.center,
        child: Stack(
          key: _overlayKey,
          clipBehavior: Clip.none,
          children: [
            // Drag the selected image from anywhere inside the box.
            Positioned.fill(
              child: GestureDetector(
                behavior: HitTestBehavior.translucent,
                onPanStart: (details) {
                  _startPosition = widget.item.position;
                  _startFocalPoint = details.globalPosition;
                },
                onPanUpdate: (details) {
                  final dx =
                      (details.globalPosition.dx - _startFocalPoint.dx) /
                      widget.scaleX;
                  final dy =
                      (details.globalPosition.dy - _startFocalPoint.dy) /
                      widget.scaleY;

                  // Drag in CANVAS coordinates. The item itself is rendered
                  // inside an outer Transform.scale, so global finger delta
                  // must first be converted by the canvas scale.
                  //
                  // The stored position is the top-left of the layout box,
                  // matching Fabric's originX/originY. The item widget now
                  // scales from that top-left point, so no half-scale offset
                  // must be added to the drag position.
                  // FREE MOVE: match the reference video. Do not clamp the
                  // object to the canvas edges. The canvas clips the part that
                  // is outside, and the object can be dragged back in from any
                  // direction.
                  final nextX = _startPosition.dx + dx;
                  final nextY = _startPosition.dy + dy;

                  _provider.updateItemTransform(
                    widget.item.id ?? '',
                    position: Offset(nextX, nextY),
                    clampToFrame: false,
                  );
                },
              ),
            ),

            // Selection UI follows the ACTUAL visible image rectangle.
            // Normal images use BoxFit.contain, so a landscape image inside a
            // square item must not get a square selection box around the empty
            // top/bottom space.
            Positioned(
              left: visual.left,
              top: visual.top,
              width: visual.width,
              height: visual.height,
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  Positioned.fill(
                    child: IgnorePointer(
                      child: CustomPaint(painter: _ImageSelectionPainter()),
                    ),
                  ),
                  ...[
                    _buildHandle(
                      alignment: Alignment.topLeft,
                      cursor: SystemMouseCursors.resizeUpLeft,
                    ),
                    _buildHandle(
                      alignment: Alignment.topCenter,
                      cursor: SystemMouseCursors.resizeUp,
                    ),
                    _buildHandle(
                      alignment: Alignment.topRight,
                      cursor: SystemMouseCursors.resizeUpRight,
                    ),
                    _buildHandle(
                      alignment: Alignment.centerLeft,
                      cursor: SystemMouseCursors.resizeLeft,
                    ),
                    _buildHandle(
                      alignment: Alignment.centerRight,
                      cursor: SystemMouseCursors.resizeRight,
                    ),
                    _buildHandle(
                      alignment: Alignment.bottomLeft,
                      cursor: SystemMouseCursors.resizeDownLeft,
                    ),
                    _buildHandle(
                      alignment: Alignment.bottomCenter,
                      cursor: SystemMouseCursors.resizeDown,
                    ),
                    _buildHandle(
                      alignment: Alignment.bottomRight,
                      cursor: SystemMouseCursors.resizeDownRight,
                    ),
                  ],

                  // 3-dot control is outside the image selection rectangle.
                  Positioned(
                    left: visual.width + 10,
                    top: (visual.height / 2.0) - 26.0,
                    width: 52,
                    height: 52,
                    child: Material(
                      color: Colors.transparent,
                      shape: const CircleBorder(),
                      child: InkWell(
                        onTap: () {
                          final id = widget.item.id;
                          if (id != null && id.isNotEmpty) {
                            _provider.setSelectedItem(widget.item.type, id);
                          }
                        },
                        customBorder: const CircleBorder(),
                        child: Container(
                          width: 52,
                          height: 52,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: const Color(0xFF2196F3),
                              width: 2.5,
                            ),
                            boxShadow: const [
                              BoxShadow(
                                blurRadius: 6,
                                offset: Offset(0, 2),
                                color: Color(0x33000000),
                              ),
                            ],
                          ),
                          child: const Center(
                            child: Icon(
                              Icons.more_horiz_rounded,
                              size: 25,
                              color: Color(0xFF222222),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // Rotation handle follows the visible image rectangle.
            Positioned(
              left: visual.left + visual.width / 2 - 14,
              top: visual.top - 39,
              width: 28,
              height: 28,
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onPanStart: (details) {
                  _startRotation = widget.item.rotation;
                  _rotationCenterGlobal = _globalCenter();
                  _rotationStartAngle = math.atan2(
                    details.globalPosition.dy - _rotationCenterGlobal.dy,
                    details.globalPosition.dx - _rotationCenterGlobal.dx,
                  );
                },
                onPanUpdate: (details) {
                  final currentAngle = math.atan2(
                    details.globalPosition.dy - _rotationCenterGlobal.dy,
                    details.globalPosition.dx - _rotationCenterGlobal.dx,
                  );
                  final delta = _normalizeAngle(
                    currentAngle - _rotationStartAngle,
                  );

                  _provider.updateItemTransform(
                    widget.item.id ?? '',
                    rotation: _startRotation + delta,
                  );
                },
                child: const Center(child: _RotationHandleVisual()),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showItemQuickMenu(BuildContext context) {
    final id = widget.item.id;
    if (id == null || id.isEmpty) return;

    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) {
        final provider = _provider;
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _quickAction(
                  sheetContext,
                  Icons.flip_to_front_rounded,
                  'Front',
                  () => provider.bringToFront(id),
                ),
                _quickAction(
                  sheetContext,
                  Icons.copy_rounded,
                  'Duplicate',
                  () => provider.duplicateItem(id),
                ),
                _quickAction(
                  sheetContext,
                  Icons.delete_outline_rounded,
                  'Delete',
                  () => provider.removeItem(id),
                  destructive: true,
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _quickAction(
    BuildContext context,
    IconData icon,
    String label,
    VoidCallback onTap, {
    bool destructive = false,
  }) {
    return InkWell(
      onTap: () {
        Navigator.pop(context);
        onTap();
      },
      borderRadius: BorderRadius.circular(14),
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: destructive ? Colors.red : null),
            const SizedBox(height: 4),
            Text(
              label,
              style: TextStyle(
                fontSize: 11,
                color: destructive ? Colors.red : null,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Offset _globalCenter() {
    final box = _overlayKey.currentContext?.findRenderObject();
    final visual = _visualRect;
    if (box is RenderBox) {
      return box.localToGlobal(
        Offset(visual.left + visual.width / 2, visual.top + visual.height / 2),
      );
    }
    return Offset.zero;
  }

  double _normalizeAngle(double angle) {
    while (angle > math.pi) {
      angle -= math.pi * 2;
    }
    while (angle < -math.pi) {
      angle += math.pi * 2;
    }
    return angle;
  }

  Widget _buildHandle({
    required Alignment alignment,
    required MouseCursor cursor,
  }) {
    const handleSize = 34.0;

    return Align(
      alignment: alignment,
      child: SizedBox(
        width: handleSize,
        height: handleSize,
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onPanStart: (details) {
            _resizeStartScale = widget.item.scale.isFinite
                ? widget.item.scale
                : 1.0;
            _resizeStartPosition = widget.item.position;
            _resizeStartGlobal = details.globalPosition;
          },
          onPanUpdate: (details) {
            final baseWidth = math.max(1.0, widget.item.width);
            final baseHeight = math.max(1.0, widget.item.height);
            final globalDelta = details.globalPosition - _resizeStartGlobal;

            // Convert the finger movement into the item's local, unrotated
            // coordinate system. This keeps handles correct even after the
            // item has been rotated.
            final canvasDx = globalDelta.dx / widget.scaleX;
            final canvasDy =
                globalDelta.dy /
                (widget.isBackground ? widget.scaleY : widget.scaleX);
            final angle = widget.item.rotation.isFinite
                ? widget.item.rotation
                : 0.0;
            final cosA = math.cos(angle);
            final sinA = math.sin(angle);
            final dx = canvasDx * cosA + canvasDy * sinA;
            final dy = -canvasDx * sinA + canvasDy * cosA;

            double deltaScale;
            if (alignment.x == 0) {
              // Top/bottom center handles: vertical resize only.
              deltaScale = alignment.y == 1
                  ? dy / baseHeight
                  : -dy / baseHeight;
            } else if (alignment.y == 0) {
              // Left/right center handles: horizontal resize only.
              deltaScale = alignment.x == 1 ? dx / baseWidth : -dx / baseWidth;
            } else {
              // Corner handles: use the larger proportional movement while
              // preserving the item's aspect ratio.
              final sx = alignment.x == 1 ? dx / baseWidth : -dx / baseWidth;
              final sy = alignment.y == 1 ? dy / baseHeight : -dy / baseHeight;
              deltaScale = sx.abs() >= sy.abs() ? sx : sy;
            }

            final newScale = (_resizeStartScale + deltaScale)
                .clamp(0.02, 10.0)
                .toDouble();
            final scaleDelta = newScale - _resizeStartScale;

            // The item is rendered with a top-left scale origin, matching
            // Fabric's originX/originY. Keep the opposite edge/corner fixed:
            // right/bottom handles leave position unchanged; left/top
            // handles move the top-left by the amount the size changed.
            final anchorX = alignment.x == -1 ? -baseWidth * scaleDelta : 0.0;
            final anchorY = alignment.y == -1 ? -baseHeight * scaleDelta : 0.0;

            // Rotate the position correction back into canvas coordinates.
            final correctedX = anchorX * cosA - anchorY * sinA;
            final correctedY = anchorX * sinA + anchorY * cosA;
            final nextPosition = Offset(
              _resizeStartPosition.dx + correctedX,
              _resizeStartPosition.dy + correctedY,
            );

            _provider.updateItemTransform(
              widget.item.id ?? '',
              scale: newScale,
              position: nextPosition,
              // Do not clamp during resize. Clamping here changes the anchor
              // edge when the object is resized at the canvas boundary and
              // causes the exact jump visible in the previous implementation.
              clampToFrame: false,
            );
          },
          child: MouseRegion(
            cursor: cursor,
            child: const Center(child: _ResizeHandleVisual()),
          ),
        ),
      ),
    );
  }

  Offset _globalToOverlay(Offset globalPosition) {
    final box = _overlayKey.currentContext?.findRenderObject();
    if (box is RenderBox) {
      return box.globalToLocal(globalPosition);
    }
    return Offset(_width / 2, _height / 2);
  }
}

class _ResizeHandleVisual extends StatelessWidget {
  const _ResizeHandleVisual();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 11,
      height: 11,
      decoration: BoxDecoration(
        color: Colors.white,
        shape: BoxShape.circle,
        border: Border.all(color: const Color(0xFF2196F3), width: 2),
      ),
    );
  }
}

class _RotationHandleVisual extends StatelessWidget {
  const _RotationHandleVisual();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 11,
      height: 11,
      decoration: BoxDecoration(
        color: Colors.white,
        shape: BoxShape.circle,
        border: Border.all(color: const Color(0xFF2196F3), width: 2),
      ),
    );
  }
}

class _OutlineStylePreviewPainter extends CustomPainter {
  final String style;

  const _OutlineStylePreviewPainter(this.style);

  @override
  void paint(Canvas canvas, Size size) {
    final centerY = size.height / 2;
    final left = 7.0;
    final right = size.width - 7.0;

    if (style == 'none') {
      final paint = Paint()
        ..color = const Color(0xFFE53935)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.2;
      canvas.drawCircle(Offset(size.width / 2, centerY), 8, paint);
      canvas.drawLine(
        Offset(size.width / 2 - 6, centerY - 6),
        Offset(size.width / 2 + 6, centerY + 6),
        paint,
      );
      return;
    }

    final paint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.stroke
      ..strokeCap = style == 'dotted' || style == 'fine_dotted'
          ? StrokeCap.round
          : StrokeCap.butt
      ..strokeWidth = style == 'fine_dotted' ? 2.0 : 3.0;

    if (style == 'solid') {
      canvas.drawLine(Offset(left, centerY), Offset(right, centerY), paint);
      return;
    }

    final dash = style == 'dashed'
        ? 9.0
        : style == 'dotted'
        ? 2.5
        : 1.2;
    final gap = style == 'dashed'
        ? 6.0
        : style == 'dotted'
        ? 5.0
        : 3.5;

    double x = left;
    while (x < right) {
      final end = math.min(x + dash, right);
      if (style == 'dotted' || style == 'fine_dotted') {
        canvas.drawCircle(
          Offset(x + (end - x) / 2, centerY),
          paint.strokeWidth / 2,
          paint,
        );
      } else {
        canvas.drawLine(Offset(x, centerY), Offset(end, centerY), paint);
      }
      x = end + gap;
    }
  }

  @override
  bool shouldRepaint(covariant _OutlineStylePreviewPainter oldDelegate) =>
      oldDelegate.style != style;
}

class _ImageSelectionPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    const selectionColor = Color(0xFF2196F3);
    const strokeWidth = 1.8;

    final borderPaint = Paint()
      ..color = selectionColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth;

    canvas.drawRect(
      Rect.fromLTWH(
        strokeWidth / 2,
        strokeWidth / 2,
        size.width - strokeWidth,
        size.height - strokeWidth,
      ),
      borderPaint,
    );

    // Connector for rotation handle.
    final connectorPaint = Paint()
      ..color = selectionColor
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;

    canvas.drawLine(
      Offset(size.width / 2, 0),
      Offset(size.width / 2, -25),
      connectorPaint,
    );
  }

  @override
  bool shouldRepaint(covariant _ImageSelectionPainter oldDelegate) => false;
}

class _InteractiveBackgroundLayer extends StatefulWidget {
  final EditorItem item;
  final double scaleX;
  final double scaleY;
  final double canvasWidth;
  final double canvasHeight;
  final VoidCallback onSelected;

  const _InteractiveBackgroundLayer({
    super.key,
    required this.item,
    required this.scaleX,
    required this.scaleY,
    required this.canvasWidth,
    required this.canvasHeight,
    required this.onSelected,
  });

  @override
  State<_InteractiveBackgroundLayer> createState() =>
      _InteractiveBackgroundLayerState();
}

class _InteractiveBackgroundLayerState
    extends State<_InteractiveBackgroundLayer> {
  Offset _startPosition = Offset.zero;
  Offset _startFocalPoint = Offset.zero;

  double _startScale = 1.0;
  double _startRotation = 0.0;

  @override
  Widget build(BuildContext context) {
    final item = widget.item;

    // Backgrounds are canvas layers, not normal media layers. Their source
    // image dimensions/aspect ratio must never determine the displayed size.
    // Always use the editor canvas dimensions as the base size; scale/rotation
    // are then applied on top of that by the editor controls.
    final baseWidth = widget.canvasWidth;
    final baseHeight = widget.canvasHeight;

    // A newly applied/replaced background is anchored to the canvas origin.
    // If the user later transforms it, preserve the stored position.
    final isDefaultTransform =
        item.position.dx.abs() < 0.5 && item.position.dy.abs() < 0.5;

    return Positioned(
      left: (isDefaultTransform ? 0.0 : item.position.dx) * widget.scaleX,
      top: (isDefaultTransform ? 0.0 : item.position.dy) * widget.scaleY,
      width: baseWidth * item.scale * widget.scaleX,
      height: baseHeight * item.scale * widget.scaleY,
      child: GestureDetector(
        onTap: widget.onSelected,

        onScaleStart: (details) {
          widget.onSelected();

          _startPosition = item.position;
          _startFocalPoint = details.focalPoint;

          _startScale = item.scale;
          _startRotation = item.rotation;
        },

        onScaleUpdate: (details) {
          final provider = context.read<EditorProvider>();

          // Move
          final dx =
              (details.focalPoint.dx - _startFocalPoint.dx) / widget.scaleX;

          final dy =
              (details.focalPoint.dy - _startFocalPoint.dy) / widget.scaleY;

          final newPosition = Offset(
            _startPosition.dx + dx,
            _startPosition.dy + dy,
          );

          // Scale
          final newScale = (_startScale * details.scale).clamp(0.1, 10.0);

          // Rotation
          final newRotation = _startRotation + details.rotation;

          provider.updateItemTransform(
            item.id ?? '',
            position: newPosition,
            scale: newScale,
            rotation: newRotation,
          );
        },

        child: Stack(
          clipBehavior: Clip.none,
          children: [
            Transform.rotate(
              angle: item.rotation,
              child: Opacity(
                opacity: item.opacity.clamp(0.0, 1.0),
                child: FittedBox(
                  fit: BoxFit.fill,
                  child: SizedBox(
                    width: baseWidth,
                    height: baseHeight,
                    child: EditableItemWidget.buildStandaloneMediaContent(
                      context,
                      item,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              right: -18,
              top: -18,
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: widget.onSelected,
                  borderRadius: BorderRadius.circular(18),
                  child: Container(
                    width: 34,
                    height: 34,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: const Color(0xFF2196F3),
                        width: 1.5,
                      ),
                      boxShadow: const [
                        BoxShadow(
                          blurRadius: 6,
                          offset: Offset(0, 2),
                          color: Color(0x22000000),
                        ),
                      ],
                    ),
                    child: const Icon(
                      Icons.more_horiz_rounded,
                      size: 20,
                      color: Color(0xFF222222),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showBackgroundQuickMenu(BuildContext context) {
    final id = widget.item.id;
    if (id == null || id.isEmpty) return;

    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) {
        final provider = context.read<EditorProvider>();
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _backgroundAction(
                  sheetContext,
                  Icons.flip_to_front_rounded,
                  'Front',
                  () => provider.bringToFront(id),
                ),
                _backgroundAction(
                  sheetContext,
                  Icons.copy_rounded,
                  'Duplicate',
                  () => provider.duplicateItem(id),
                ),
                _backgroundAction(
                  sheetContext,
                  Icons.delete_outline_rounded,
                  'Delete',
                  () => provider.removeItem(id),
                  destructive: true,
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _backgroundAction(
    BuildContext context,
    IconData icon,
    String label,
    VoidCallback onTap, {
    bool destructive = false,
  }) {
    return InkWell(
      onTap: () {
        Navigator.pop(context);
        onTap();
      },
      borderRadius: BorderRadius.circular(14),
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: destructive ? Colors.red : null),
            const SizedBox(height: 4),
            Text(
              label,
              style: TextStyle(
                fontSize: 11,
                color: destructive ? Colors.red : null,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
