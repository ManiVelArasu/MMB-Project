import 'package:flutter/material.dart';
import 'package:mmb_app/component/appbar_widget.dart';
import 'package:mmb_app/core/api/api_endpoints.dart';
import 'package:provider/provider.dart';

import '../../../network/provider/business_provider.dart';

class FromLibraryScreen extends StatefulWidget {
  const FromLibraryScreen({super.key});

  @override
  State<FromLibraryScreen> createState() => _FromLibraryScreenState();
}

class _FromLibraryScreenState extends State<FromLibraryScreen> {
  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;

      context.read<BusinessProvider>().fetchLibraryImages('profile-pics');
    });
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<BusinessProvider>();

    return Scaffold(
      appBar: CustomAppBar(title: "From Library", showRightIcon: false),
      body: provider.isLoadingLibrary
          ? const Center(child: CircularProgressIndicator())
          : provider.libraryError != null
          ? Center(child: Text(provider.libraryError!))
          : provider.libraryImages.isEmpty
          ? const Center(child: Text('No images found'))
          : SafeArea(
            child: GridView.builder(
                padding: const EdgeInsets.all(12),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                ),
                itemCount: provider.libraryImages.length,
                itemBuilder: (context, index) {
                  final image = provider.libraryImages[index];
            
                  final imageKey = image['thumbnail_s3_key'] ?? image['s3_key'];
            
                  final imageUrl = '${ApiEndpoints.cdnImageUrl}/$imageKey';
            
                  debugPrint('Image key: $imageKey');
                  debugPrint('Image URL: $imageUrl');
            
                  return GestureDetector(
                    onTap: () {},
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Colors.grey.shade200,
                      ),
                      clipBehavior: Clip.antiAlias,
                      child: imageKey == null
                          ? const Icon(Icons.broken_image)
                          : Image.network(
                              imageUrl,
                              fit: BoxFit.cover,
                              width: double.infinity,
                              height: double.infinity,
                              errorBuilder: (context, error, stackTrace) {
                                debugPrint('Image loading error: $error');
                                return const Center(
                                  child: Icon(Icons.broken_image),
                                );
                              },
                            ),
                    ),
                  );
                },
              ),
          ),
    );
  }
}
