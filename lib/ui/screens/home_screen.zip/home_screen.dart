import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:mmb_app/ui/screens/template_edit.dart';
import 'package:mmb_app/ui/screens/video_widget/video_widget.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../Api Model/Template_model.dart';
import '../../Api Model/special_days.dart';
import '../../Api Model/templatecategories.dart';
import '../../component/custom_searchbar.dart';
import '../../component/custom_widget.dart';
import '../../component/home_appbar.dart';
import '../../core/api/api_endpoints.dart';
import '../../model/my_space_model.dart';
import '../../network/provider/custom_theme_provider.dart';
import '../../network/provider/common_provider.dart';
import '../../network/provider/home_screen_provider.dart';
import '../../network/provider/prpject_provider.dart';
import '../../utils/theme/app.colors.dart';
import '../../utils/theme/app.fonts.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final Size size = MediaQuery.of(context).size;
    final themeProvider = context.watch<CustomThemeProvider>();
    final commonProvider = context.watch<CommonProvider>();

    final me = commonProvider.me;
    final isDark = themeProvider.isDarkMode;

    return ChangeNotifierProvider(
      create: (_) => HomeScreenProvider(),
      builder: (context, provider) => Consumer<HomeScreenProvider>(
        builder: (context, homeScreenProvider, child) {
          if (homeScreenProvider.templateCategories.isEmpty) {
            return Scaffold(
              backgroundColor: Theme.of(context).scaffoldBackgroundColor,
              body: const Center(
                child: CircularProgressIndicator(color: Color(0xFFE53935)),
              ),
            );
          }
          return Scaffold(
            backgroundColor: Theme.of(context).scaffoldBackgroundColor,
            appBar: const HomeCustomAppBar(),
            body: SafeArea(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                child: Padding(
                  padding: EdgeInsets.symmetric(
                    horizontal: size.width * 0.04,
                    vertical: size.height * 0.015,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CustomSearchBar(
                        hintText: "Find your Industry",
                        prefixAsset: "assets/images/search.png",
                        suffixAsset: "assets/images/mic.png",
                        borderColor: AppColors.searchBorderColor,
                        onChanged: (query) {},
                      ),

                      SizedBox(height: 20.h),

                      _buildSectionHeader(
                        title: "My Space",
                        iconAsset: "assets/images/myspace.png",
                        hasViewAll: true,
                        isDark: isDark,
                      ),
                      SizedBox(height: 12.h),
                      _buildMySpaceList(homeScreenProvider, isDark, (item) {
                        switch (item.title) {
                          case "CREATE NEW":
                            _showCreateNewDialog(context, isDark);
                            break;

                          case "FOR YOU":
                            Navigator.pushNamed(context, "/ForYouScreen");
                            break;

                          case "FESTIVAL":
                            Navigator.pushNamed(
                              context,
                              "/TemplateListScreen",
                              arguments: {"type": "festival"},
                            );
                            break;

                          case "MY BRAND":
                            Navigator.pushNamed(
                              context,
                              "/TemplateListScreen",
                              arguments: {"type": "brand-series"},
                            );
                            break;

                          case "BRAND SERIES":
                            Navigator.pushNamed(context, "/BrandSeriesScreen");
                            break;

                          case "BRAND FRAMES":
                            Navigator.pushNamed(context, "/BrandFramesScreen");
                            break;

                          case "AI HUB":
                            Navigator.pushNamed(context, "/AiHubScreen");
                            break;
                        }
                      }),

                      SizedBox(height: 20.h),

                      Row(
                        children: [
                          Image.asset(
                            "assets/images/calendar.png",
                            height: 32.h,
                            width: 32.w,
                          ),
                          SizedBox(width: 8.w),
                          AppText(
                            "Special Days",
                            style: TextStyle(
                              color: isDark
                                  ? Colors.white
                                  : AppColors.darkBlack,
                              fontSize: AppFontSize.fontSize18,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          const Spacer(),
                          Material(
                            color: Colors.transparent,
                            child: InkWell(
                              borderRadius: BorderRadius.circular(18.r),
                              onTap: () {
                                Navigator.pushNamed(
                                  context,
                                  "/SpecialDaysScreen",
                                );
                              },
                              child: Padding(
                                padding: EdgeInsets.symmetric(
                                  horizontal: 4.w,
                                  vertical: 5.h,
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Text(
                                      'VIEW ALL',
                                      style: TextStyle(
                                        color: isDark
                                            ? Colors.grey.shade300
                                            : Colors.grey.shade600,
                                        fontSize: 12.sp,
                                        fontWeight: FontWeight.w800,
                                      ),
                                    ),
                                    SizedBox(width: 2.w),
                                    Icon(
                                      Icons.chevron_right_rounded,
                                      size: 19.sp,
                                      color: isDark
                                          ? Colors.grey.shade300
                                          : Colors.grey.shade600,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 12.h),

                      _buildSpecialDaysCalendar(homeScreenProvider),
                      SizedBox(height: 12.h),

                      Row(
                        children: [
                          Image.asset(
                            "assets/images/myzone.png",
                            height: 32.h,
                            width: 32.w,
                          ),
                          SizedBox(width: 8.w),
                          AppText(
                            "My Zone",
                            style: TextStyle(
                              color: isDark
                                  ? Colors.white
                                  : AppColors.darkBlack,
                              fontSize: AppFontSize.fontSize18,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 12.h),

                      _buildMyZoneSlider(homeScreenProvider, isDark, me: me),

                      SizedBox(height: 24.h),

                      _buildMyFrameHeader(isDark, context),

                      SizedBox(height: 16.h),

                      _buildLeadBannerSlider(
                        homeScreenProvider,
                        isDark,
                        me,
                        context,
                      ),

                      SizedBox(height: 20.h),

                      if (me?.data.accountType != "personal") ...[
                        _buildSectionHeader(
                          title: "My Brand Posts",
                          iconAsset: "assets/images/my_brand_posts.png",
                          hasViewAll: true,
                          isDark: isDark,
                        ),
                        SizedBox(height: 12.h),

                        SizedBox(
                          height: 45.h,
                          child: ListView.builder(
                            scrollDirection: Axis.horizontal,
                            itemCount:
                                homeScreenProvider.videoCategories.length,
                            physics: const BouncingScrollPhysics(),
                            itemBuilder: (context, index) {
                              bool isSelected =
                                  homeScreenProvider
                                      .selectedVideoCategoryIndex ==
                                  index;
                              return GestureDetector(
                                onTap: () => homeScreenProvider
                                    .updateVideoCategoryIndex(index),
                                child: Container(
                                  margin: EdgeInsets.only(right: 10.w),
                                  padding: EdgeInsets.symmetric(
                                    horizontal: 22.w,
                                    vertical: 10.h,
                                  ),
                                  decoration: BoxDecoration(
                                    color: isSelected
                                        ? const Color(0xFF555555)
                                        : (isDark
                                              ? const Color(0xFF1E1E1E)
                                              : Colors.white),
                                    borderRadius: BorderRadius.circular(30.r),
                                    border: Border.all(
                                      color: isSelected
                                          ? Colors.transparent
                                          : (isDark
                                                ? Colors.grey.shade700
                                                : Colors.grey.shade400),
                                      width: 1.5,
                                    ),
                                  ),
                                  child: Center(
                                    child: AppText(
                                      homeScreenProvider.videoCategories[index],
                                      style: TextStyle(
                                        color: isSelected
                                            ? Colors.white
                                            : (isDark
                                                  ? Colors.white70
                                                  : Colors.grey.shade800),
                                        fontSize: 14.sp,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                        ),

                        SizedBox(height: 16.h),

                        SizedBox(
                          height: 190.h,
                          child: ListView.builder(
                            scrollDirection: Axis.horizontal,
                            physics: const BouncingScrollPhysics(),
                            padding: EdgeInsets.symmetric(horizontal: 4.w),
                            itemCount:
                                homeScreenProvider.popularTemplates.length,
                            itemBuilder: (context, index) {
                              final item =
                                  homeScreenProvider.popularTemplates[index];

                              final thumbnailKey = item.iconS3Key ?? '';

                              final imageUrl = thumbnailKey.isEmpty
                                  ? ''
                                  : '${ApiEndpoints.cdnImageUrl}/$thumbnailKey';

                              return Padding(
                                padding: EdgeInsets.only(right: 12.w),
                                child: InkWell(
                                  onTap: () {
                                    Navigator.pushNamed(
                                      context,
                                      "/TemplateDetailScreen",
                                      arguments: {"templateUid": item.uid},
                                    );
                                  },
                                  borderRadius: BorderRadius.circular(20.r),
                                  child: Container(
                                    width: 145.w,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(20.r),
                                      color: isDark
                                          ? const Color(0xFF1E1E1E)
                                          : Colors.grey.shade100,
                                      border: Border.all(
                                        color: isDark
                                            ? Colors.grey.shade800
                                            : Colors.grey.shade300,
                                        width: 1.2,
                                      ),
                                    ),
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(20.r),
                                      child: imageUrl.isEmpty
                                          ? const Center(
                                              child: Icon(
                                                Icons.image_outlined,
                                                color: Colors.grey,
                                              ),
                                            )
                                          : buildProfileImage(imageUrl),
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                        SizedBox(height: 12.h),
                      ],

                      if (me?.data.accountType != "personal") ...[
                        _buildSectionHeader(
                          title: "My Brand Video Posts",
                          iconAsset: "assets/images/my_brand_posts.png",
                          hasViewAll: true,
                          isDark: isDark,
                        ),

                        SizedBox(height: 12.h),

                        SizedBox(
                          height: 38.h,
                          child: ListView.builder(
                            scrollDirection: Axis.horizontal,
                            itemCount:
                                homeScreenProvider.videoCategories.length,
                            physics: const BouncingScrollPhysics(),
                            itemBuilder: (context, index) {
                              bool isSelected =
                                  homeScreenProvider
                                      .selectedVideoCategoryIndex ==
                                  index;
                              return GestureDetector(
                                onTap: () => homeScreenProvider
                                    .updateVideoCategoryIndex(index),
                                child: Container(
                                  margin: EdgeInsets.only(right: 10.w),
                                  padding: EdgeInsets.symmetric(
                                    horizontal: 16.w,
                                    vertical: 8.h,
                                  ),
                                  decoration: BoxDecoration(
                                    color: isSelected
                                        ? const Color(0xFF555555)
                                        : (isDark
                                              ? const Color(0xFF1E1E1E)
                                              : Colors.white),
                                    borderRadius: BorderRadius.circular(20.r),
                                    border: Border.all(
                                      color: isSelected
                                          ? Colors.transparent
                                          : (isDark
                                                ? Colors.grey.shade700
                                                : Colors.grey.shade400),
                                      width: 1.2,
                                    ),
                                  ),
                                  child: Center(
                                    child: AppText(
                                      homeScreenProvider.videoCategories[index],
                                      style: TextStyle(
                                        color: isSelected
                                            ? Colors.white
                                            : (isDark
                                                  ? Colors.white70
                                                  : Colors.grey.shade800),
                                        fontSize: 12.sp,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                        ),

                        SizedBox(height: 16.h),
                        GridView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount:
                              homeScreenProvider.brandVideoPostsList.length,
                          gridDelegate:
                              SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 2,
                                crossAxisSpacing: 12.w,
                                mainAxisSpacing: 12.h,
                                childAspectRatio: 1.0,
                              ),
                          itemBuilder: (context, index) {
                            final videoData =
                                homeScreenProvider.brandVideoPostsList[index];
                            return BrandVideoCard(
                              thumbnailUrl: videoData["thumbnail"] ?? '',
                              videoUrl: videoData["videoUrl"] ?? '',
                            );
                          },
                        ),
                        SizedBox(height: 12.h),
                      ],

                      // பொதுவான டெம்ப்ளேட் வகைகள்
                      ListView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: homeScreenProvider.templateCategories.length,

                        itemBuilder: (context, index) {
                          final category =
                              homeScreenProvider.templateCategories[index];

                          final categoryName = category.name?.trim() ?? '';

                          final categoryLower = categoryName.toLowerCase();

                          final slug = category.slug?.trim() ?? '';

                          // ==========================================================
                          // SPECIAL CATEGORY CHECK
                          // ==========================================================

                          final bool isSpecialCategory =
                              categoryLower == 'celebrate moments' ||
                              categoryLower == 'devotional/daily posts' ||
                              categoryLower == 'devotional / daily posts';

                          // ==========================================================
                          // SPECIAL CATEGORY
                          // Celebrate Moments
                          // Devotional / Daily Posts
                          // ==========================================================

                          if (isSpecialCategory) {
                            if (category.children.isEmpty) {
                              return const SizedBox.shrink();
                            }

                            return Container(
                              width: double.infinity,
                              margin: EdgeInsets.only(top: 20.h),
                              padding: EdgeInsets.fromLTRB(
                                12.w,
                                14.h,
                                12.w,
                                16.h,
                              ),
                              decoration: BoxDecoration(
                                color: isDark
                                    ? const Color(0xFF171717)
                                    : const Color(0xFFFAF4FF),
                                border: Border(
                                  top: BorderSide(
                                    color: isDark
                                        ? Colors.grey.shade800
                                        : const Color(0xFFE9DDF0),
                                  ),
                                  bottom: BorderSide(
                                    color: isDark
                                        ? Colors.grey.shade800
                                        : const Color(0xFFE9DDF0),
                                  ),
                                ),
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  // ==================================================
                                  // PARENT TITLE
                                  // ==================================================

                                  AppText(
                                    categoryName,
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      fontSize: 14.sp,
                                      fontWeight: FontWeight.w800,
                                      color: isDark
                                          ? Colors.white
                                          : Colors.black,
                                    ),
                                  ),

                                  SizedBox(height: 12.h),

                                  // ==================================================
                                  // CHILDREN HORIZONTAL SCROLL
                                  // ==================================================
                                  SizedBox(
                                    height: 105.h,
                                    child: ListView.separated(
                                      scrollDirection: Axis.horizontal,
                                      physics: const BouncingScrollPhysics(),
                                      itemCount: category.children.length,

                                      separatorBuilder: (_, __) =>
                                          SizedBox(width: 14.w),

                                      itemBuilder: (context, childIndex) {
                                        final child =
                                            category.children[childIndex];

                                        final childName =
                                            child.name?.trim() ?? '';

                                        final childSlug =
                                            child.slug?.trim() ?? '';

                                        final thumbnailKey =
                                            child.iconS3Key?.trim() ?? '';

                                        final imageUrl = thumbnailKey.isEmpty
                                            ? ''
                                            : '${ApiEndpoints.cdnImageUrl}/$thumbnailKey';

                                        return SizedBox(
                                          width: 72.w,
                                          child: InkWell(
                                            borderRadius: BorderRadius.circular(
                                              30.r,
                                            ),

                                            onTap: () {
                                              debugPrint(
                                                "📂 CHILD CATEGORY: "
                                                "$childName",
                                              );

                                              debugPrint(
                                                "📂 CHILD SLUG: "
                                                "$childSlug",
                                              );

                                              Navigator.pushNamed(
                                                context,
                                                "/TemplateDetailScreen",
                                                arguments: {
                                                  "category": childSlug,
                                                  "categoryUid": child.uid,
                                                  "categoryName": child.name,
                                                },
                                              );
                                            },

                                            child: Column(
                                              children: [
                                                // ====================================
                                                // CHILD THUMBNAIL
                                                // ====================================

                                                ClipRRect(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                        10.r,
                                                      ),
                                                  child: Container(
                                                    width: 68.w,
                                                    height: 68.w,
                                                    color: isDark
                                                        ? const Color(
                                                            0xFF252525,
                                                          )
                                                        : Colors.grey.shade100,

                                                    child: imageUrl.isEmpty
                                                        ? const Icon(
                                                            Icons
                                                                .image_outlined,
                                                            color: Colors.grey,
                                                          )
                                                        : Image.network(
                                                            imageUrl,
                                                            width: 68.w,
                                                            height: 68.w,
                                                            fit: BoxFit.cover,

                                                            loadingBuilder:
                                                                (
                                                                  context,
                                                                  child,
                                                                  loadingProgress,
                                                                ) {
                                                                  if (loadingProgress ==
                                                                      null) {
                                                                    return child;
                                                                  }

                                                                  return const Center(
                                                                    child: CircularProgressIndicator(
                                                                      strokeWidth:
                                                                          1.5,
                                                                      color: Color(
                                                                        0xFFE53935,
                                                                      ),
                                                                    ),
                                                                  );
                                                                },

                                                            errorBuilder:
                                                                (
                                                                  context,
                                                                  error,
                                                                  stackTrace,
                                                                ) {
                                                                  debugPrint(
                                                                    "❌ CHILD IMAGE ERROR: "
                                                                    "$imageUrl",
                                                                  );

                                                                  return const Icon(
                                                                    Icons
                                                                        .broken_image_outlined,
                                                                    color: Colors
                                                                        .grey,
                                                                  );
                                                                },
                                                          ),
                                                  ),
                                                ),

                                                SizedBox(height: 6.h),

                                                // ====================================
                                                // CHILD NAME
                                                // ====================================
                                                AppText(
                                                  childName,
                                                  textAlign: TextAlign.center,
                                                  maxLines: 2,
                                                  style: TextStyle(
                                                    fontSize: 8.sp,
                                                    fontWeight: FontWeight.w800,
                                                    height: 1.05,
                                                    color: isDark
                                                        ? Colors.white
                                                        : Colors.black,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        );
                                      },
                                    ),
                                  ),
                                ],
                              ),
                            );
                          }

                          // ==========================================================
                          // NORMAL CATEGORY
                          // ==========================================================

                          if (slug.isEmpty) {
                            return const SizedBox.shrink();
                          }

                          final categoryIcon =
                              (category.iconS3Key?.trim().isNotEmpty ?? false)
                              ? '${ApiEndpoints.cdnImageUrl}/${category.iconS3Key}'
                              : '';

                          final templates = homeScreenProvider
                              .templatesForCategory(slug);

                          final isLoading = homeScreenProvider
                              .isTemplateLoading(slug);

                          // ==========================================================
                          // YOUTUBE THUMBNAIL CHECK
                          // ==========================================================

                          final bool isYoutubeThumbnail =
                              slug.toLowerCase() == 'youtube-thumbnails' ||
                              categoryLower == 'youtube thumbnails';

                          return Padding(
                            padding: EdgeInsets.only(top: 24.h),

                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,

                              children: [
                                // ======================================================
                                // CATEGORY HEADER
                                // ======================================================

                                _buildSectionHeader(
                                  title: categoryName,
                                  iconAsset: categoryIcon,
                                  hasViewAll: true,
                                  isDark: isDark,

                                  onViewAll: () {
                                    Navigator.pushNamed(
                                      context,
                                      "/TemplateDetailScreen",
                                      arguments: {"category": slug},
                                    );
                                  },
                                ),

                                SizedBox(height: 12.h),

                                // ======================================================
                                // LOADING
                                // ======================================================
                                if (isLoading)
                                  SizedBox(
                                    height: isYoutubeThumbnail ? 310.h : 165.h,

                                    child: const Center(
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                        color: Color(0xFFE53935),
                                      ),
                                    ),
                                  )
                                // ======================================================
                                // EMPTY
                                // ======================================================
                                else if (templates.isEmpty)
                                  SizedBox(
                                    height: isYoutubeThumbnail ? 250.h : 110.h,

                                    child: Center(
                                      child: AppText(
                                        'No templates available',

                                        style: TextStyle(
                                          color: isDark
                                              ? Colors.white54
                                              : Colors.black45,
                                          fontSize: 13.sp,
                                        ),
                                      ),
                                    ),
                                  )
                                // ======================================================
                                // YOUTUBE THUMBNAILS
                                // 16:9 OLD YOUTUBE SIZE
                                // 2 x 2 GRID + HORIZONTAL PAGE
                                // ======================================================
                                else if (isYoutubeThumbnail)
                                  SizedBox(
                                    height: 200.h,
                                    width: double.infinity,

                                    child: LayoutBuilder(
                                      builder: (context, constraints) {
                                        final double pageWidth =
                                            constraints.maxWidth;

                                        final double horizontalGap = 12.w;

                                        final double verticalGap = 12.h;

                                        // 2 cards per row
                                        final double cardWidth =
                                            (pageWidth - horizontalGap) / 2;

                                        // EXACT 16:9
                                        final double cardHeight =
                                            cardWidth * 9 / 16;

                                        // 4 cards per page
                                        final int pageCount =
                                            (templates.length / 4).ceil();

                                        return ListView.builder(
                                          scrollDirection: Axis.horizontal,

                                          physics:
                                              const BouncingScrollPhysics(),

                                          itemCount: pageCount,

                                          itemBuilder: (context, pageIndex) {
                                            final int startIndex =
                                                pageIndex * 4;

                                            return SizedBox(
                                              width: pageWidth,

                                              child: Padding(
                                                padding: EdgeInsets.only(
                                                  right:
                                                      pageIndex == pageCount - 1
                                                      ? 0
                                                      : 16.w,
                                                ),

                                                child: Column(
                                                  children: [
                                                    // ==============================
                                                    // ROW 1
                                                    // ==============================

                                                    SizedBox(
                                                      height: cardHeight,

                                                      child: Row(
                                                        children: [
                                                          Expanded(
                                                            child: _buildApiTemplateCard(
                                                              context,
                                                              templates[startIndex],
                                                              isDark,
                                                            ),
                                                          ),

                                                          SizedBox(
                                                            width:
                                                                horizontalGap,
                                                          ),

                                                          Expanded(
                                                            child:
                                                                startIndex + 1 <
                                                                    templates
                                                                        .length
                                                                ? _buildApiTemplateCard(
                                                                    context,
                                                                    templates[startIndex +
                                                                        1],
                                                                    isDark,
                                                                  )
                                                                : const SizedBox(),
                                                          ),
                                                        ],
                                                      ),
                                                    ),

                                                    SizedBox(
                                                      height: verticalGap,
                                                    ),

                                                    // ==============================
                                                    // ROW 2
                                                    // ==============================
                                                    SizedBox(
                                                      height: cardHeight,

                                                      child: Row(
                                                        children: [
                                                          Expanded(
                                                            child:
                                                                startIndex + 2 <
                                                                    templates
                                                                        .length
                                                                ? _buildApiTemplateCard(
                                                                    context,
                                                                    templates[startIndex +
                                                                        2],
                                                                    isDark,
                                                                  )
                                                                : const SizedBox(),
                                                          ),

                                                          SizedBox(
                                                            width:
                                                                horizontalGap,
                                                          ),

                                                          Expanded(
                                                            child:
                                                                startIndex + 3 <
                                                                    templates
                                                                        .length
                                                                ? _buildApiTemplateCard(
                                                                    context,
                                                                    templates[startIndex +
                                                                        3],
                                                                    isDark,
                                                                  )
                                                                : const SizedBox(),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            );
                                          },
                                        );
                                      },
                                    ),
                                  )
                                // ======================================================
                                // NORMAL CATEGORY
                                // HORIZONTAL TEMPLATE SCROLL
                                // ======================================================
                                else
                                  SizedBox(
                                    height: 165.h,

                                    child: ListView.separated(
                                      scrollDirection: Axis.horizontal,

                                      physics: const BouncingScrollPhysics(),

                                      itemCount: templates.length,

                                      separatorBuilder: (_, __) =>
                                          SizedBox(width: 12.w),

                                      itemBuilder: (context, templateIndex) {
                                        return SizedBox(
                                          width: 145.w,

                                          child: _buildApiTemplateCard(
                                            context,
                                            templates[templateIndex],
                                            isDark,
                                          ),
                                        );
                                      },
                                    ),
                                  ),
                              ],
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
  Widget _buildCategorySection({
    required String categoryName,
    required TemplateCategories category,
    required bool isDark,
  }) {
    final children = category.children;

    if (children.isEmpty) {
      return const SizedBox.shrink();
    }

    return Container(
      width: double.infinity,
      margin: EdgeInsets.symmetric(
        horizontal: 16.w,
        vertical: 7.h,
      ),
      padding: EdgeInsets.only(
        top: 12.h,
        bottom: 12.h,
      ),
      decoration: BoxDecoration(
        color: isDark
            ? const Color(0xFF1B1620)
            : const Color(0xFFFFF9FF),
        borderRadius: BorderRadius.circular(14.r),
        border: Border.all(
          color: isDark
              ? const Color(0xFF302936)
              : const Color(0xFFE9D8F4),
          width: 1,
        ),
      ),
      child: Column(
        children: [
          // ==========================================
          // TITLE
          // ==========================================
          Padding(
            padding: EdgeInsets.symmetric(
              horizontal: 12.w,
            ),
            child: Row(
              children: [
                Expanded(
                  child: AppText(
                    categoryName,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 12.sp,
                      fontWeight: FontWeight.w800,
                      color: isDark
                          ? Colors.white
                          : Colors.black,
                    ),
                  ),
                ),
              ],
            ),
          ),

          SizedBox(height: 10.h),

          // ==========================================
          // HORIZONTAL CHILDREN
          // ==========================================
          SizedBox(
            height: 91.h,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,

              // IMPORTANT:
              // First + last item screen edge-la
              // cut aagama irukka padding
              padding: EdgeInsets.symmetric(
                horizontal: 14.w,
              ),

              physics: const BouncingScrollPhysics(),

              itemCount: children.length,

              separatorBuilder: (_, __) {
                return SizedBox(width: 11.w);
              },

              itemBuilder: (context, index) {
                final child = children[index];

                final childName =
                    child.name?.trim() ?? '';

                final childSlug =
                    child.slug?.trim() ?? '';

                // ------------------------------------------
                // Prefer thumbnail, fallback icon
                // ------------------------------------------
                String imageKey =
                    child.thumbnailS3Key?.trim() ?? '';

                if (imageKey.isEmpty) {
                  imageKey =
                      child.iconS3Key?.trim() ?? '';
                }

                final imageUrl = imageKey.isEmpty
                    ? ''
                    : '${ApiEndpoints.cdnImageUrl}/$imageKey';

                return SizedBox(
                  width: 62.w,
                  child: InkWell(
                    borderRadius:
                    BorderRadius.circular(12.r),

                    onTap: () {
                      debugPrint(
                        "📂 CHILD CATEGORY: $childName",
                      );

                      debugPrint(
                        "📂 CHILD SLUG: $childSlug",
                      );

                      Navigator.pushNamed(
                        context,
                        "/TemplateDetailScreen",
                        arguments: {
                          "category": childSlug,
                          "categoryUid": child.uid,
                          "categoryName": child.name,
                        },
                      );
                    },

                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        // ==================================
                        // IMAGE
                        // ==================================
                        Container(
                          width: 58.w,
                          height: 58.w,
                          decoration: BoxDecoration(
                            borderRadius:
                            BorderRadius.circular(11.r),

                            color: isDark
                                ? const Color(0xFF28232B)
                                : Colors.white,

                            boxShadow: [
                              BoxShadow(
                                color: Colors.black
                                    .withOpacity(0.05),
                                blurRadius: 5,
                                offset:
                                const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: ClipRRect(
                            borderRadius:
                            BorderRadius.circular(11.r),

                            child: imageUrl.isEmpty
                                ? Center(
                              child: Icon(
                                Icons
                                    .image_outlined,
                                size: 22.sp,
                                color: Colors.grey,
                              ),
                            )
                                : Image.network(
                              imageUrl,
                              width: 58.w,
                              height: 58.w,
                              fit: BoxFit.cover,

                              loadingBuilder:
                                  (
                                  context,
                                  child,
                                  loadingProgress,
                                  ) {
                                if (loadingProgress ==
                                    null) {
                                  return child;
                                }

                                return Center(
                                  child:
                                  SizedBox(
                                    width: 17.w,
                                    height: 17.w,
                                    child:
                                    const CircularProgressIndicator(
                                      strokeWidth: 1.5,
                                      color:
                                      Color(
                                        0xFFE53935,
                                      ),
                                    ),
                                  ),
                                );
                              },

                              errorBuilder:
                                  (
                                  context,
                                  error,
                                  stackTrace,
                                  ) {
                                debugPrint(
                                  "❌ CHILD IMAGE ERROR: "
                                      "$imageUrl",
                                );

                                return Center(
                                  child: Icon(
                                    Icons
                                        .broken_image_outlined,
                                    size: 21.sp,
                                    color:
                                    Colors.grey,
                                  ),
                                );
                              },
                            ),
                          ),
                        ),

                        SizedBox(height: 5.h),

                        // ==================================
                        // NAME
                        // ==================================
                        SizedBox(
                          width: 62.w,
                          child: AppText(
                            childName,
                            textAlign: TextAlign.center,
                            maxLines: 2,
                            overflow:
                            TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 7.5.sp,
                              fontWeight: FontWeight.w700,
                              height: 1.05,
                              color: isDark
                                  ? Colors.white
                                  : Colors.black,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
  void _showCreateNewDialog(BuildContext context, bool isDark) {
    final List<String> sizes = [
      "Post Square (1:1)",
      "Post Portrait (4:5)",
      "Story / Reel (9:16)",
      "Post Horizontal (16:9)",
    ];

    showDialog(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          backgroundColor: isDark ? const Color(0xFF2A2A2A) : Colors.white,

          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12.r),
          ),

          title: Text(
            "Create New",
            style: TextStyle(
              color: isDark ? Colors.white : Colors.black,
              fontSize: 16.sp,
              fontWeight: FontWeight.w600,
            ),
          ),

          contentPadding: EdgeInsets.only(
            left: 12.w,
            right: 12.w,
            bottom: 10.h,
          ),

          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: sizes.map((size) {
              return InkWell(
                borderRadius: BorderRadius.circular(8.r),

                onTap: () {
                  Navigator.pop(dialogContext);

                  double canvasWidth = 1080;
                  double canvasHeight = 1080;

                  switch (size) {
                    case "Post Square (1:1)":
                      canvasWidth = 1080;
                      canvasHeight = 1080;
                      break;
                    case "Post Portrait (4:5)":
                      canvasWidth = 1080;
                      canvasHeight = 1350;
                      break;
                    case "Story / Reel (9:16)":
                      canvasWidth = 1080;
                      canvasHeight = 1920;
                      break;
                    case "Post Horizontal (16:9)":
                      canvasWidth = 1920;
                      canvasHeight = 1080;
                      break;
                  }

                  // Project creation is intentionally handled inside
                  // TemplateEditScreen so the editor owns the complete flow.
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => TemplateEditScreen(
                        canvasWidth: canvasWidth,
                        canvasHeight: canvasHeight,
                        resizeSize: size,
                      ),
                    ),
                  );
                },

                child: Container(
                  width: double.infinity,

                  padding: EdgeInsets.symmetric(
                    horizontal: 10.w,
                    vertical: 12.h,
                  ),

                  margin: EdgeInsets.only(bottom: 4.h),

                  decoration: BoxDecoration(
                    color: isDark
                        ? const Color(0xFF333333)
                        : Colors.transparent,

                    borderRadius: BorderRadius.circular(8.r),
                  ),

                  child: Text(
                    size,

                    style: TextStyle(
                      color: isDark ? Colors.white : Colors.black87,

                      fontSize: 13.sp,
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        );
      },
    );
  }

  Widget _buildDateContainer(
    HomeScreenProvider provider,
    List<DateTime> dates,
    int month,
  ) {
    final now = DateTime.now();
    final selected = provider.selectedDates;

    int selectedIndex = dates.indexWhere((date) {
      if (selected == null || selected.isEmpty) return false;
      final parsed = DateTime.tryParse(selected);
      return parsed != null &&
          parsed.year == date.year &&
          parsed.month == date.month &&
          parsed.day == date.day;
    });

    if (selectedIndex < 0) {
      selectedIndex = dates.indexWhere(
        (date) =>
            date.year == now.year &&
            date.month == now.month &&
            date.day == now.day,
      );
    }
    if (selectedIndex < 0 && dates.isNotEmpty) selectedIndex = 0;

    return Container(
      height: 40.h,
      decoration: BoxDecoration(
        color: const Color(0xFFFFE5E5),
        borderRadius: BorderRadius.circular(20.r),
      ),
      clipBehavior: Clip.antiAlias,
      child: Row(
        children: [
          Container(
            width: 62.w,
            height: double.infinity,
            color: const Color(0xFFF51B23),
            alignment: Alignment.center,
            child: Text(
              _monthName(month),
              style: TextStyle(
                color: Colors.white,
                fontSize: 18.sp,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
          Expanded(
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 8.h),
              physics: const BouncingScrollPhysics(),
              itemCount: dates.length,
              separatorBuilder: (_, __) => SizedBox(width: 8.w),
              itemBuilder: (context, index) {
                final date = dates[index];
                final isSelected = index == selectedIndex;

                return GestureDetector(
                  onTap: () => provider.setSelectedDate(date),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 180),
                    width: 48.w,
                    height: 44.h,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: isSelected
                          ? Colors.white
                          : const Color(0xFFFFF7F7),
                      borderRadius: BorderRadius.circular(12.r),
                      border: Border.all(
                        color: isSelected
                            ? const Color(0xFFF51B23)
                            : Colors.transparent,
                        width: 1.5,
                      ),
                    ),
                    child: Text(
                      '${date.day}',
                      style: TextStyle(
                        fontSize: 16.sp,
                        fontWeight: FontWeight.w800,
                        color: Colors.black,
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: EdgeInsets.only(right: 12.w, left: 2.w),
            child: GestureDetector(
              onTap: provider.specialDaysRange == null
                  ? null
                  : provider.loadNextSpecialDaysRange,
              child: Icon(
                Icons.arrow_forward_ios_rounded,
                size: 19.sp,
                color: Colors.black,
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _monthName(int month) {
    const months = [
      'Jan',
      'Feb',
      'March',
      'April',
      'May',
      'June',
      'July',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];

    if (month < 1 || month > 12) {
      return '';
    }

    return months[month - 1];
  }

  Widget buildProfileImage(String imageUrl) {
    if (imageUrl.isEmpty) {
      return _defaultLogo();
    }

    final uri = Uri.tryParse(imageUrl);
    final path = uri?.path.toLowerCase() ?? '';

    final isSvg = path.endsWith('.svg');

    // SVG
    if (isSvg) {
      return SvgPicture.network(
        imageUrl,
        width: 50.w,
        height: 50.w,
        fit: BoxFit.cover,
        placeholderBuilder: (context) {
          return _defaultLogo();
        },
      );
    }

    // PNG / JPG / JPEG / WEBP
    return CachedNetworkImage(
      imageUrl: imageUrl,
      cacheKey: imageUrl,
      width: 50.w,
      height: 50.w,
      fit: BoxFit.cover,

      placeholder: (context, url) {
        return _defaultLogo();
      },

      errorWidget: (context, url, error) {
        debugPrint("❌ Profile image load failed: $error");

        debugPrint("Image URL: $url");

        return _defaultLogo();
      },
    );
  }

  Widget _buildSpecialDaysApiList(HomeScreenProvider provider) {
    final events = provider.specialDays;

    final List<Template> allTemplates = [];

    final Set<String> addedTemplateIds = {};

    for (final event in events) {
      for (final template in event.templates) {
        final uid = template.uid?.trim() ?? '';

        if (uid.isNotEmpty && !addedTemplateIds.contains(uid)) {
          addedTemplateIds.add(uid);

          allTemplates.add(template);
        }
      }
    }

    if (allTemplates.isEmpty) {
      return Padding(
        padding: EdgeInsets.only(left: 4.w, top: 2.h),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AppText(
              'No special days for this date',
              style: TextStyle(
                fontSize: 13.sp,
                fontWeight: FontWeight.w600,
                color: Colors.grey,
              ),
            ),
          ],
        ),
      );
    }
    return SizedBox(
      height: 180.h,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,

        physics: const BouncingScrollPhysics(),

        padding: EdgeInsets.only(left: 2.w, right: 12.w),

        itemCount: allTemplates.length,

        separatorBuilder: (context, index) {
          return SizedBox(width: 12.w);
        },

        itemBuilder: (context, index) {
          final template = allTemplates[index];

          return _buildSpecialDayTemplateCard(context, template);
        },
      ),
    );
  }

  Widget _buildSpecialDayTemplateCard(BuildContext context, Template template) {
    final key = template.thumbnailS3Key?.trim() ?? '';

    final imageUrl = key.isEmpty
        ? ''
        : key.startsWith('http://') || key.startsWith('https://')
        ? key
        : '${ApiEndpoints.cdnImageUrl}/$key';

    return GestureDetector(
      behavior: HitTestBehavior.opaque,

      onTap: () {
        final templateUid = template.uid?.trim() ?? '';

        if (templateUid.isEmpty) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Template UID not available')),
          );
          return;
        }

        if (template.isLocked) {
          _showPremiumTemplateDialog(context, template);
          return;
        }

        // Template API + Project API are handled by TemplateEditScreen.
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => TemplateEditScreen(templateUid: templateUid),
          ),
        );
      },

      child: Container(
        width: 145.w,

        decoration: BoxDecoration(
          color: Colors.white,

          borderRadius: BorderRadius.circular(16.r),

          border: Border.all(color: Colors.grey.shade200, width: 1),

          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.05),
              blurRadius: 8,
              offset: const Offset(0, 3),
            ),
          ],
        ),

        clipBehavior: Clip.antiAlias,

        child: Stack(
          children: [
            Positioned.fill(
              child: imageUrl.isEmpty
                  ? _specialDayPlaceholder()
                  : CachedNetworkImage(
                      imageUrl: imageUrl,

                      width: double.infinity,

                      height: double.infinity,

                      fit: BoxFit.cover,

                      placeholder: (context, url) {
                        return Container(
                          color: Colors.grey.shade100,

                          child: const Center(
                            child: SizedBox(
                              height: 22,
                              width: 22,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            ),
                          ),
                        );
                      },

                      errorWidget: (context, url, error) {
                        debugPrint("❌ Template image failed");

                        debugPrint("URL : $url");

                        debugPrint("ERROR : $error");

                        return _specialDayPlaceholder();
                      },
                    ),
            ),

            if (template.isLocked)
              Positioned.fill(
                child: Container(
                  color: Colors.black.withOpacity(0.40),

                  child: const Center(
                    child: Icon(
                      Icons.lock_rounded,
                      color: Colors.white,
                      size: 30,
                    ),
                  ),
                ),
              ),

            /*    Positioned(
              left: 0,
              right: 0,
              bottom: 0,

              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 7.h),

                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.transparent,
                      Colors.black.withOpacity(0.75),
                    ],
                  ),
                ),

                child: AppText(
                  template.name ?? 'Template',

                  maxLines: 1,

                  overflow: TextOverflow.ellipsis,

                  style: TextStyle(
                    color: Colors.white,

                    fontSize: 11.sp,

                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ),*/
          ],
        ),
      ),
    );
  }

  void _showPremiumTemplateDialog(BuildContext context, dynamic template) {
    final String templateName = (template.name?.toString().isNotEmpty ?? false)
        ? template.name.toString()
        : "This template";

    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (dialogContext) {
        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.symmetric(horizontal: 16),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(18),
            ),
            clipBehavior: Clip.antiAlias,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 18, 20, 16),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: const EdgeInsets.only(top: 3),
                        child: const Icon(
                          Icons.local_offer_rounded,
                          color: Color(0xFFE91E63),
                          size: 18,
                        ),
                      ),

                      const SizedBox(width: 10),

                      Expanded(
                        child: Text(
                          'Premium template',
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                            color: Color(0xFF202124),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 18),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      '"$templateName" is part of the premium\n'
                      'collection. Upgrade your plan to use it in your designs.',
                      style: const TextStyle(
                        fontSize: 14,
                        height: 1.45,
                        color: Color(0xFF666666),
                      ),
                    ),
                  ),
                ),

                Container(height: 1, color: const Color(0xFFE8E8E8)),

                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 12,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      TextButton(
                        onPressed: () {
                          Navigator.pop(dialogContext);
                        },
                        child: const Text(
                          'Not now',
                          style: TextStyle(
                            color: Color(0xFF222222),
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),

                      const SizedBox(width: 8),

                      ElevatedButton(
                        onPressed: () {
                          Navigator.pop(dialogContext);
                          Navigator.pushNamed(
                            context,
                            '/PlansAndPricingScreen',
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF202020),
                          foregroundColor: Colors.white,
                          elevation: 0,
                          padding: const EdgeInsets.symmetric(
                            horizontal: 14,
                            vertical: 11,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(9),
                          ),
                        ),
                        child: const Text(
                          'Upgrade to premium',
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _specialDayPlaceholder() {
    return Container(
      width: double.infinity,
      height: double.infinity,
      color: const Color(0xFFFFE5E5),

      child: const Center(
        child: Icon(Icons.image_outlined, color: Color(0xFFE53935), size: 35),
      ),
    );
  }

  Widget _buildSpecialDaysCalendar(HomeScreenProvider provider) {
    final range = provider.specialDaysRange;

    if (range == null) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildDateContainer(provider, [DateTime.now()], DateTime.now().month),

          SizedBox(height: 12.h),

          if (provider.isLoadingSpecialDays)
            const Center(
              child: SizedBox(
                height: 22,
                width: 22,
                child: CircularProgressIndicator(strokeWidth: 2),
              ),
            )
          else
            _buildSpecialDaysApiList(provider),
        ],
      );
    }

    final DateTime from = DateTime(
      range.from.year,
      range.from.month,
      range.from.day,
    );

    final DateTime to = DateTime(range.to.year, range.to.month, range.to.day);

    final List<DateTime> dates = [];

    DateTime current = from;

    while (!current.isAfter(to)) {
      dates.add(current);

      current = current.add(const Duration(days: 1));
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildDateContainer(provider, dates, from.month),

        SizedBox(height: 12.h),

        if (provider.isLoadingSpecialDays)
          const Center(
            child: SizedBox(
              height: 22,
              width: 22,
              child: CircularProgressIndicator(strokeWidth: 2),
            ),
          )
        else
          _buildSpecialDaysApiList(provider),
      ],
    );
  }

  Widget _buildApiTemplateCard(
    BuildContext context,
    TemplateModel template,
    bool isDark,
  ) {
    final key = template.thumbnailS3Key?.trim() ?? '';

    final imageUrl = key.isEmpty ? '' : '${ApiEndpoints.cdnImageUrl}/$key';

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        final templateUid = (template as dynamic).uid?.toString().trim() ?? '';

        if (templateUid.isEmpty) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Template UID not available')),
          );
          return;
        }

        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => TemplateEditScreen(templateUid: templateUid),
          ),
        );
      },
      child: Container(
        margin: EdgeInsets.only(right: 12.w),
        decoration: BoxDecoration(
          color: isDark ? const Color(0xFF1E1E1E) : Colors.white,
          borderRadius: BorderRadius.circular(16.r),
          border: Border.all(
            color: isDark ? Colors.grey.shade800 : Colors.grey.shade200,
            width: 1.2,
          ),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(16.r),
          child: imageUrl.isEmpty
              ? _templateImagePlaceholder(isDark)
              : CachedNetworkImage(
                  imageUrl: imageUrl,
                  fit: BoxFit.cover,
                  placeholder: (context, url) {
                    return const Center(child: CircularProgressIndicator());
                  },
                  errorWidget: (context, url, error) {
                    return _templateImagePlaceholder(isDark);
                  },
                ),
        ),
      ),
    );
  }

  Widget _templateImagePlaceholder(bool isDark) {
    return Container(
      color: isDark ? const Color(0xFF2C2C2C) : Colors.grey.shade200,
      child: Icon(
        Icons.image_outlined,
        size: 36.sp,
        color: Colors.grey.shade400,
      ),
    );
  }

  Widget _buildSectionHeader({
    required String title,
    required String iconAsset,
    bool hasViewAll = false,
    required bool isDark,
    VoidCallback? onViewAll,
  }) {
    final icon = iconAsset.trim();

    final isNetwork = icon.startsWith('http://') || icon.startsWith('https://');

    final isSvg = icon.toLowerCase().endsWith('.svg');

    return Row(
      children: [
        SizedBox(
          width: 32.w,
          height: 32.w,
          child: ClipOval(
            child: icon.isEmpty
                ? _buildDefaultCategoryIcon(isDark)
                : isNetwork
                ? (isSvg
                      ? SvgPicture.network(
                          icon,
                          width: 32.w,
                          height: 32.w,
                          fit: BoxFit.cover,
                          placeholderBuilder: (_) =>
                              _buildDefaultCategoryIcon(isDark),
                        )
                      : CachedNetworkImage(
                          imageUrl: icon,
                          width: 32.w,
                          height: 32.w,
                          fit: BoxFit.cover,
                          placeholder: (_, __) =>
                              _buildDefaultCategoryIcon(isDark),
                          errorWidget: (_, __, ___) =>
                              _buildDefaultCategoryIcon(isDark),
                        ))
                : (isSvg
                      ? SvgPicture.asset(
                          icon,
                          width: 32.w,
                          height: 32.w,
                          fit: BoxFit.cover,
                        )
                      : Image.asset(
                          icon,
                          width: 32.w,
                          height: 32.w,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) =>
                              _buildDefaultCategoryIcon(isDark),
                        )),
          ),
        ),

        SizedBox(width: 8.w),

        Expanded(
          child: AppText(
            title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: isDark ? Colors.white : AppColors.darkBlack,
              fontSize: AppFontSize.fontSize18,
              fontWeight: FontWeight.w800,
            ),
          ),
        ),

        if (hasViewAll)
          GestureDetector(
            onTap: onViewAll,
            behavior: HitTestBehavior.opaque,
            child: Padding(
              padding: EdgeInsets.symmetric(vertical: 8.h, horizontal: 4.w),
              child: AppText(
                "VIEW ALL",
                style: TextStyle(
                  color: isDark ? Colors.grey.shade400 : Colors.grey.shade600,
                  fontSize: 12.sp,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildDefaultCategoryIcon(bool isDark) {
    return Container(
      width: 32.w,
      height: 32.w,
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF2A1A1C) : const Color(0xFFFFECEE),
        shape: BoxShape.circle,
      ),
      child: Icon(Icons.flash_on, color: const Color(0xFFE53935), size: 18.sp),
    );
  }

  Widget _buildMySpaceList(
    HomeScreenProvider homeScreenProvider,
    bool isDark,
    void Function(MySpaceModel item) onTap,
  ) {
    return SizedBox(
      height: 90.h,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: homeScreenProvider.mySpaceList.length,
        physics: const BouncingScrollPhysics(),
        itemBuilder: (context, index) {
          final item = homeScreenProvider.mySpaceList[index];

          return InkWell(
            onTap: () => onTap(item),
            borderRadius: BorderRadius.circular(20.r),
            child: Container(
              width: 100.w,
              margin: EdgeInsets.only(right: 12.w),
              padding: EdgeInsets.all(10.r),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: item.gradientColors,
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(20.r),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset(
                    item.icon,
                    height: 36.h,
                    width: 36.w,
                    fit: BoxFit.contain,
                  ),
                  SizedBox(height: 6.h),
                  AppText(
                    item.title,
                    textAlign: TextAlign.center,
                    maxLines: 2,
                    style: TextStyle(
                      color: isDark ? Colors.white : Colors.black,
                      fontSize: 10.sp,
                      fontWeight: FontWeight.w900,
                      height: 1.1,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildMyZoneSlider(
    HomeScreenProvider homeScreenProvider,
    bool isDark, {
    required dynamic me,
  }) {
    // Popular templates first 4 only
    final popularTemplates = homeScreenProvider.popularTemplates
        .take(4)
        .toList();

    return SizedBox(
      height: 360.h,
      child: popularTemplates.isEmpty
          ? Container(
              margin: EdgeInsets.symmetric(horizontal: 25.w),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16.r),
                color: isDark ? const Color(0xFF1E1E1E) : Colors.grey.shade100,
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(16.r),
                child: Image.asset(
                  "assets/images/BName.png",
                  fit: BoxFit.cover,
                ),
              ),
            )
          : PageView.builder(
              controller: homeScreenProvider.zonePageController,
              itemCount: popularTemplates.length,
              itemBuilder: (context, index) {
                final item = popularTemplates[index];

                final thumbnailKey = item.iconS3Key ?? '';

                final imageUrl = thumbnailKey.isEmpty
                    ? ''
                    : '${ApiEndpoints.cdnImageUrl}/$thumbnailKey';

                return Container(
                  margin: EdgeInsets.symmetric(horizontal: 25.w),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16.r),
                    color: isDark
                        ? const Color(0xFF1E1E1E)
                        : Colors.grey.shade100,
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(16.r),
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        buildProfileImage(imageUrl),

                        // =========================
                        // BOTTOM INFO
                        // =========================
                        Positioned(
                          left: 0,
                          right: 0,
                          bottom: 0,
                          child: Container(
                            padding: EdgeInsets.symmetric(
                              horizontal: 18.w,
                              vertical: 12.h,
                            ),
                            decoration: const BoxDecoration(
                              color: Color(0xFF246BFE),
                            ),
                            child: Row(
                              children: [
                                Expanded(
                                  child: AppText(
                                    item.name ?? '',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 13.sp,
                                      fontWeight: FontWeight.w700,
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }

  Widget _buildMyFrameHeader(bool isDark, BuildContext context) {
    return Row(
      children: [
        Text(
          "MY FRAME - 1",
          style: TextStyle(
            color: isDark ? Colors.white : AppColors.darkBlack,
            fontSize: 18.sp,
            fontWeight: FontWeight.w800,
          ),
        ),

        SizedBox(width: 8.w),

        Container(
          width: 28.w,
          height: 28.w,
          decoration: BoxDecoration(
            color: isDark ? const Color(0xFF3A2929) : const Color(0xFFFFE5E5),
            borderRadius: BorderRadius.circular(8.r),
          ),
          child: IconButton(
            padding: EdgeInsets.zero,
            onPressed: () {
              // More options
            },
            icon: Icon(Icons.more_vert_rounded, color: Colors.red, size: 19.sp),
          ),
        ),

        const Spacer(),

        Container(
          width: 38.w,
          height: 38.w,
          decoration: BoxDecoration(
            color: isDark ? const Color(0xFF3A2929) : const Color(0xFFFFE5E5),
            shape: BoxShape.circle,
          ),
          child: InkWell(
            onTap: () {},
            child: Image.asset('assets/images/frame_edit.png'),
          ),
        ),

        SizedBox(width: 8.w),

        Container(
          width: 38.w,
          height: 38.w,
          decoration: BoxDecoration(
            color: isDark ? const Color(0xFF3A2929) : const Color(0xFFFFE5E5),
            shape: BoxShape.circle,
          ),
          child: InkWell(
            onTap: () {
              _showShareBottomSheet(context, isDark);
            },
            child: Image.asset('assets/images/download.png'),
          ),
        ),
      ],
    );
  }

  Widget _buildLeadBannerSlider(
    HomeScreenProvider homeScreenProvider,
    bool isDark,
    dynamic me,
    BuildContext context,
  ) {
    final controller = homeScreenProvider.leadPageController;

    final banners = [
      {
        "title": "Grow Your Business",
        "description":
            "List your business on MMB and get discovered by potential customers.",
        "button": "GO PREMIUM",
        "onTap": () {
          Navigator.pushNamed(context, "/PlansAndPricingScreen");
        },
        "gradient": const [Color(0xFFFFEEEE), Color(0xFFFFF9EA)],
        "titleColor": const Color(0xFFD4A017),
        "descriptionColor": const Color(0xFF333333),
      },
      {
        "title": "2000+ Business Templates",
        "description": "Find ready-made templates designed for your industry",
        "button": "BROWSE TEMPLATES",
        "onTap": () {
          // Navigator.pushNamed(context, "/TemplateScreen");
        },
        "gradient": const [Color(0xFFEEF4FF), Color(0xFFEEEAFF)],
        "titleColor": const Color(0xFF8D77FB),
        "descriptionColor": const Color(0xFF343434),
      },
      {
        "title": "Powerful AI Tools",
        "description":
            "Generate logos, remove backgrounds, create images, and write caption instantly",
        "button": "EXPLORE AI",
        "onTap": () {
          // Navigator.pushNamed(context, "/AIScreen");
        },
        "gradient": const [Color(0xFFFFFBEE), Color(0xFFEAFEFF)],
        "titleColor": const Color(0xFF26A3D9),
        "descriptionColor": const Color(0xFF303030),
      },
    ];

    final bool isPersonal =
        me?.data?.accountType?.toString().toLowerCase() == "personal";

    if (isPersonal) {
      return Padding(
        padding: EdgeInsets.symmetric(horizontal: 4.w),
        child: Column(
          children: List.generate(banners.length, (index) {
            final banner = banners[index];

            final title = banner["title"] as String;

            final description = banner["description"] as String;

            final button = banner["button"] as String;

            final gradient = banner["gradient"] as List<Color>;

            final titleColor = banner["titleColor"] as Color;

            final descriptionColor = banner["descriptionColor"] as Color;

            final onTap = banner["onTap"] as VoidCallback;

            return Container(
              width: double.infinity,
              height: 48.h,
              margin: EdgeInsets.only(
                bottom: index == banners.length - 1 ? 0 : 6.h,
              ),
              padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 5.h),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: gradient,
                ),
                borderRadius: BorderRadius.circular(7.r),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        AppText(
                          title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: titleColor,
                            fontSize: 11.sp,
                            fontWeight: FontWeight.w900,
                          ),
                        ),

                        SizedBox(height: 1.h),

                        AppText(
                          description,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: descriptionColor,
                            fontSize: 7.sp,
                            height: 1.1,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),

                  SizedBox(width: 6.w),

                  SizedBox(
                    height: 19.h,
                    child: ElevatedButton(
                      onPressed: onTap,
                      style: ElevatedButton.styleFrom(
                        elevation: 0,
                        backgroundColor: titleColor,
                        foregroundColor: Colors.white,
                        padding: EdgeInsets.symmetric(horizontal: 7.w),
                        minimumSize: Size.zero,
                        tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(4.r),
                        ),
                      ),
                      child: AppText(
                        button,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 6.sp,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          }),
        ),
      );
    }

    return SizedBox(
      height: 165.h,
      child: Column(
        children: [
          Expanded(
            child: PageView.builder(
              controller: controller,
              itemCount: banners.length,
              physics: const BouncingScrollPhysics(),
              itemBuilder: (context, index) {
                final banner = banners[index];

                final title = banner["title"] as String;

                final description = banner["description"] as String;

                final button = banner["button"] as String;

                final gradient = banner["gradient"] as List<Color>;

                final titleColor = banner["titleColor"] as Color;

                final descriptionColor = banner["descriptionColor"] as Color;

                final onTap = banner["onTap"] as VoidCallback;

                return Container(
                  margin: EdgeInsets.symmetric(horizontal: 4.w),
                  padding: EdgeInsets.symmetric(
                    horizontal: 16.w,
                    vertical: 12.h,
                  ),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: gradient,
                    ),
                    borderRadius: BorderRadius.circular(12.r),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      AppText(
                        title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: titleColor,
                          fontSize: 20.sp,
                          fontWeight: FontWeight.w900,
                        ),
                      ),

                      SizedBox(height: 3.h),

                      AppText(
                        description,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: descriptionColor,
                          fontSize: 13.sp,
                          height: 1.15,
                          fontWeight: FontWeight.w500,
                        ),
                      ),

                      SizedBox(height: 7.h),

                      SizedBox(
                        height: 28.h,
                        child: ElevatedButton(
                          onPressed: onTap,
                          style: ElevatedButton.styleFrom(
                            elevation: 0,
                            backgroundColor: titleColor,
                            foregroundColor: Colors.white,
                            padding: EdgeInsets.symmetric(horizontal: 14.w),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8.r),
                            ),
                          ),
                          child: AppText(
                            button,
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 10.sp,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),

          SizedBox(height: 7.h),

          _buildBannerDots(controller, banners.length),
        ],
      ),
    );
  }

  Widget _buildBannerDots(PageController controller, int itemCount) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, child) {
        int currentIndex = 0;

        if (controller.hasClients && controller.page != null) {
          currentIndex = controller.page!.round().clamp(0, itemCount - 1);
        }

        return Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(itemCount, (index) {
            final isActive = currentIndex == index;

            return AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              margin: EdgeInsets.symmetric(horizontal: 3.w),
              width: isActive ? 24.w : 7.w,
              height: 7.h,
              decoration: BoxDecoration(
                color: isActive
                    ? const Color(0xFF17295C)
                    : Colors.grey.shade300,
                borderRadius: BorderRadius.circular(10.r),
              ),
            );
          }),
        );
      },
    );
  }

  void _showShareBottomSheet(BuildContext context, bool isDark) {
    final shareItems = <_ShareItem>[
      _ShareItem("Download", Icons.download_rounded),
      _ShareItem("Instagram", Icons.camera_alt_rounded),
      _ShareItem("Facebook", Icons.facebook_rounded),
      _ShareItem("X (Twitter)", Icons.close_rounded),
      _ShareItem("LinkedIn", Icons.link_rounded),
      _ShareItem("Pinterest", Icons.push_pin_rounded),
      _ShareItem("Boost", Icons.rocket_launch_rounded),
    ];

    final messageItems = <_ShareItem>[
      _ShareItem("WhatsApp", Icons.chat_rounded),
      _ShareItem("Messenger", Icons.message_rounded),
      _ShareItem("Drive", Icons.drive_file_move_rounded),
      _ShareItem("Link", Icons.link_rounded),
    ];

    final manageItems = <_ShareItem>[
      _ShareItem("Caption", Icons.description_rounded),
      _ShareItem("Schedule", Icons.calendar_month_rounded),
      _ShareItem("Link", Icons.link_rounded),
    ];

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) {
        return SafeArea(
          top: false,
          child: Container(
            constraints: BoxConstraints(
              maxHeight: MediaQuery.of(sheetContext).size.height * 0.92,
            ),
            decoration: BoxDecoration(
              color: isDark ? const Color(0xFF1E1E1E) : Colors.white,
              borderRadius: BorderRadius.vertical(top: Radius.circular(24.r)),
            ),
            child: SingleChildScrollView(
              child: Padding(
                padding: EdgeInsets.only(
                  left: 22.w,
                  right: 22.w,
                  top: 10.h,
                  bottom: 20.h,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Drag handle
                    Center(
                      child: Container(
                        width: 70.w,
                        height: 5.h,
                        decoration: BoxDecoration(
                          color: Colors.grey.shade400,
                          borderRadius: BorderRadius.circular(10.r),
                        ),
                      ),
                    ),

                    SizedBox(height: 14.h),

                    // Header
                    Row(
                      children: [
                        Text(
                          "Share",
                          style: TextStyle(
                            color: isDark ? Colors.white : AppColors.darkBlack,
                            fontSize: 24.sp,
                            fontWeight: FontWeight.w700,
                          ),
                        ),

                        const Spacer(),

                        InkWell(
                          borderRadius: BorderRadius.circular(30.r),
                          onTap: () {
                            Navigator.pop(sheetContext);
                          },
                          child: Container(
                            width: 38.w,
                            height: 38.w,
                            decoration: BoxDecoration(
                              color: isDark
                                  ? const Color(0xFF3A2929)
                                  : const Color(0xFFFFF1F1),
                              shape: BoxShape.circle,
                            ),
                            child: Icon(
                              Icons.close,
                              color: Colors.red,
                              size: 22.sp,
                            ),
                          ),
                        ),
                      ],
                    ),

                    SizedBox(height: 20.h),

                    // SHARE
                    _buildShareSection(
                      context: sheetContext,
                      title: null,
                      items: shareItems,
                      isDark: isDark,
                    ),

                    SizedBox(height: 16.h),

                    // MESSAGE
                    _buildShareSection(
                      context: sheetContext,
                      title: "Message",
                      items: messageItems,
                      isDark: isDark,
                    ),

                    SizedBox(height: 16.h),

                    // MANAGE
                    _buildShareSection(
                      context: sheetContext,
                      title: "Manage",
                      items: manageItems,
                      isDark: isDark,
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildShareSection({
    required BuildContext context,
    required String? title,
    required List<_ShareItem> items,
    required bool isDark,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (title != null) ...[
          Text(
            title,
            style: TextStyle(
              color: isDark ? Colors.white : AppColors.darkBlack,
              fontSize: 22.sp,
              fontWeight: FontWeight.w500,
            ),
          ),
          SizedBox(height: 12.h),
        ],

        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          padding: EdgeInsets.zero,
          itemCount: items.length,

          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 4,

            crossAxisSpacing: 12.w,
            mainAxisSpacing: 18.h,

            childAspectRatio: 0.82,
          ),

          itemBuilder: (context, index) {
            final item = items[index];

            return InkWell(
              borderRadius: BorderRadius.circular(12.r),
              onTap: () {
                _handleShareItem(context, item);
              },
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: isDark
                      ? const Color(0xFF302020)
                      : const Color(0xFFFFF5F5),
                  borderRadius: BorderRadius.circular(12.r),
                  border: Border.all(color: Colors.red.withValues(alpha: 0.12)),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 30.w,
                      height: 30.w,
                      decoration: BoxDecoration(
                        color: Colors.red.withValues(alpha: .12),
                        borderRadius: BorderRadius.circular(8.r),
                      ),
                      alignment: Alignment.center,
                      child: Icon(item.icon, color: Colors.red, size: 20.sp),
                    ),

                    SizedBox(height: 8.h),

                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 4.w),
                      child: Text(
                        item.title,
                        textAlign: TextAlign.center,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: isDark ? Colors.white : AppColors.darkBlack,
                          fontSize: 12.sp,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _defaultLogo() {
    return Image.asset(
      "assets/images/BName.png",

      width: 50.w,
      height: 50.w,

      fit: BoxFit.cover,

      errorBuilder: (context, error, stackTrace) {
        return Container(
          width: 50.w,
          height: 50.w,

          color: const Color(0xFFE91E63),

          child: const Icon(Icons.business, color: Colors.white),
        );
      },
    );
  }

  void _handleShareItem(BuildContext context, _ShareItem item) {
    switch (item.title) {
      case "Download":
        Navigator.pop(context);

        _downloadFrame();

        break;

      case "Instagram":
        Navigator.pop(context);

        // Instagram share
        _openInstagram();

        break;

      case "Facebook":
        Navigator.pop(context);

        break;

      case "X (Twitter)":
        Navigator.pop(context);

        break;

      case "LinkedIn":
        Navigator.pop(context);

        break;

      case "Pinterest":
        Navigator.pop(context);

        break;

      case "Boost":
        Navigator.pop(context);

        break;

      case "WhatsApp":
        Navigator.pop(context);

        _openWhatsApp();

        break;

      case "Messenger":
        Navigator.pop(context);

        break;

      case "Drive":
        Navigator.pop(context);

        break;

      case "Link":
        Navigator.pop(context);

        break;

      case "Caption":
        Navigator.pop(context);

        break;

      case "Schedule":
        Navigator.pop(context);

        break;
      case "copy":
        _copyLink(context);
        Navigator.pop(context);

        break;
    }
  }

  Future<void> _openInstagram() async {
    final appUrl = Uri.parse("instagram://app");

    final webUrl = Uri.parse("https://www.instagram.com/");

    if (await canLaunchUrl(appUrl)) {
      await launchUrl(appUrl);
    } else {
      await launchUrl(webUrl, mode: LaunchMode.externalApplication);
    }
  }

  Future<void> _openWhatsApp() async {
    final url = Uri.parse("whatsapp://send");

    final webUrl = Uri.parse("https://www.whatsapp.com/");

    if (await canLaunchUrl(url)) {
      await launchUrl(url);
    } else {
      await launchUrl(webUrl, mode: LaunchMode.externalApplication);
    }
  }

  Future<void> _openUrl(String url) async {
    final uri = Uri.parse(url);

    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  Future<void> _copyLink(BuildContext context) async {
    const link = "https://your-mmb-app-link.com";

    await Clipboard.setData(const ClipboardData(text: link));

    if (context.mounted) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text("Link copied")));
    }
  }

  Future<void> _downloadFrame() async {
    // existing PNG export / save / share logic
  }
}

class _ShareItem {
  final String title;
  final IconData icon;

  _ShareItem(this.title, this.icon);
}
