import 'package:flutter/material.dart';
import 'package:mmb_app/component/custom_widget.dart';
import 'package:provider/provider.dart';

import '../../network/provider/plan_provider.dart';

class PlanUsageScreen extends StatefulWidget {
  const PlanUsageScreen({super.key});

  @override
  State<PlanUsageScreen> createState() => _PlanUsageScreenState();
}

class _PlanUsageScreenState extends State<PlanUsageScreen> {
  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<PlanProvider>().fetchPlanUsage();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<PlanProvider>(
      builder: (context, provider, child) {
        if (provider.isLoadingPlanUsage) {
          return const Center(
            child: CircularProgressIndicator(
              color: Colors.red,
            ),
          );
        }

        if (provider.planUsageError != null) {
          return Center(
            child: AppText(
              provider.planUsageError!,
              style: const TextStyle(
                color: Colors.red,
              ),
            ),
          );
        }

        final usage = provider.planUsageData?.data;

        return Scaffold(
          body: usage == null
              ? const Center(
            child: AppText("No usage data found"),
          )
              : _buildUsageContent(
            context,
            provider,
            usage,
          ),
        );
      },
    );
  }
}

class _TopUpCreditsBottomSheet extends StatefulWidget {
  final BuildContext parentContext;

  const _TopUpCreditsBottomSheet({required this.parentContext});

  @override
  State<_TopUpCreditsBottomSheet> createState() =>
      _TopUpCreditsBottomSheetState();
}

class _TopUpCreditsBottomSheetState extends State<_TopUpCreditsBottomSheet> {
  int selectedIndex = 1;

  final List<Map<String, String>> plans = [
    {"price": "₹49", "credits": "100 Credits"},
    {"price": "₹79", "credits": "200 Credits"},
    {"price": "₹99", "credits": "150 Credits"},
    {"price": "₹249", "credits": "250 Credits"},
    {"price": "₹449", "credits": "500 Credits"},
    {"price": "₹899", "credits": "1000 Credits"},
  ];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(10, 12, 10, 14),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 55,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),

            const SizedBox(height: 10),

            Row(
              children: [
                const Expanded(
                  child: AppText(
                    "Top Up AI Credits",
                    style: TextStyle(
                      color: Color(0xFF171A2B),
                      fontSize: 14,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),

                GestureDetector(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Container(
                    width: 20,
                    height: 20,
                    decoration: const BoxDecoration(
                      color: Color(0xFFFFE5E7),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.close, color: Colors.red, size: 13),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 8),

            const Center(
              child: AppText(
                "Purchase additional credits valid for 360 days. Top up credits\n"
                "persist even if your subscription cancelled.",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFF666666),
                  fontSize: 8,
                  height: 1.4,
                ),
              ),
            ),

            const SizedBox(height: 12),

            const AppText(
              "SELECT THE PLAN",
              style: TextStyle(
                color: Colors.red,
                fontSize: 9,
                fontWeight: FontWeight.w800,
              ),
            ),

            const SizedBox(height: 7),

            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: plans.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                crossAxisSpacing: 8,
                mainAxisSpacing: 7,
                childAspectRatio: 1.45,
              ),
              itemBuilder: (context, index) {
                final plan = plans[index];
                final bool isSelected = selectedIndex == index;

                return GestureDetector(
                  onTap: () {
                    setState(() {
                      selectedIndex = index;
                    });
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: isSelected
                            ? Colors.red
                            : const Color(0xFFFFD5D8),
                        width: isSelected ? 1.5 : 1,
                      ),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        AppText(
                          plan["price"]!,
                          style: const TextStyle(
                            color: Color(0xFF171A2B),
                            fontSize: 12,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 3),
                        AppText(
                          plan["credits"]!,
                          style: const TextStyle(
                            color: Color(0xFF333333),
                            fontSize: 9,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),

            const SizedBox(height: 20),

            SizedBox(
              width: double.infinity,
              height: 39,
              child: ElevatedButton(
                onPressed: () {
                  final selectedPlan = plans[selectedIndex];

                  debugPrint(
                    "Selected: "
                    "${selectedPlan["price"]} - "
                    "${selectedPlan["credits"]}",
                  );

                  Navigator.pop(context);

                  Future.delayed(const Duration(milliseconds: 350), () {
                    if (!widget.parentContext.mounted) {
                      return;
                    }

                    showModalBottomSheet(
                      context: widget.parentContext,
                      isScrollControlled: true,
                      backgroundColor: Colors.white,
                      shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.vertical(
                          top: Radius.circular(20),
                        ),
                      ),
                      builder: (aiSheetContext) {
                        return const _AICreditsBottomSheet();
                      },
                    );
                  });
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(9),
                  ),
                ),
                child: const AppText(
                  "CONTINUE",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _AICreditsBottomSheet extends StatelessWidget {
  const _AICreditsBottomSheet();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(10, 12, 10, 18),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 55,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),

            const SizedBox(height: 10),

            Row(
              children: [
                const Expanded(
                  child: AppText(
                    "AI Credits",
                    style: TextStyle(
                      color: Color(0xFF171A2B),
                      fontSize: 14,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),

                GestureDetector(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Container(
                    width: 20,
                    height: 20,
                    decoration: const BoxDecoration(
                      color: Color(0xFFFFE5E7),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.close, color: Colors.red, size: 13),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 10),

            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFFE2E2E2)),
              ),
              child: const Column(
                children: [
                  _AICreditRow(
                    title: "Image Generation",
                    credits: "20 Credits",
                  ),

                  _AICreditRow(title: "Logo Generation", credits: "25 Credits"),

                  _AICreditRow(
                    title: "Background Removal",
                    credits: "5 Credits",
                  ),

                  _AICreditRow(
                    title: "Text to Audio (10 Seconds)",
                    credits: "15 Credits",
                  ),

                  _AICreditRow(title: "Auto Captions", credits: "5 Credits"),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _AICreditRow extends StatelessWidget {
  final String title;
  final String credits;

  const _AICreditRow({required this.title, required this.credits});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: [
          Expanded(
            child: AppText(
              title,
              style: const TextStyle(color: Color(0xFF666666), fontSize: 9),
            ),
          ),

          AppText(
            credits,
            style: const TextStyle(
              color: Color(0xFF171A2B),
              fontSize: 9,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }
}
