import 'package:flutter/cupertino.dart';

import '../Api Model/Template_model.dart';
import '../Api Model/special_days.dart';
import '../Api Model/templatecategories.dart';
import '../core/api/api_endpoints.dart';
import '../core/api/api_repository.dart';
import '../core/api/enums/api_method.dart';
import '../core/api/models/api_request_config.dart';
import '../core/api/models/api_result.dart';

class HomeRepository {
  HomeRepository._();

  static final HomeRepository instance = HomeRepository._();

  Future<ApiResult<TemplateCategoriesModel>> templateCategory() async {
    return await ApiRepository.instance.request<TemplateCategoriesModel>(
      config: ApiRequestConfig(
        endpoint: ApiEndpoints.templateCategory,
        method: ApiMethod.get,
        queryParams: {"homepage": "1"},
      ),
      fromJson: (json) =>
          TemplateCategoriesModel.fromJson(json as Map<String, dynamic>),
    );
  }

  Future<ApiResult<TemplateCategoriesModel>> templateCategoryTree() async {
    return await ApiRepository.instance.request<TemplateCategoriesModel>(
      config: ApiRequestConfig(
        endpoint: ApiEndpoints.templateCategory,
        method: ApiMethod.get,
        queryParams: {"tree": "1"},
      ),
      fromJson: (json) =>
          TemplateCategoriesModel.fromJson(json as Map<String, dynamic>),
    );
  }

  Future<ApiResult<TemplatesResponseModel>> templatesByCategory(
    String categorySlug,
  ) async {
    final result = await ApiRepository.instance.request<TemplatesResponseModel>(
      config: ApiRequestConfig(
        endpoint: ApiEndpoints.templates,
        method: ApiMethod.get,
        queryParams: {'category': categorySlug},
      ),
      fromJson: (json) {
        return TemplatesResponseModel.fromJson(json as Map<String, dynamic>);
      },
    );

    return result;
  }

  Future<ApiResult<TemplateCategoriesModel>> myBrandCategory({
    required String industrySlug,
    required String language,
  }) async {
    final result = await ApiRepository.instance
        .request<TemplateCategoriesModel>(
          config: ApiRequestConfig(
            endpoint: ApiEndpoints.templates,
            method: ApiMethod.get,
            queryParams: {
              "industry": industrySlug,
              "template_type": "image",
              "is_popular": "1",
              "language":language
            },
          ),
          fromJson: (json) =>
              TemplateCategoriesModel.fromJson(json as Map<String, dynamic>),
        );
    return result;
  }

  Future<ApiResult<SpecialDays>> specialDaysApi({
    String? range,
    String? from,
    String? to,
    String? type,
  }) async {
    final Map<String, dynamic> queryParams = {};

    if (range != null && range.isNotEmpty) {
      queryParams["range"] = range;
    } else if (from != null && from.isNotEmpty && to != null && to.isNotEmpty) {
      queryParams["from"] = from;
      queryParams["to"] = to;
    }

    if (type != null && type.isNotEmpty) {
      queryParams["type"] = type;
    }

    debugPrint("📅 Special Days API Params: $queryParams");

    final result = await ApiRepository.instance.request<SpecialDays>(
      config: ApiRequestConfig(
        endpoint: ApiEndpoints.specialDays,
        method: ApiMethod.get,
        queryParams: queryParams,
      ),
      fromJson: (json) => SpecialDays.fromJson(json as Map<String, dynamic>),
    );

    return result;
  }

  Future<ApiResult<dynamic>> favorite(String? templateId) {
    return ApiRepository.instance.request<dynamic>(
      config: ApiRequestConfig(
        endpoint: ApiEndpoints.favoriteTemplate('${templateId}'),
        method: ApiMethod.put,
      ),
      fromJson: (json) => json,
    );
  }
}
