import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:mmb_app/component/custom_widget.dart';
import 'package:mmb_app/core/api/api_endpoints.dart';
import 'package:mmb_app/helper/shared_preference.dart';
import 'dart:io';
import 'package:provider/provider.dart';
import '../../network/provider/custom_theme_provider.dart';
import '../network/provider/business_provider.dart';
import '../network/provider/getMe_provider.dart';

class HomeCustomAppBar extends StatelessWidget
    implements PreferredSizeWidget {
  final String notificationCount;
  final VoidCallback? onMagicWandTap;
  final VoidCallback? onNotificationTap;

  const HomeCustomAppBar({
    super.key,
    this.notificationCount = "2",
    this.onMagicWandTap,
    this.onNotificationTap,
  });

  @override
  Widget build(BuildContext context) {
    final themeProvider =
    context.watch<CustomThemeProvider>();

    final isDark = themeProvider.isDarkMode;

    final commonProvider =
    context.watch<CommonProvider>();

    final business = commonProvider.business;

    final String businessName =
    business?.name?.isNotEmpty == true
        ? business!.name!
        : "Business Name";


    final String businessCategory =
    business?.businessCategory?.name?.isNotEmpty == true
        ? business!.businessCategory!.name!
        : "Business Category";

    final String? logoS3Key =
        business?.logoS3Key;

    debugPrint(
      "🏢 Business Name : $businessName",
    );

    debugPrint(
      "🏷️ Industry      : $businessCategory",
    );

    debugPrint(
      "🖼️ Logo S3 Key   : $logoS3Key",
    );

    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 16.w,
        vertical: 10.h,
      ),
      decoration: const BoxDecoration(
        color: Colors.transparent,
      ),
      child: SafeArea(
        bottom: false,
        child: Row(
          children: [
            SizedBox(
              width: 50.w,
              height: 50.w,
              child: ClipOval(
                child: logoS3Key != null &&
                    logoS3Key.isNotEmpty
                    ? Image.network(
                  getS3ImageUrl(logoS3Key),
                  width: 50.w,
                  height: 50.w,
                  fit: BoxFit.cover,
                  errorBuilder:
                      (context, error, stackTrace) {
                    return _defaultLogo();
                  },
                )
                    : _defaultLogo(),
              ),
            ),

            SizedBox(width: 12.w),

            // =================================================
            // BUSINESS NAME + INDUSTRY
            // =================================================

            Expanded(
              child: Column(
                crossAxisAlignment:
                CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [

                  AppText(
                    businessName,
                    style: TextStyle(
                      color: isDark
                          ? Colors.white
                          : Colors.black,
                      fontSize: 18.sp,
                      fontWeight:
                      FontWeight.w800,
                    ),
                    maxLines: 1,
                    overflow:
                    TextOverflow.ellipsis,
                  ),

                  SizedBox(height: 2.h),

                  AppText(
                    businessCategory,
                    style: TextStyle(
                      color: isDark
                          ? Colors.grey.shade400
                          : Colors.grey.shade600,
                      fontSize: 13.sp,
                      fontWeight:
                      FontWeight.w500,
                    ),
                    maxLines: 1,
                    overflow:
                    TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),

            SizedBox(width: 10.w),

            // =================================================
            // NOTIFICATION
            // =================================================

            InkWell(
              onTap:
              onNotificationTap ??
                      () {
                    Navigator.pushNamed(
                      context,
                      "/NotificationScreen",
                    );
                  },
              borderRadius:
              BorderRadius.circular(24.r),
              child: Stack(
                clipBehavior: Clip.none,
                children: [

                  Container(
                    height: 40.h,
                    width: 40.w,
                    padding:
                    EdgeInsets.all(8.r),
                    decoration:
                    BoxDecoration(
                      color: isDark
                          ? const Color(
                        0xFF2A1A1C,
                      )
                          : const Color(
                        0xFFFFECEE,
                      ),
                      shape: BoxShape.circle,
                    ),
                    child: Center(
                      child: Icon(
                        Icons
                            .notifications_rounded,
                        color:
                        const Color(
                          0xFFE53935,
                        ),
                        size: 22.sp,
                      ),
                    ),
                  ),

                  if (notificationCount
                      .isNotEmpty)
                    Positioned(
                      top: -2.h,
                      left: -2.w,
                      child: Container(
                        padding:
                        EdgeInsets.all(4.r),
                        decoration:
                        const BoxDecoration(
                          color:
                          Color(0xFFE53935),
                          shape:
                          BoxShape.circle,
                        ),
                        constraints:
                        BoxConstraints(
                          minWidth: 18.w,
                          minHeight: 18.h,
                        ),
                        child: Center(
                          child: AppText(
                            notificationCount,
                            style:
                            TextStyle(
                              color:
                              Colors.white,
                              fontSize:
                              10.sp,
                              fontWeight:
                              FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _defaultLogo() {
    return Image.asset(
      "assets/images/BName.png",
      width: 50.w,
      height: 50.w,
      fit: BoxFit.cover,
      errorBuilder:
          (context, error, stackTrace) {
        return Container(
          width: 50.w,
          height: 50.w,
          color: const Color(0xFFE91E63),
          child: const Icon(
            Icons.business,
            color: Colors.white,
          ),
        );
      },
    );
  }

  @override
  Size get preferredSize =>
      Size.fromHeight(65.h);
}
String getS3ImageUrl(String key) {
  return "${ApiEndpoints.cdnImageUrl}/$key";
}