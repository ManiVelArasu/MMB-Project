import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:mmb_app/ui/industry/search_bottom_sheet.dart';
import 'package:mmb_app/ui/screens/widget/search_sub_category.dart';
import 'package:mmb_app/utils/theme/app.fonts.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../component/custom_widget.dart';
import '../../../network/provider/business_change_provider.dart';
import '../../../network/provider/custom_theme_provider.dart';
import '../../../network/provider/industry_provider.dart';
import '../../../utils/theme/app.colors.dart';

class BusinessCategorySearchScreen extends StatelessWidget {
  const BusinessCategorySearchScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => IndustryProvider()..fetchAssetCategories(),
      child: const BusinessCategoryChooseSearchViewScreen(),
    );
  }
}

class BusinessCategoryChooseSearchViewScreen extends StatelessWidget {
  const BusinessCategoryChooseSearchViewScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final customColor = context.watch<CustomThemeProvider>().colors;
    final theme = Theme.of(context).textTheme;
    //final accountProvider = context.watch<BusinessPatchProvider>();
    final industryProvider = context.watch<IndustryProvider>();

    // bool isBusiness = accountProvider.currentIndex == 0;

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              AppText(
                "Select Your Business Category",
                style: TextStyle(
                  fontSize: AppFontSize.fontSize22,
                  fontWeight: FontWeight.bold,
                  color: AppColors.appBlack,
                ),
              ),
              const SizedBox(height: 8),
              AppText(
                "Find the category that best matches your business.",
                style: TextStyle(
                  fontSize: AppFontSize.fontSize18,
                  color: Colors.grey.shade600,
                ),
              ),

              const SizedBox(height: 20),
              TextFormField(
                readOnly: true,
                onTap: () {
                  searchCategorySheet(context);
                },
                decoration: InputDecoration(
                  hintText: "Search your business category",
                  hintStyle: theme.bodyMedium!.copyWith(
                    color: customColor.greyColor.withAlpha(50),
                  ),
                  prefixIcon: Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: SvgPicture.asset(
                      "assets/icons/search.svg",
                      width: 22,
                      height: 22,
                    ),
                  ),
                  contentPadding: const EdgeInsets.symmetric(
                    vertical: 20,
                    horizontal: 12,
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: BorderSide(color: Colors.grey.shade300),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: BorderSide(color: Colors.grey.shade300),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: BorderSide(color: customColor.baseColor),
                  ),
                ),
              ),

              const SizedBox(height: 16),
              Expanded(
                child: industryProvider.isLoading
                    ? const Center(
                        child: CircularProgressIndicator(color: Colors.red),
                      )
                    : industryProvider.categories.isEmpty
                    ? _buildEmptyCategoryState(context, industryProvider)
                    : ListView.separated(
                        itemCount: industryProvider.categories.length > 10
                            ? 10
                            : industryProvider.categories.length,
                        separatorBuilder: (context, index) =>
                            Divider(color: Colors.grey.shade200),
                        itemBuilder: (context, index) {
                          final category = industryProvider.categories[index];
                          final categoryName = category.name ?? "";

                          return ListTile(
                            contentPadding: EdgeInsets.zero,
                            title: AppText(
                              categoryName,
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w400,
                                color: Colors.black87,
                              ),
                            ),
                            trailing: const Icon(
                              Icons.north_east,
                              size: 18,
                              color: Colors.grey,
                            ),
                            onTap: () async {
                              industryProvider.selectCategory(category);

                              final prefs =
                                  await SharedPreferences.getInstance();

                              final selectedCat =
                                  industryProvider.selectedCategory;

                              if (selectedCat != null) {
                                final industrySlug =
                                    selectedCat.slug?.trim() ?? "";
                                final categoryId =
                                    selectedCat.id?.toString() ?? "";
                                final categoryName = selectedCat.name ?? "";

                                await prefs.setString(
                                  'saved_category_id',
                                  categoryId,
                                );

                                await prefs.setString(
                                  'saved_category_name',
                                  categoryName,
                                );

                                // IMPORTANT
                                await prefs.setString(
                                  'saved_category_slug',
                                  industrySlug,
                                );

                                debugPrint('✅ Selected Industry');
                                debugPrint('ID   : $categoryId');
                                debugPrint('Name : $categoryName');
                                debugPrint('Slug : $industrySlug');
                              }

                              if (!context.mounted) return;

                              Navigator.pushNamed(
                                context,
                                "/BusinessSubCategoryChooseView",
                              );
                            },
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyCategoryState(
    BuildContext context,
    IndustryProvider industryProvider,
  ) {
    return Column(
      children: [
        const SizedBox(height: 4),
        AppText(
          "Can't find your business type?",
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: AppFontSize.fontSize16,
            fontWeight: FontWeight.w700,
            color: Colors.black87,
          ),
        ),
        const SizedBox(height: 8),
        AppText(
          "Choose Other and enter your business type. We'll review new "
          "requests and continuously expand our industry database to "
          "improve template recommendations.",
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: AppFontSize.fontSize15,
            height: 1.35,
            color: Colors.grey.shade700,
          ),
        ),
        const SizedBox(height: 26),
        TextButton(
          onPressed: () {
            industryProvider.setSelectedSpecialization("Other");
          },
          child: AppText(
            "Choose Other",
            style: TextStyle(
              color: Colors.red,
              fontSize: AppFontSize.fontSize14,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
        if (industryProvider.showOtherInput) ...[
          const SizedBox(height: 8),
          TextField(
            controller: industryProvider.otherController,
            decoration: InputDecoration(
              hintText: "Enter your business type",
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 14,
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: Colors.grey.shade300),
              ),
              focusedBorder: const OutlineInputBorder(
                borderRadius: BorderRadius.all(Radius.circular(12)),
                borderSide: BorderSide(color: Colors.red),
              ),
            ),
          ),
        ],
      ],
    );
  }

  void searchCategorySheet(BuildContext context) {
    final industryProvider = context.read<IndustryProvider>();
    final DraggableScrollableController sheetController =
        DraggableScrollableController();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) {
        return ChangeNotifierProvider.value(
          value: industryProvider,
          child: Stack(
            children: [
              Positioned.fill(
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 1.5, sigmaY: 1.5),
                  child: Container(
                    color: AppColors.appBlack.withValues(alpha: 0.2),
                  ),
                ),
              ),
              DraggableScrollableSheet(
                controller: sheetController,
                expand: false,
                initialChildSize: 0.75,
                minChildSize: 0.5,
                maxChildSize: 0.95,
                builder: (context, scrollController) {
                  return SearchSubCategoryBottomSheet(
                    scrollController: scrollController,
                    sheetController: sheetController,
                  );
                },
              ),
            ],
          ),
        );
      },
    );
  }
}
