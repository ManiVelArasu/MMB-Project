class ApiEndpoints {
  ApiEndpoints._(); // no instances

  static const String baseUrl =
      'https://lightslategray-llama-976293.hostingersite.com/api/v1';

  // ── Asset Categories ──────────────────────────────────────
  static const String assetCategories = '/asset-categories';

  static const String industries = '/industries';

  static const String plan = '/plans';

  static const String templateSize = '/template-sizes';
  static const String themes = '/brand-series?preview_variants=4';
  static String themesDetail(String varientId) => '/variants/$varientId';

  static const String templateCategory = '/template-categories';
  static const String templates = '/templates';

  static const String cdnImageUrl =
      'https://temp-m2b-assets.s3.ap-south-1.amazonaws.com';

  // ── Auth ──────────────────────────────────────────────────
  static const String login = '/auth/send-otp';

  static const String verifyOtp = '/auth/verify-otp';

  ///refresh token
  static const String refreshToken = '/auth/refresh';

  static const String feedBack = '/feedback';

  static const String fileUpload = '/uploads/presign';
  static const String fileConfirm = '/uploads/confirm';

  static const String logout = '/auth/logout';

  static const String businessUpdate = '/businesses';
  static String businessDetail(String varientId) => '/businesses/$varientId';
  static const String user = '/users/me';

  static const String language = '/languages';

  static const String notification = '/notifications';

  static const String specialDays = '/special-events';

  static const String frames = '/frames';

  static const String accountDeactivate = '/users/me/deactivate';

  static const String Business = '/businesses';

  static const String keyWords = '/tags';

  static const String notificationReadAll = '/notifications/read-all';

  static const String unReadCount = '/notifications/summary';

  static String industryKeyWords(String industrySlug) =>
      '/industries/${industrySlug}/keywords';

  static String notificationReadOne(String notificationUid) =>
      '/notifications/${notificationUid}/read';

  static String invoice(String invoiceId) =>
      '/subscriptions/payments/${invoiceId}/document';

  static const String project = '/projects';
  static const String subscription = '/subscriptions';
  static const String subscriptionPayment = '/subscriptions/payments';
  static const String planUsage = '/quota/usage';
  static const String cancelPlan = '/subscriptions/me/cancel-renewal';
  static const String aiPlan = '/quota/packs';
  static const String verify = '/subscriptions/payment/verify';
  static const String access = '/subscriptions/access-pass';
  static const String asset = '/assets';
  static String quota(String quotaId) => '/quota/packs/${quotaId}/purchase';
  static String favoriteTemplate(String templateId) =>
      '/users/me/favourites/templates/${templateId}';

  static String get productList => '/products';
}
