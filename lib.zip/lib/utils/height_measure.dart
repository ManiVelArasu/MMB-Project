
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../widgets/custom_sized_box.dart';

final height4 = CustomSizedBox(height: 4.h);
final height6 = CustomSizedBox(height: 6.h);
final height8 = CustomSizedBox(height: 8.h);
final height10 = CustomSizedBox(height: 10.h);
final height12 = CustomSizedBox(height: 12.h);
final height14 = CustomSizedBox(height: 14.h);
final height16 = CustomSizedBox(height: 16.h);
final height18 = CustomSizedBox(height: 18.h);
final height20 = CustomSizedBox(height: 20.h);
final height22 = CustomSizedBox(height: 22.h);
final height24 = CustomSizedBox(height: 24.h);
final height26 = CustomSizedBox(height: 26.h);
final height28 = CustomSizedBox(height: 28.h);
final height30 = CustomSizedBox(height: 30.h);
final width4 = CustomSizedBox(width: 4.w);
final width6 = CustomSizedBox(width: 6.w);
final width8 = CustomSizedBox(width: 8.w);
final width10 = CustomSizedBox(width: 10.w);
final width12 = CustomSizedBox(width: 12.w);
final width14 = CustomSizedBox(width: 14.w);
final width16 = CustomSizedBox(width: 16.w);
final width18 = CustomSizedBox(width: 18.w);
final width20 = CustomSizedBox(width: 20.w);
final width22 = CustomSizedBox(width: 22.w);
final width24 = CustomSizedBox(width: 24.w);
final width26 = CustomSizedBox(width: 26.w);
final width28 = CustomSizedBox(width: 28.w);
final width30 = CustomSizedBox(width: 30.w);
